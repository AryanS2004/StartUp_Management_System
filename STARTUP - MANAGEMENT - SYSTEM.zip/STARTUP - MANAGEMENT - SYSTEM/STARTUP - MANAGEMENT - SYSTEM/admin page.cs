﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace STARTUP___MANAGEMENT___SYSTEM
{
    public partial class admin_page : Form
    {
        private string connectionString = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\hp\Documents\Startup1.mdf;Integrated Security=True;Connect Timeout=30";
        private SqlConnection connection; private bool isClosingInitiated = false;

        public admin_page()
        {
            InitializeComponent(); connection = new SqlConnection(connectionString); this.FormClosing += AdminPage_FormClosing;
        }

        private void addNewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var em = new EmpAdd(); em.MdiParent = this;
            em.FormClosing += ChildFormClosing; HideGroupBox(); em.Show();
        }

        private void AdminPage_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (this.MdiChildren.Length == 0)
            {
                if (!isClosingInitiated)
                {
                    isClosingInitiated = true;
                    DialogResult result = MessageBox.Show("Do you want to close the application?", "Close Application Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (result == DialogResult.Yes)
                    {
                        Application.Exit();
                    }
                    else
                    {
                        e.Cancel = true; isClosingInitiated = false;
                    }
                }
            }
        }

        private void mODIFYToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var me = new ModifyEmployee(); me.MdiParent = this;
            me.FormClosing += ChildFormClosing; HideGroupBox(); me.Show();
        }

        private void addTeamToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            var at = new TeamAdd1(); at.MdiParent = this;
            at.FormClosing += ChildFormClosing; HideGroupBox(); at.Show();
        }

        private void viewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var view = new EmpAttendShow(); view.MdiParent = this;
            view.FormClosing += ChildFormClosing; HideGroupBox(); view.Show();
        }

        private void ChildFormClosing(object sender, FormClosingEventArgs e)
        {
            if (this.MdiChildren.Length == 1 && e.CloseReason == CloseReason.UserClosing)
            {
                ShowGroupBox();
            }
        }

        private void HideGroupBox()
        {
            panel1.Visible = false; linkaboutus.Visible = false;
        }

        private void ShowGroupBox()
        {
            panel1.Visible = true; linkaboutus.Visible = true;
        }

        private void documentsToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            var view = new DocAdd(); view.MdiParent = this;
            view.FormClosing += ChildFormClosing; HideGroupBox(); view.Show();
        }

        private void stockToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var view = new Stock(); view.MdiParent = this;
            view.FormClosing += ChildFormClosing; HideGroupBox(); view.Show();
        }

        private void attendanceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var att = new EmpAttend(); att.MdiParent = this;
            att.FormClosing += ChildFormClosing; att.Show(); HideGroupBox();
        }

        private void teamsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var add = new TeamAdd1(); add.MdiParent = this; 
            add.FormClosing += ChildFormClosing; HideGroupBox(); add.Show();
        }

        private void projectsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var add = new ProjectAdd1(); add.MdiParent = this;
            add.FormClosing += ChildFormClosing; HideGroupBox(); add.Show();
        }

        private void bugetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var add = new CashFlow(); add.MdiParent = this;
            add.FormClosing += ChildFormClosing; HideGroupBox(); add.Show();
        }

        private void linkaboutus_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Welcome to our Helpdesk! 🚀 If you ever need assistance or have questions, feel free to reach out to us. For emergencies, "+ 
            "you can contact us at 8769961080 or email us at aryaleena2004@gmail.com. Thank you for choosing our app to elevate your startup journey! 💼✨");
        }

        private void admin_page_Load(object sender, EventArgs e)
        {
            connection.Open(); 
            string query = "SELECT pid, pname, datelast FROM projects"; SqlCommand cmd = new SqlCommand(query, connection);
            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                if (reader.HasRows)
                {
                    richTextBox1.Text = "Projects - \n"; richTextBox2.Text = "Projects within 15 Days - \n";

                    while (reader.Read())
                    {
                        string pid = reader["pid"].ToString(); string pname = reader["pname"].ToString();
                        DateTime datelast = Convert.ToDateTime(reader["datelast"]);
                        if (datelast.Date == DateTime.Today)
                        {
                            richTextBox1.AppendText("Project " + pname + " (" + pid + ") should be submitted by Today.\n");
                        }
                        else
                        {
                            richTextBox1.AppendText("No project to be submitted today.\n");
                        }
                        if (datelast.Date >= DateTime.Today.AddDays(15))
                        {
                            int daysDifference = (int)(datelast.Date - DateTime.Today).TotalDays;
                            richTextBox2.AppendText("Project "+pname+" ("+pid+") is going to be submitted in "+daysDifference+" days.\n");
                        }
                        else
                        {
                            richTextBox2.AppendText("No near dates for upcoming Project.\n");
                        }
                    }
                }
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Saved!");
        }

        private void button9_Click(object sender, EventArgs e)
        {
            richTextBox5.Text = "";
        }
    }
}
