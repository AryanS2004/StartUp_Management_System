﻿namespace STARTUP___MANAGEMENT___SYSTEM
{
    partial class ProjectAdd1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProjectAdd1));
            this.Savebtn = new System.Windows.Forms.Button();
            this.txtadddesc = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtaddproid = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtaddproname = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dateaddass = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.dateaddsub = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.comaddtid = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtaddbuget = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.numaddpriority = new System.Windows.Forms.NumericUpDown();
            this.label8 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.adddoc = new System.Windows.Forms.TabPage();
            this.txtaddprotype = new System.Windows.Forms.TextBox();
            this.moddoc = new System.Windows.Forms.TabPage();
            this.txtmodproname = new System.Windows.Forms.TextBox();
            this.txtmodprotype = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.btnmoddel = new System.Windows.Forms.Button();
            this.nummodpri = new System.Windows.Forms.NumericUpDown();
            this.label14 = new System.Windows.Forms.Label();
            this.commodstat = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.nummodass = new System.Windows.Forms.NumericUpDown();
            this.label16 = new System.Windows.Forms.Label();
            this.commodtid = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.datemodsub = new System.Windows.Forms.DateTimePicker();
            this.label19 = new System.Windows.Forms.Label();
            this.datemodass = new System.Windows.Forms.DateTimePicker();
            this.label18 = new System.Windows.Forms.Label();
            this.btnmodsave = new System.Windows.Forms.Button();
            this.txtmoddesc = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.commodproid = new System.Windows.Forms.ComboBox();
            this.label100 = new System.Windows.Forms.Label();
            this.Viewdoc = new System.Windows.Forms.TabPage();
            this.btnviewdoc = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.comviewpid = new System.Windows.Forms.ComboBox();
            this.label29 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.numaddpriority)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.adddoc.SuspendLayout();
            this.moddoc.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nummodpri)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nummodass)).BeginInit();
            this.Viewdoc.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // Savebtn
            // 
            this.Savebtn.BackColor = System.Drawing.Color.Lime;
            this.Savebtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Savebtn.Font = new System.Drawing.Font("Microsoft Tai Le", 12F);
            this.Savebtn.Location = new System.Drawing.Point(634, 490);
            this.Savebtn.Name = "Savebtn";
            this.Savebtn.Size = new System.Drawing.Size(126, 54);
            this.Savebtn.TabIndex = 10;
            this.Savebtn.Text = "Save";
            this.Savebtn.UseVisualStyleBackColor = false;
            this.Savebtn.Click += new System.EventHandler(this.Savebtn_Click);
            // 
            // txtadddesc
            // 
            this.txtadddesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtadddesc.Location = new System.Drawing.Point(273, 297);
            this.txtadddesc.Multiline = true;
            this.txtadddesc.Name = "txtadddesc";
            this.txtadddesc.Size = new System.Drawing.Size(413, 132);
            this.txtadddesc.TabIndex = 7;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(8, 303);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(217, 29);
            this.label9.TabIndex = 80;
            this.label9.Text = "Project Description";
            // 
            // txtaddproid
            // 
            this.txtaddproid.Cursor = System.Windows.Forms.Cursors.No;
            this.txtaddproid.Enabled = false;
            this.txtaddproid.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaddproid.Location = new System.Drawing.Point(697, 30);
            this.txtaddproid.Multiline = true;
            this.txtaddproid.Name = "txtaddproid";
            this.txtaddproid.Size = new System.Drawing.Size(270, 37);
            this.txtaddproid.TabIndex = 1;
            this.txtaddproid.WordWrap = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(459, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 29);
            this.label2.TabIndex = 78;
            this.label2.Text = "Project ID";
            // 
            // txtaddproname
            // 
            this.txtaddproname.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaddproname.Location = new System.Drawing.Point(697, 93);
            this.txtaddproname.Multiline = true;
            this.txtaddproname.Name = "txtaddproname";
            this.txtaddproname.Size = new System.Drawing.Size(270, 37);
            this.txtaddproname.TabIndex = 2;
            this.txtaddproname.WordWrap = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(459, 97);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(168, 29);
            this.label1.TabIndex = 76;
            this.label1.Text = "Prroject Name";
            // 
            // dateaddass
            // 
            this.dateaddass.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateaddass.Location = new System.Drawing.Point(1012, 298);
            this.dateaddass.Name = "dateaddass";
            this.dateaddass.Size = new System.Drawing.Size(270, 34);
            this.dateaddass.TabIndex = 8;
            this.dateaddass.Value = new System.DateTime(2023, 11, 15, 0, 20, 47, 0);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(719, 298);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(220, 29);
            this.label3.TabIndex = 84;
            this.label3.Text = "Date of Assignment";
            // 
            // dateaddsub
            // 
            this.dateaddsub.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateaddsub.Location = new System.Drawing.Point(1012, 373);
            this.dateaddsub.Name = "dateaddsub";
            this.dateaddsub.Size = new System.Drawing.Size(270, 34);
            this.dateaddsub.TabIndex = 9;
            this.dateaddsub.Value = new System.DateTime(2023, 11, 15, 0, 20, 47, 0);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(719, 375);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(279, 29);
            this.label4.TabIndex = 86;
            this.label4.Text = "Last Date for Submission";
            // 
            // comaddtid
            // 
            this.comaddtid.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comaddtid.FormattingEnabled = true;
            this.comaddtid.Location = new System.Drawing.Point(272, 166);
            this.comaddtid.Name = "comaddtid";
            this.comaddtid.Size = new System.Drawing.Size(270, 37);
            this.comaddtid.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(7, 169);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(168, 29);
            this.label6.TabIndex = 88;
            this.label6.Text = "Enter Team ID";
            // 
            // txtaddbuget
            // 
            this.txtaddbuget.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaddbuget.Location = new System.Drawing.Point(1011, 166);
            this.txtaddbuget.Multiline = true;
            this.txtaddbuget.Name = "txtaddbuget";
            this.txtaddbuget.Size = new System.Drawing.Size(270, 37);
            this.txtaddbuget.TabIndex = 4;
            this.txtaddbuget.WordWrap = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(718, 169);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(264, 29);
            this.label5.TabIndex = 90;
            this.label5.Text = "Project Assigned Buget";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(719, 235);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(170, 29);
            this.label7.TabIndex = 92;
            this.label7.Text = "Project Priority";
            // 
            // numaddpriority
            // 
            this.numaddpriority.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numaddpriority.Location = new System.Drawing.Point(1012, 234);
            this.numaddpriority.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numaddpriority.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numaddpriority.Name = "numaddpriority";
            this.numaddpriority.Size = new System.Drawing.Size(270, 34);
            this.numaddpriority.TabIndex = 6;
            this.numaddpriority.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(8, 235);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(150, 29);
            this.label8.TabIndex = 95;
            this.label8.Text = "Project Type";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.adddoc);
            this.tabControl1.Controls.Add(this.moddoc);
            this.tabControl1.Controls.Add(this.Viewdoc);
            this.tabControl1.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(10, 38);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1314, 648);
            this.tabControl1.TabIndex = 96;
            // 
            // adddoc
            // 
            this.adddoc.BackColor = System.Drawing.Color.Peru;
            this.adddoc.Controls.Add(this.txtaddprotype);
            this.adddoc.Controls.Add(this.label2);
            this.adddoc.Controls.Add(this.label8);
            this.adddoc.Controls.Add(this.label1);
            this.adddoc.Controls.Add(this.txtaddproname);
            this.adddoc.Controls.Add(this.numaddpriority);
            this.adddoc.Controls.Add(this.txtaddproid);
            this.adddoc.Controls.Add(this.label7);
            this.adddoc.Controls.Add(this.label9);
            this.adddoc.Controls.Add(this.txtaddbuget);
            this.adddoc.Controls.Add(this.txtadddesc);
            this.adddoc.Controls.Add(this.label5);
            this.adddoc.Controls.Add(this.comaddtid);
            this.adddoc.Controls.Add(this.Savebtn);
            this.adddoc.Controls.Add(this.label6);
            this.adddoc.Controls.Add(this.label3);
            this.adddoc.Controls.Add(this.dateaddsub);
            this.adddoc.Controls.Add(this.dateaddass);
            this.adddoc.Controls.Add(this.label4);
            this.adddoc.Location = new System.Drawing.Point(4, 35);
            this.adddoc.Name = "adddoc";
            this.adddoc.Padding = new System.Windows.Forms.Padding(3);
            this.adddoc.Size = new System.Drawing.Size(1306, 609);
            this.adddoc.TabIndex = 0;
            this.adddoc.Text = "Add";
            // 
            // txtaddprotype
            // 
            this.txtaddprotype.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.txtaddprotype.Location = new System.Drawing.Point(272, 233);
            this.txtaddprotype.Multiline = true;
            this.txtaddprotype.Name = "txtaddprotype";
            this.txtaddprotype.Size = new System.Drawing.Size(270, 37);
            this.txtaddprotype.TabIndex = 4;
            // 
            // moddoc
            // 
            this.moddoc.BackColor = System.Drawing.Color.Coral;
            this.moddoc.Controls.Add(this.txtmodproname);
            this.moddoc.Controls.Add(this.txtmodprotype);
            this.moddoc.Controls.Add(this.label10);
            this.moddoc.Controls.Add(this.btnmoddel);
            this.moddoc.Controls.Add(this.nummodpri);
            this.moddoc.Controls.Add(this.label14);
            this.moddoc.Controls.Add(this.commodstat);
            this.moddoc.Controls.Add(this.label12);
            this.moddoc.Controls.Add(this.label13);
            this.moddoc.Controls.Add(this.nummodass);
            this.moddoc.Controls.Add(this.label16);
            this.moddoc.Controls.Add(this.commodtid);
            this.moddoc.Controls.Add(this.label11);
            this.moddoc.Controls.Add(this.datemodsub);
            this.moddoc.Controls.Add(this.label19);
            this.moddoc.Controls.Add(this.datemodass);
            this.moddoc.Controls.Add(this.label18);
            this.moddoc.Controls.Add(this.btnmodsave);
            this.moddoc.Controls.Add(this.txtmoddesc);
            this.moddoc.Controls.Add(this.label15);
            this.moddoc.Controls.Add(this.commodproid);
            this.moddoc.Controls.Add(this.label100);
            this.moddoc.Location = new System.Drawing.Point(4, 35);
            this.moddoc.Name = "moddoc";
            this.moddoc.Padding = new System.Windows.Forms.Padding(3);
            this.moddoc.Size = new System.Drawing.Size(1306, 609);
            this.moddoc.TabIndex = 1;
            this.moddoc.Text = "Modify";
            // 
            // txtmodproname
            // 
            this.txtmodproname.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.txtmodproname.Location = new System.Drawing.Point(1012, 41);
            this.txtmodproname.Multiline = true;
            this.txtmodproname.Name = "txtmodproname";
            this.txtmodproname.Size = new System.Drawing.Size(270, 37);
            this.txtmodproname.TabIndex = 147;
            // 
            // txtmodprotype
            // 
            this.txtmodprotype.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.txtmodprotype.Location = new System.Drawing.Point(272, 183);
            this.txtmodprotype.Multiline = true;
            this.txtmodprotype.Name = "txtmodprotype";
            this.txtmodprotype.Size = new System.Drawing.Size(270, 37);
            this.txtmodprotype.TabIndex = 146;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(705, 44);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(155, 29);
            this.label10.TabIndex = 145;
            this.label10.Text = "Project name";
            // 
            // btnmoddel
            // 
            this.btnmoddel.BackColor = System.Drawing.Color.Red;
            this.btnmoddel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnmoddel.Font = new System.Drawing.Font("Microsoft Tai Le", 12F);
            this.btnmoddel.Location = new System.Drawing.Point(1012, 521);
            this.btnmoddel.Name = "btnmoddel";
            this.btnmoddel.Size = new System.Drawing.Size(167, 48);
            this.btnmoddel.TabIndex = 144;
            this.btnmoddel.Text = "Remove Project";
            this.btnmoddel.UseVisualStyleBackColor = false;
            // 
            // nummodpri
            // 
            this.nummodpri.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nummodpri.Location = new System.Drawing.Point(1012, 187);
            this.nummodpri.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nummodpri.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nummodpri.Name = "nummodpri";
            this.nummodpri.Size = new System.Drawing.Size(270, 34);
            this.nummodpri.TabIndex = 143;
            this.nummodpri.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(705, 189);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(170, 29);
            this.label14.TabIndex = 142;
            this.label14.Text = "Project Priority";
            // 
            // commodstat
            // 
            this.commodstat.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.commodstat.FormattingEnabled = true;
            this.commodstat.Items.AddRange(new object[] {
            "Submitted",
            "Not Submitted"});
            this.commodstat.Location = new System.Drawing.Point(1012, 120);
            this.commodstat.Name = "commodstat";
            this.commodstat.Size = new System.Drawing.Size(270, 37);
            this.commodstat.TabIndex = 141;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(705, 123);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(161, 29);
            this.label12.TabIndex = 140;
            this.label12.Text = "Project Status";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(9, 184);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(150, 29);
            this.label13.TabIndex = 139;
            this.label13.Text = "Project Type";
            // 
            // nummodass
            // 
            this.nummodass.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nummodass.Location = new System.Drawing.Point(1012, 261);
            this.nummodass.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.nummodass.Name = "nummodass";
            this.nummodass.Size = new System.Drawing.Size(270, 34);
            this.nummodass.TabIndex = 135;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(705, 260);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(264, 29);
            this.label16.TabIndex = 134;
            this.label16.Text = "Project Assigned Buget";
            // 
            // commodtid
            // 
            this.commodtid.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.commodtid.FormattingEnabled = true;
            this.commodtid.Items.AddRange(new object[] {
            "T001(Alpha Team)",
            "T002(Beta Team)"});
            this.commodtid.Location = new System.Drawing.Point(270, 120);
            this.commodtid.Name = "commodtid";
            this.commodtid.Size = new System.Drawing.Size(270, 37);
            this.commodtid.TabIndex = 133;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(9, 122);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(168, 29);
            this.label11.TabIndex = 132;
            this.label11.Text = "Enter Team ID";
            // 
            // datemodsub
            // 
            this.datemodsub.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datemodsub.Location = new System.Drawing.Point(1012, 422);
            this.datemodsub.Name = "datemodsub";
            this.datemodsub.Size = new System.Drawing.Size(270, 34);
            this.datemodsub.TabIndex = 131;
            this.datemodsub.Value = new System.DateTime(2023, 11, 15, 0, 20, 47, 0);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(705, 422);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(267, 29);
            this.label19.TabIndex = 130;
            this.label19.Text = "Last Date for Submittion";
            // 
            // datemodass
            // 
            this.datemodass.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datemodass.Location = new System.Drawing.Point(270, 417);
            this.datemodass.Name = "datemodass";
            this.datemodass.Size = new System.Drawing.Size(270, 34);
            this.datemodass.TabIndex = 129;
            this.datemodass.Value = new System.DateTime(2023, 11, 15, 0, 20, 47, 0);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(9, 419);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(220, 29);
            this.label18.TabIndex = 128;
            this.label18.Text = "Date of Assignment";
            // 
            // btnmodsave
            // 
            this.btnmodsave.BackColor = System.Drawing.Color.Lime;
            this.btnmodsave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnmodsave.Font = new System.Drawing.Font("Microsoft Tai Le", 12F);
            this.btnmodsave.Location = new System.Drawing.Point(614, 518);
            this.btnmodsave.Name = "btnmodsave";
            this.btnmodsave.Size = new System.Drawing.Size(127, 51);
            this.btnmodsave.TabIndex = 127;
            this.btnmodsave.Text = "Save";
            this.btnmodsave.UseVisualStyleBackColor = false;
            this.btnmodsave.Click += new System.EventHandler(this.btnmodsave_Click);
            // 
            // txtmoddesc
            // 
            this.txtmoddesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmoddesc.Location = new System.Drawing.Point(270, 257);
            this.txtmoddesc.Multiline = true;
            this.txtmoddesc.Name = "txtmoddesc";
            this.txtmoddesc.Size = new System.Drawing.Size(413, 132);
            this.txtmoddesc.TabIndex = 125;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(9, 262);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(217, 29);
            this.label15.TabIndex = 124;
            this.label15.Text = "Project Description";
            // 
            // commodproid
            // 
            this.commodproid.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.commodproid.FormattingEnabled = true;
            this.commodproid.Location = new System.Drawing.Point(270, 41);
            this.commodproid.Name = "commodproid";
            this.commodproid.Size = new System.Drawing.Size(270, 37);
            this.commodproid.TabIndex = 1;
            this.commodproid.SelectedIndexChanged += new System.EventHandler(this.commodproid_SelectedIndexChanged);
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label100.Location = new System.Drawing.Point(9, 44);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(200, 29);
            this.label100.TabIndex = 121;
            this.label100.Text = "Search Project ID";
            // 
            // Viewdoc
            // 
            this.Viewdoc.BackColor = System.Drawing.Color.NavajoWhite;
            this.Viewdoc.Controls.Add(this.btnviewdoc);
            this.Viewdoc.Controls.Add(this.dataGridView1);
            this.Viewdoc.Controls.Add(this.comviewpid);
            this.Viewdoc.Controls.Add(this.label29);
            this.Viewdoc.Location = new System.Drawing.Point(4, 35);
            this.Viewdoc.Name = "Viewdoc";
            this.Viewdoc.Size = new System.Drawing.Size(1306, 609);
            this.Viewdoc.TabIndex = 2;
            this.Viewdoc.Text = "View";
            // 
            // btnviewdoc
            // 
            this.btnviewdoc.BackColor = System.Drawing.Color.Orange;
            this.btnviewdoc.Font = new System.Drawing.Font("Microsoft Tai Le", 12F);
            this.btnviewdoc.Location = new System.Drawing.Point(572, 35);
            this.btnviewdoc.Name = "btnviewdoc";
            this.btnviewdoc.Size = new System.Drawing.Size(126, 61);
            this.btnviewdoc.TabIndex = 21;
            this.btnviewdoc.Text = "Search";
            this.btnviewdoc.UseVisualStyleBackColor = false;
            this.btnviewdoc.Click += new System.EventHandler(this.btnviewdoc_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(31, 125);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1204, 410);
            this.dataGridView1.TabIndex = 20;
            // 
            // comviewpid
            // 
            this.comviewpid.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.comviewpid.FormattingEnabled = true;
            this.comviewpid.Location = new System.Drawing.Point(185, 45);
            this.comviewpid.Name = "comviewpid";
            this.comviewpid.Size = new System.Drawing.Size(270, 37);
            this.comviewpid.TabIndex = 1;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(26, 48);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(118, 29);
            this.label29.TabIndex = 17;
            this.label29.Text = "Project ID";
            // 
            // ProjectAdd1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.RoyalBlue;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1924, 1055);
            this.Controls.Add(this.tabControl1);
            this.DoubleBuffered = true;
            this.Name = "ProjectAdd1";
            this.ShowIcon = false;
            this.Text = "Project Management";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.ProjectAdd1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numaddpriority)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.adddoc.ResumeLayout(false);
            this.adddoc.PerformLayout();
            this.moddoc.ResumeLayout(false);
            this.moddoc.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nummodpri)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nummodass)).EndInit();
            this.Viewdoc.ResumeLayout(false);
            this.Viewdoc.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Savebtn;
        private System.Windows.Forms.TextBox txtadddesc;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtaddproid;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtaddproname;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dateaddass;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dateaddsub;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comaddtid;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtaddbuget;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown numaddpriority;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage adddoc;
        private System.Windows.Forms.TabPage moddoc;
        private System.Windows.Forms.TabPage Viewdoc;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ComboBox comviewpid;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.NumericUpDown nummodpri;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox commodstat;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.NumericUpDown nummodass;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox commodtid;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DateTimePicker datemodsub;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.DateTimePicker datemodass;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button btnmodsave;
        private System.Windows.Forms.TextBox txtmoddesc;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox commodproid;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Button btnmoddel;
        private System.Windows.Forms.TextBox txtaddprotype;
        private System.Windows.Forms.TextBox txtmodproname;
        private System.Windows.Forms.TextBox txtmodprotype;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnviewdoc;
    }
}