﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace STARTUP___MANAGEMENT___SYSTEM
{
    public partial class CashFlow : Form
    {
        private string connectionString = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\hp\Documents\Startup1.mdf;Integrated Security=True;Connect Timeout=30";
        private SqlConnection connection; private int tid; private float lpay, lget, lintrest; private string tranId;
        private readonly object searchLock = new object();

        public CashFlow()
        {
            InitializeComponent(); connection = new SqlConnection(connectionString);
        }

        private void comnewttype_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comnewttype.SelectedItem.ToString() == "Investment")
            {
                pannewinvest.Visible = true; pannewl.Visible = false;
            }
            else
            {
                pannewinvest.Visible = false;
            }

            if (comnewttype.SelectedItem.ToString() == "Loan")
            {
                pannewl.Visible = true; pannewinvest.Visible = false;
            }
            else
            {
                pannewl.Visible = false;
            }
        }

        private void btnnewisave_Click(object sender, EventArgs e)
        {
            if (comnewttype.SelectedItem.ToString() == "Investment")
            {
                if (!string.IsNullOrEmpty(txtnewiname.Text) && !string.IsNullOrEmpty(txtnewiam.Text))
                {
                    string iname = txtnewiname.Text.Trim(); string cont = txtnewiphone.Text; DateTime datein = datenewiinvest.Value;
                    string desc = txtnewidesc.Text; int amount = Convert.ToInt32(txtnewiam.Text);

                    DialogResult result = MessageBox.Show("Do you want to save the information?", "Save Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (result == DialogResult.Yes)
                    {
                        try
                        {
                            connection.Open();
                            string insertQuery = "INSERT INTO invest (compname, tranid, contnum, dateinvest, investamount, trandesc, investstatus) " +
                                                 "VALUES (@compname, @tranid, @contnum, @dateinvest, @investamount, @trandesc, @investstatus)";
                            using (SqlCommand cmd = new SqlCommand(insertQuery, connection))
                            {
                                cmd.Parameters.AddWithValue("@compname", iname); cmd.Parameters.AddWithValue("@tranid", tid); cmd.Parameters.AddWithValue("@contnum", cont);
                                cmd.Parameters.AddWithValue("@dateinvest", datein); cmd.Parameters.AddWithValue("@investamount", amount);
                                cmd.Parameters.AddWithValue("@trandesc", desc); cmd.Parameters.AddWithValue("@investstatus", "Uncleared");
                                cmd.ExecuteNonQuery();
                            }
                            MessageBox.Show("Information of investment is saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error saving data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        finally
                        {
                            connection.Close();
                        }
                    }
                }
            }
        }

        private void CashFlow_Load(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open(); string query = "SELECT MAX(tranid) FROM (SELECT tranid FROM invest UNION SELECT tranid FROM loantran) AS CombinedTable";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    object result = command.ExecuteScalar();
                    if (result != null && result != DBNull.Value)
                    {
                        int maxTranId = Convert.ToInt32(result); tid = maxTranId + 1; txtnewtid.Text = "T"+tid;
                    }
                    else
                    {
                        MessageBox.Show("error in showing the value in tid", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open(); string query = "SELECT tranid FROM invest UNION SELECT tranid FROM loantran";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            commodproid.Items.Add("T" + reader["tranid"].ToString()); comviewtid.Items.Add("T" + reader["tranid"].ToString());
                        }
                    }
                }
            }
        }

        private void btnnewlsave_Click(object sender, EventArgs e)
        {
            if (comnewttype.SelectedItem.ToString() == "Loan")
            {
                lget = Convert.ToSingle(txtnewlam.Text); lintrest = Convert.ToSingle(txtnewlintrest.Text);
                if (Convert.ToSingle(txtnewlintrest.Text) > 0)
                {
                    lpay = lget * lintrest;
                    txtnewlampay.Text = lpay.ToString();
                }
                else
                {
                    MessageBox.Show("Intrest rate must be there !!", "OOPs", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                if (!string.IsNullOrEmpty(txtnewlproname.Text) && !string.IsNullOrEmpty(txtnewlampay.Text))
                {
                    string providename = txtnewlproname.Text.Trim(); DateTime dtake = datenewltake.Value; 
                    DateTime dreturn = datenewlret.Value; string desc = txtnewloandesc.Text;
                    DialogResult result = MessageBox.Show("Do you want to save the information?", "Save Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (result == DialogResult.Yes)
                    {
                        try
                        {
                            connection.Open();
                            string insertQuery = "INSERT INTO loantran (providername, tranid, loanamount, intrestrate, payamount, dateofloan, datelast, loandesc , loanstatus) " +
                                                 "VALUES (@providername, @tranid, @loanamount, @intrestrate, @payamount, @dateofloan, @datelast, @loandesc, @loanstatus)";
                            using (SqlCommand cmd = new SqlCommand(insertQuery, connection))
                            {
                                cmd.Parameters.AddWithValue("@providername", providename); cmd.Parameters.AddWithValue("@tranid", tid);
                                cmd.Parameters.AddWithValue("@loanamount", lget); cmd.Parameters.AddWithValue("@intrestrate", lintrest);
                                cmd.Parameters.AddWithValue("@payamount", lpay); cmd.Parameters.AddWithValue("@dateofloan", dtake); cmd.Parameters.AddWithValue("@datelast", dreturn);
                                cmd.Parameters.AddWithValue("@loandesc", desc); cmd.Parameters.AddWithValue("@loanstatus", "Uncleared"); cmd.ExecuteNonQuery();
                            }
                            MessageBox.Show("Information of Loan is saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error saving data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        finally
                        {
                            connection.Close();
                        }
                    }
                }
            }
        }

        private void commodproid_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedValue = commodproid.SelectedItem.ToString(); tranId = selectedValue.Substring(1); SearchDataInTables(tranId);
        }

        private void btnmodloan_Click(object sender, EventArgs e)
        {
            lget = Convert.ToSingle(txtlmoamtake.Text); lintrest = Convert.ToSingle(txtlmoinvest.Text); lpay = lget * lintrest;
            string providename = txtlmoname.Text.Trim(); DateTime dtake = datelmotake.Value; txtlmopay.Text = lpay.ToString();
            DateTime dreturn = datelmoret.Value; string desc = txtlmoddesc.Text; string status = comlmodstatus.Text;  
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string updateQuery = "UPDATE loantran SET providername = @providername, loanamount = @loanamount, intrestrate = @intrestrate , payamount = @payamount, " +
                    "dateofloan = @dateofloan, datelast = @datelast, loandesc = @loandesc , loanstatus = @loanstatus WHERE tranid = @tranId";
                using (SqlCommand updateCommand = new SqlCommand(updateQuery, connection))
                {
                    updateCommand.Parameters.AddWithValue("@providername", providename); updateCommand.Parameters.AddWithValue("@loanamount", lget);
                    updateCommand.Parameters.AddWithValue("@tranId", tranId); updateCommand.Parameters.AddWithValue("@intrestrate", lintrest);
                    updateCommand.Parameters.AddWithValue("@payamount", lpay); updateCommand.Parameters.AddWithValue("@dateofloan", dtake);
                    updateCommand.Parameters.AddWithValue("@datelast", dreturn); updateCommand.Parameters.AddWithValue("@loandesc", desc);
                    updateCommand.Parameters.AddWithValue("@loanstatus", status);

                    int rowsAffected = updateCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Data updated Loan Table.");
                    }
                    else
                    {
                        MessageBox.Show("No matching record found in loantran table.");
                    }
                }
            }
        }

        private void SearchDataInTables(string tranId)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open(); string investQuery = "SELECT * FROM invest WHERE tranid = '"+ tranId +"'";
                using (SqlCommand investCommand = new SqlCommand(investQuery, connection))
                {
                    using (SqlDataReader investReader = investCommand.ExecuteReader())
                    {
                        if (investReader.Read())
                        {
                            panmodinvest.Visible = true; txtimodname.Text = investReader["compname"].ToString(); 
                            txtimodcontact.Text = investReader["contnum"].ToString(); DateTime dateValue;
                            if (DateTime.TryParse(investReader["dateinvest"].ToString(), out dateValue))
                            {
                                dateimodinvest.Value = dateValue;
                            }   
                            txtimodinamt.Text = investReader["investamount"].ToString(); 
                            txtimoddesc.Text = investReader["trandesc"].ToString(); cominstatus.Text = investReader["investstatus"].ToString(); return;
                        }
                        else
                        {
                            panmodinvest.Visible = false;
                        }
                    }
                }

                string loantranQuery = "SELECT * FROM loantran WHERE tranid = '"+ tranId +"'";
                using (SqlCommand loantranCommand = new SqlCommand(loantranQuery, connection))
                {
                    using (SqlDataReader loantranReader = loantranCommand.ExecuteReader())
                    {
                        if (loantranReader.Read())
                        {
                            panmodloan.Visible = true; txtlmoname.Text = loantranReader["providername"].ToString(); txtlmopay.Text = loantranReader["payamount"].ToString();
                            txtlmoamtake.Text = loantranReader["loanamount"].ToString(); txtlmoinvest.Text = loantranReader["intrestrate"].ToString(); DateTime dateloan;
                            if (DateTime.TryParse(loantranReader["dateofloan"].ToString(), out dateloan))
                            {
                                dateimodinvest.Value = dateloan;
                            }
                            DateTime datelast;
                            if (DateTime.TryParse(loantranReader["datelast"].ToString(), out datelast))
                            {
                                dateimodinvest.Value = datelast;
                            }

                            txtlmoddesc.Text = loantranReader["loandesc"].ToString(); comlmodstatus.Text = loantranReader["loanstatus"].ToString();
                            return;
                        }
                        else
                        {
                            panmodloan.Visible = false;
                        }
                    }
                }
            }
        }

        private void btnimodsave_Click(object sender, EventArgs e)
        {
            string investname = txtimodname.Text; string contnum = txtimodcontact.Text; DateTime dateinvest = dateimodinvest.Value;
            int inamount = Convert.ToInt32(txtimodinamt.Text); string invdesc = txtimoddesc.Text; string status = cominstatus.Text;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open(); string updateQuery = "UPDATE invest SET compname = @compname, contnum = @contnum, dateinvest = @dateinvest , investamount = @investamount, " +
                    "trandesc = @trandesc, investstatus = @investstatus WHERE tranid = @tranId";
                using (SqlCommand updateCommand = new SqlCommand(updateQuery, connection))
                {
                    updateCommand.Parameters.AddWithValue("@compname", investname); updateCommand.Parameters.AddWithValue("@contnum", lget);
                    updateCommand.Parameters.AddWithValue("@tranId", tranId); updateCommand.Parameters.AddWithValue("@dateinvest", dateinvest);
                    updateCommand.Parameters.AddWithValue("@investamount", inamount); updateCommand.Parameters.AddWithValue("@trandesc", invdesc);
                    updateCommand.Parameters.AddWithValue("@investstatus", status);
                    int rowsAffected = updateCommand.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Data updated invest Table.");
                    }
                    else
                    {
                        MessageBox.Show("No matching record found in loantran table.");
                    }
                }
            }
        }

        private void btnmoddel_Click(object sender, EventArgs e)
        {
            string table1 = "invest"; string table2 = "loantran"; 
            using (SqlCommand commandTable1 = new SqlCommand("DELETE FROM " + table1 + " WHERE tranid = '"+ tranId +"';", connection))
            {
                try
                {
                    int rowsAffectedTable1 = commandTable1.ExecuteNonQuery();
                    if (rowsAffectedTable1 > 0)
                    {
                        Console.WriteLine("Data deleted from Table1.");
                    }
                    else
                    {
                        Console.WriteLine("No data deleted from Table1. Check your condition or data existence.");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error deleting from invest tabel:"+ ex.Message);
                }
            }

            using (SqlCommand commandTable2 = new SqlCommand("DELETE FROM " + table2 + " WHERE tranid = '"+ tranId +"';", connection))
            {
                try
                {
                    int rowsAffectedTable2 = commandTable2.ExecuteNonQuery();
                    if (rowsAffectedTable2 > 0)
                    {
                        Console.WriteLine("Data deleted from Table2.");
                    }
                    else
                    {
                        Console.WriteLine("No data deleted from Table2. Check your condition or data existence.");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error deleting from loan table :" + ex.Message);
                }
            }        
        }

        private void btnviewtran_Click(object sender, EventArgs e)
        {
            btnviewtran.BackColor = Color.LimeGreen; dataGridView1.Visible = true;
        }

        private void comviewtid_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedValue = comviewtid.SelectedItem.ToString(); tranId = selectedValue.Substring(1); Searchforview(tranId);
        }

        private void Searchforview(string tranId)
        {
            DataSet dataSet1 = new DataSet(); DataSet dataSet = new DataSet();
            lock (searchLock)
            {
                string query = "SELECT * FROM invest WHERE tranId = @tranId";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open(); 
                    using (SqlDataAdapter adapter = new SqlDataAdapter(query, connection))
                    {
                        adapter.SelectCommand.Parameters.AddWithValue("@tranId", tranId); adapter.Fill(dataSet, "InvestTable");
                    }
                }
            }
            lock (searchLock)
            {
                string query1 = "SELECT * FROM loantran WHERE tranId = @tranId"; 
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open(); using (SqlDataAdapter adapter1 = new SqlDataAdapter(query1, connection))
                    {
                        adapter1.SelectCommand.Parameters.AddWithValue("@tranId", tranId); adapter1.Fill(dataSet1, "loantable");
                    }
                }
            }
            int tom = Convert.ToInt32(tranId);
            if (tom %2 == 0)
            {
                dataGridView1.DataSource = dataSet1.Tables["loantable"];
            }
            else
            {
                dataGridView1.DataSource = dataSet.Tables["InvestTable"];
            }
        }
    }
}
