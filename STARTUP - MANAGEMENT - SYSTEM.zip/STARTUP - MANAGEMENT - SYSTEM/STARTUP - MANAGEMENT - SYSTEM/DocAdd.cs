﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace STARTUP___MANAGEMENT___SYSTEM
{
    public partial class DocAdd : Form
    {
        private string selectedFilePath;
        private string connectionString = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\hp\Documents\Startup1.mdf;Integrated Security=True;Connect Timeout=30";
        private SqlConnection connection; string moddid; int did; string modflocation; string searchid;

        public DocAdd()
        {
            InitializeComponent(); connection = new SqlConnection(connectionString);
        }

        private void btnviewdoc_Click(object sender, EventArgs e)
        {
            if (comviewdocid.Text != "")
            {
                MessageBox.Show("Document Found.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information); dataGridView1.Visible = true;
            }
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            getdid(); try
            {
                connection.Open(); string insertQuery = "INSERT INTO documents (did, dname, dtype, submitby, ddesc, datesub, dfile) " +
                                     "VALUES (@doxid, @docname, @doctype, @subby, @description, @datesub, @filepath)";
                using (SqlCommand cmd = new SqlCommand(insertQuery, connection))
                {
                    cmd.Parameters.AddWithValue("@doxid", did); cmd.Parameters.AddWithValue("@docname", txtdocname.Text.Trim());
                    cmd.Parameters.AddWithValue("@doctype", comdocty.Text.Trim()); cmd.Parameters.AddWithValue("@subby", comsubby.Text.Trim());
                    cmd.Parameters.AddWithValue("@description", richtxtdesc.Text.Trim());cmd.Parameters.AddWithValue("@datesub", datesub.Value);
                    cmd.Parameters.AddWithValue("@filepath", selectedFilePath.Trim()); cmd.ExecuteNonQuery();
                }
                MessageBox.Show("Data saved successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                connection.Close();
            }
        }

        private void getdid()
        {
            string productId = txtdocid.Text; int indexOfI = productId.IndexOf('D');
            if (indexOfI != -1)
            {
                string numericPart = productId.Substring(indexOfI + 1); if (int.TryParse(numericPart, out did)) { }
            }
        }

        private void btnchodoc_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            switch (comdocty.SelectedItem.ToString())
            {
                case "Image": openFileDialog1.Filter = "Image Files|*.bmp;*.jpg;*.jpeg;*.png;*.gif|All Files|*.*"; break;
                case "PDF File": openFileDialog1.Filter = "PDF Files|*.pdf|All Files|*.*"; break;
                case "Power Point File": openFileDialog1.Filter = "PowerPoint Files|*.ppt;*.pptx|All Files|*.*"; break;
                case "Word File": openFileDialog1.Filter = "Word Files|*.doc;*.docx|All Files|*.*"; break;
                case "Other": openFileDialog1.Filter = "All Files|*.*"; break;
                default: openFileDialog1.Filter = "All Files|*.*"; break;
            }
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                selectedFilePath = openFileDialog1.FileName; MessageBox.Show("Document selected: " + selectedFilePath, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void comdocty_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comdocty.SelectedItem.ToString() != "Hard Copy")
            {
                label6.Visible = true; btnchodoc.Visible = true;
            }
            else
            {
                label6.Visible = false; btnchodoc.Visible = false;
            }
        }

        private void DocAdd_Load(object sender, EventArgs e)
        {
            PopulateComboBox();
        }

        private void PopulateComboBox()
        {
            try
            {
                connection.Open(); string countQuery = "SELECT COUNT(*) FROM documents;";
                SqlCommand countCmd = new SqlCommand(countQuery, connection); int recordCount = Convert.ToInt32(countCmd.ExecuteScalar());
                int nextEid = recordCount + 1; string formattedEid = "D" + nextEid; txtdocid.Text = formattedEid;
                string query2 = "SELECT did FROM documents;";
                using (SqlCommand command = new SqlCommand(query2, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            int did = reader.GetInt32(0); commoddocid.Items.Add("D" + did); comviewdocid.Items.Add("D" + did);
                        }
                    }
                }
                string query = "SELECT Eid, fname, lname FROM Empbasic";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            int eid = reader.GetInt32(0); string firstName = reader.GetString(1); string lastName = reader.GetString(2);
                            string displayString = "E" + eid + " (" + firstName + " " + lastName + ")";
                            comsubby.Items.Add(displayString); commodsub.Items.Add(displayString);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        private void commoddocid_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedValue = commoddocid.SelectedItem.ToString(); moddid = selectedValue.Substring(1); SearchDataInTables(moddid);
        }

        private void SearchDataInTables(string tranId)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open(); string investQuery = "SELECT * FROM documents WHERE did = '" + tranId + "'";
                using (SqlCommand investCommand = new SqlCommand(investQuery, connection))
                {
                    using (SqlDataReader investReader = investCommand.ExecuteReader())
                    {
                        if (investReader.Read())
                        {
                            txtmoddocname.Text = investReader["dname"].ToString(); commoddoctype.Text = investReader["dtype"].ToString();
                            commodsub.Text = investReader["submitby"].ToString(); txtmoddesc.Text = investReader["ddesc"].ToString();
                            modflocation = investReader["dfile"].ToString(); DateTime datesub;
                            if (DateTime.TryParse(investReader["datesub"].ToString(), out datesub))
                            {
                                datemodsub.Value = datesub;
                            }
                            return;
                        }
                    }
                }
            }
        }

        private void btnmoddoc_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do you want to save the information?", "Save Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string updateQuery = "UPDATE documents SET dname = @dname, dtype = @dtype, submitby = @submitby, datesub = @datesub, " +
                        "ddesc = @ddesc, dflie = @dflie WHERE did = @did";
                    using (SqlCommand cmd = new SqlCommand(updateQuery, connection))
                    {
                        cmd.Parameters.AddWithValue("@dname", txtmoddocname.Text.Trim()); cmd.Parameters.AddWithValue("@dtype", commoddoctype.Text.Trim());
                        cmd.Parameters.AddWithValue("@submitby", commodsub.Text.Trim()); cmd.Parameters.AddWithValue("@datesub", datemodsub.Value);
                        cmd.Parameters.AddWithValue("@ddesc", txtmoddesc.Text.Trim()); cmd.Parameters.AddWithValue("@dflie", modflocation);
                        cmd.Parameters.AddWithValue("@did", moddid); int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Data updated.");
                        }
                        else
                        {
                            MessageBox.Show("No matching record found in loantran table.");
                        }
                    }
                }
            }
        }

        private void btnmodchoosedoc_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            switch (commoddoctype.SelectedItem.ToString())
            {
                case "Image": openFileDialog1.Filter = "Image Files|*.bmp;*.jpg;*.jpeg;*.png;*.gif|All Files|*.*"; break;
                case "PDF File": openFileDialog1.Filter = "PDF Files|*.pdf|All Files|*.*"; break;
                case "Power Point File": openFileDialog1.Filter = "PowerPoint Files|*.ppt;*.pptx|All Files|*.*"; break;
                case "Word File": openFileDialog1.Filter = "Word Files|*.doc;*.docx|All Files|*.*"; break;
                case "Other": openFileDialog1.Filter = "All Files|*.*"; break;
                default: openFileDialog1.Filter = "All Files|*.*"; break;
            }

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                modflocation = openFileDialog1.FileName;
                MessageBox.Show("Document selected: " + selectedFilePath, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void commoddoctype_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (commoddoctype.SelectedItem.ToString() != "Hard Copy")
            {
                label10.Visible = true; btnmodchoosedoc.Visible = true;
            }
            else
            {
                label10.Visible = false; btnmodchoosedoc.Visible = false;
            }
        }

        private void comviewdocid_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comviewdocid.Text == "")
            {
                DataSet dataSet0 = new DataSet(); string query0 = "SELECT * FROM documents"; connection.Open();
                using (SqlDataAdapter adapter0 = new SqlDataAdapter(query0, connection))
                {
                    adapter0.Fill(dataSet0, "All_Documents");
                }
                dataGridView1.DataSource = dataSet0.Tables["All_Documents"];   
            }
            else
            {
                string selectedValue = comviewdocid.SelectedItem.ToString(); searchid = selectedValue.Substring(1);
                DataSet dataSet0 = new DataSet(); string query0 = "SELECT * FROM documents WHERE did = @tranId "; connection.Open();
                using (SqlDataAdapter adapter0 = new SqlDataAdapter(query0, connection))
                {
                    adapter0.SelectCommand.Parameters.AddWithValue("@tranId", searchid); adapter0.Fill(dataSet0, "Document");
                }
                dataGridView1.DataSource = dataSet0.Tables["Document"]; 
            }
        }       
    }
}
