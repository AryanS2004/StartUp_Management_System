﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace STARTUP___MANAGEMENT___SYSTEM
{
    public partial class ProjectAdd1 : Form
    {
        private string connectionString = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\hp\Documents\Startup1.mdf;Integrated Security=True;Connect Timeout=30";
        private SqlConnection connection; private int atid; private string proid, searchid; private int teamid; 

        public ProjectAdd1()
        {
            InitializeComponent(); connection = new SqlConnection(connectionString);
        }

        private void ProjectAdd1_Load(object sender, EventArgs e)
        {
            PopulateComboBox();
        }

        private void PopulateComboBox()
        {
            try
            {
                connection.Open(); string countQuery = "SELECT COUNT(*) FROM projects;";
                SqlCommand countCmd = new SqlCommand(countQuery, connection); int recordCount = Convert.ToInt32(countCmd.ExecuteScalar());
                int nextEid = recordCount + 1; string formattedEid = "P" + nextEid; txtaddproid.Text = formattedEid;
                string query1 = "SELECT tid, tname FROM teams";
                using (SqlCommand command = new SqlCommand(query1, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        comaddtid.Items.Clear(); 

                        while (reader.Read())
                        {
                            int tid = reader.GetInt32(0); string tname = reader.GetString(1);
                            string displayString = "T" + tid + " (" + tname + ")";
                            comaddtid.Items.Add(displayString); commodtid.Items.Add(displayString);
                        }
                    }
                } 
                string query2 = "SELECT pid FROM projects;";
                using (SqlCommand command = new SqlCommand(query2, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            int pid = reader.GetInt32(0); commodproid.Items.Add("P" + pid); comviewpid.Items.Add("P" + pid);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        private void Savebtn_Click(object sender, EventArgs e)
        {
            string pname = txtaddproname.Text; int assbuget = Convert.ToInt32(txtaddbuget.Text); string protype = txtaddprotype.Text;
            int priority = Convert.ToInt32(numaddpriority.Value); string prodesc = txtadddesc.Text;
            DateTime proass = dateaddass.Value; DateTime prosub = dateaddsub.Value; gettid();
            DialogResult result = MessageBox.Show("Do you want to save the information?", "Save Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                try
                {
                    connection.Open();
                    string insertQuery = "INSERT INTO projects (pname, tid, proassbug, protype, propriority, prodesc, dateass, datelast, prostatus) " +
                                         "VALUES (@pname, @tid, @proassbug, @protype, @propriority, @prodesc, @dateass, @datelast, @prostatus)";
                    using (SqlCommand cmd = new SqlCommand(insertQuery, connection))
                    {
                        cmd.Parameters.AddWithValue("@pname", pname); cmd.Parameters.AddWithValue("@tid", atid);
                        cmd.Parameters.AddWithValue("@proassbug", assbuget); cmd.Parameters.AddWithValue("@protype", protype);
                        cmd.Parameters.AddWithValue("@propriority", priority); cmd.Parameters.AddWithValue("@prodesc", prodesc);
                        cmd.Parameters.AddWithValue("@dateass", proass); cmd.Parameters.AddWithValue("@datelast", prosub);
                        cmd.Parameters.AddWithValue("@prostatus", "Not Submitted"); cmd.ExecuteNonQuery();
                    }
                    MessageBox.Show("Information saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error saving data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    connection.Close();
                }
            }
        }

        private void gettid()
        {
            string stre1 = comaddtid.Text; int starte1 = stre1.IndexOf('T') + 1;
            int ende1 = stre1.IndexOf(' ', starte1);
            if (starte1 != -1 && ende1 != -1)
            {
                string e1str = stre1.Substring(starte1, ende1 - starte1); atid = Convert.ToInt32(e1str);
            }
        }

        private void commodproid_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedValue = commodproid.SelectedItem.ToString();
            proid = selectedValue.Substring(1); SearchDataInTables(proid);
        }

        private void SearchDataInTables(string tranId)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open(); string investQuery = "SELECT * FROM projects WHERE pid = '" + tranId + "'";
                using (SqlCommand investCommand = new SqlCommand(investQuery, connection))
                {
                    using (SqlDataReader investReader = investCommand.ExecuteReader())
                    {
                        if (investReader.Read())
                        {
                            commodtid.Text = investReader["pname"].ToString(); int teamid = Convert.ToInt32(investReader["tid"]);
                            txtmodproname.Text = teamid.ToString(); DateTime dateass; DateTime datelast;
                            if (DateTime.TryParse(investReader["dateass"].ToString(), out dateass))
                            {
                                datemodass.Value = dateass;
                            }
                            if (DateTime.TryParse(investReader["datelast"].ToString(), out datelast))
                            {
                                datemodsub.Value = datelast;
                            }
                            nummodass.Text = investReader["proassbug"].ToString(); txtmodprotype.Text = investReader["protype"].ToString();
                            nummodpri.Text = investReader["propriority"].ToString(); txtmoddesc.Text = investReader["prodesc"].ToString();
                            commodstat.Text = investReader["prostatus"].ToString(); return;
                        }
                    }
                }
            }
        }

        private void btnmodsave_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do you want to save the information?", "Save Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                string proname = txtmodproname.Text; string status = commodstat.Text; getids();
                string protype = txtmodprotype.Text; int prio = Convert.ToInt32(nummodpri.Value); string desc = txtmoddesc.Text;
                int assbug = Convert.ToInt32(nummodass.Value); DateTime dateass = datemodass.Value; DateTime datelast = datemodsub.Value;
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string updateQuery = "UPDATE projects SET pname = @pname, tid = @tid, proassbug = @proassbug, protype = @protype, " +
                        "propriority = @propriority, prodesc = @prodesc, dateass = @dateass , datelast = @datelast , prostatus = @prostatus WHERE pid = @pid";

                    using (SqlCommand updateCommand = new SqlCommand(updateQuery, connection))
                    {
                        updateCommand.Parameters.AddWithValue("@pname", proname); updateCommand.Parameters.AddWithValue("@tid", teamid);
                        updateCommand.Parameters.AddWithValue("@proassbug", assbug); updateCommand.Parameters.AddWithValue("@protype", protype);
                        updateCommand.Parameters.AddWithValue("@propriority", prio); updateCommand.Parameters.AddWithValue("@prodesc", desc);
                        updateCommand.Parameters.AddWithValue("@dateass", dateass); updateCommand.Parameters.AddWithValue("@datelast", datelast);
                        updateCommand.Parameters.AddWithValue("@prostatus", status); updateCommand.Parameters.AddWithValue("@pid", proid);
                        int rowsAffected = updateCommand.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Data updated.");
                        }
                        else
                        {
                            MessageBox.Show("No matching record found in loantran table.");
                        }
                    }
                }
            }
        }

        private void getids()
        {
            string leadstr = commodtid.Text; int startlead = leadstr.IndexOf('P') + 1;
            int endlead = leadstr.IndexOf(' ', startlead); if (startlead != -1 && endlead != -1)
            {
                string leadString = leadstr.Substring(startlead, endlead - startlead); teamid = Convert.ToInt32(leadString);
            }
        }

        private void btnviewdoc_Click(object sender, EventArgs e)
        {
            if (comviewpid.Text == "")
            {
                DataSet dataSet0 = new DataSet(); string query0 = "SELECT * FROM projects"; connection.Open();
                using (SqlDataAdapter adapter0 = new SqlDataAdapter(query0, connection))
                {
                    adapter0.Fill(dataSet0, "All_projects");
                }
                dataGridView1.DataSource = dataSet0.Tables["All_projects"]; connection.Close();
            }
            else
            {
                string selectedValue = comviewpid.SelectedItem.ToString(); searchid = selectedValue.Substring(1);
                DataSet dataSet0 = new DataSet(); string query0 = "SELECT * FROM projects WHERE pid = @tranId "; connection.Open();
                using (SqlDataAdapter adapter0 = new SqlDataAdapter(query0, connection))
                {
                    adapter0.SelectCommand.Parameters.AddWithValue("@tranId", searchid); adapter0.Fill(dataSet0, "Employee");
                }
                dataGridView1.DataSource = dataSet0.Tables["Employee"]; connection.Close();
            }
        }
    }
}