﻿namespace STARTUP___MANAGEMENT___SYSTEM
{
    partial class EmpAttend
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EmpAttend));
            this.txttofirst = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dateat = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.radiotono = new System.Windows.Forms.RadioButton();
            this.radiotoyes = new System.Windows.Forms.RadioButton();
            this.label9 = new System.Windows.Forms.Label();
            this.timetoin = new System.Windows.Forms.DateTimePicker();
            this.timetoout = new System.Windows.Forms.DateTimePicker();
            this.txttoover = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.btntosave = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.todayattend = new System.Windows.Forms.TabPage();
            this.txttorole = new System.Windows.Forms.TextBox();
            this.txttodep = new System.Windows.Forms.TextBox();
            this.comtoeid = new System.Windows.Forms.ComboBox();
            this.oldattend = new System.Windows.Forms.TabPage();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnviewemp = new System.Windows.Forms.Button();
            this.comvieweid = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.todayattend.SuspendLayout();
            this.oldattend.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // txttofirst
            // 
            this.txttofirst.Enabled = false;
            this.txttofirst.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttofirst.Location = new System.Drawing.Point(305, 118);
            this.txttofirst.Multiline = true;
            this.txttofirst.Name = "txttofirst";
            this.txttofirst.Size = new System.Drawing.Size(270, 37);
            this.txttofirst.TabIndex = 22;
            this.txttofirst.WordWrap = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(25, 291);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(141, 29);
            this.label5.TabIndex = 21;
            this.label5.Text = "Designation";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(25, 204);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(138, 29);
            this.label4.TabIndex = 20;
            this.label4.Text = "Department";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(802, 41);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 29);
            this.label3.TabIndex = 19;
            this.label3.Text = "Date";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(25, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(240, 29);
            this.label2.TabIndex = 18;
            this.label2.Text = "Employee Unique ID ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(25, 122);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 29);
            this.label1.TabIndex = 17;
            this.label1.Text = "Name";
            // 
            // dateat
            // 
            this.dateat.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateat.Location = new System.Drawing.Point(1026, 41);
            this.dateat.Name = "dateat";
            this.dateat.Size = new System.Drawing.Size(270, 34);
            this.dateat.TabIndex = 2;
            this.dateat.Value = new System.DateTime(2023, 11, 15, 0, 20, 47, 0);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(800, 289);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(127, 29);
            this.label7.TabIndex = 36;
            this.label7.Text = "Out - Time";
            this.label7.Visible = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(800, 204);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(108, 29);
            this.label8.TabIndex = 34;
            this.label8.Text = "In - Time";
            this.label8.Visible = false;
            // 
            // radiotono
            // 
            this.radiotono.AutoSize = true;
            this.radiotono.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radiotono.Location = new System.Drawing.Point(1230, 120);
            this.radiotono.Name = "radiotono";
            this.radiotono.Size = new System.Drawing.Size(66, 33);
            this.radiotono.TabIndex = 4;
            this.radiotono.TabStop = true;
            this.radiotono.Text = "No";
            this.radiotono.UseVisualStyleBackColor = true;
            this.radiotono.CheckedChanged += new System.EventHandler(this.noradio_CheckedChanged);
            // 
            // radiotoyes
            // 
            this.radiotoyes.AutoSize = true;
            this.radiotoyes.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radiotoyes.Location = new System.Drawing.Point(1026, 120);
            this.radiotoyes.Name = "radiotoyes";
            this.radiotoyes.Size = new System.Drawing.Size(76, 33);
            this.radiotoyes.TabIndex = 3;
            this.radiotoyes.TabStop = true;
            this.radiotoyes.Text = "Yes";
            this.radiotoyes.UseVisualStyleBackColor = true;
            this.radiotoyes.CheckedChanged += new System.EventHandler(this.yesradio_CheckedChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(800, 121);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(96, 29);
            this.label9.TabIndex = 39;
            this.label9.Text = "Present";
            // 
            // timetoin
            // 
            this.timetoin.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.timetoin.Location = new System.Drawing.Point(1026, 199);
            this.timetoin.Name = "timetoin";
            this.timetoin.Size = new System.Drawing.Size(270, 34);
            this.timetoin.TabIndex = 5;
            this.timetoin.Value = new System.DateTime(2023, 11, 15, 3, 24, 58, 0);
            this.timetoin.Visible = false;
            // 
            // timetoout
            // 
            this.timetoout.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.timetoout.Location = new System.Drawing.Point(1026, 284);
            this.timetoout.Name = "timetoout";
            this.timetoout.Size = new System.Drawing.Size(270, 34);
            this.timetoout.TabIndex = 6;
            this.timetoout.Value = new System.DateTime(2023, 11, 15, 3, 35, 41, 0);
            this.timetoout.Visible = false;
            // 
            // txttoover
            // 
            this.txttoover.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttoover.Location = new System.Drawing.Point(1026, 372);
            this.txttoover.Multiline = true;
            this.txttoover.Name = "txttoover";
            this.txttoover.Size = new System.Drawing.Size(270, 37);
            this.txttoover.TabIndex = 7;
            this.txttoover.Visible = false;
            this.txttoover.WordWrap = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(802, 375);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(182, 29);
            this.label10.TabIndex = 44;
            this.label10.Text = "Overtime / early";
            this.label10.Visible = false;
            // 
            // btntosave
            // 
            this.btntosave.BackColor = System.Drawing.Color.Lime;
            this.btntosave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btntosave.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btntosave.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntosave.Location = new System.Drawing.Point(618, 487);
            this.btntosave.Name = "btntosave";
            this.btntosave.Size = new System.Drawing.Size(170, 63);
            this.btntosave.TabIndex = 8;
            this.btntosave.Text = "Save";
            this.btntosave.UseVisualStyleBackColor = false;
            this.btntosave.Click += new System.EventHandler(this.Savebtn_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.todayattend);
            this.tabControl1.Controls.Add(this.oldattend);
            this.tabControl1.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.HotTrack = true;
            this.tabControl1.Location = new System.Drawing.Point(12, 34);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1335, 634);
            this.tabControl1.TabIndex = 48;
            // 
            // todayattend
            // 
            this.todayattend.BackColor = System.Drawing.Color.Wheat;
            this.todayattend.Controls.Add(this.txttorole);
            this.todayattend.Controls.Add(this.txttodep);
            this.todayattend.Controls.Add(this.comtoeid);
            this.todayattend.Controls.Add(this.label2);
            this.todayattend.Controls.Add(this.label1);
            this.todayattend.Controls.Add(this.btntosave);
            this.todayattend.Controls.Add(this.label3);
            this.todayattend.Controls.Add(this.txttoover);
            this.todayattend.Controls.Add(this.label4);
            this.todayattend.Controls.Add(this.label10);
            this.todayattend.Controls.Add(this.label5);
            this.todayattend.Controls.Add(this.timetoout);
            this.todayattend.Controls.Add(this.txttofirst);
            this.todayattend.Controls.Add(this.timetoin);
            this.todayattend.Controls.Add(this.radiotono);
            this.todayattend.Controls.Add(this.radiotoyes);
            this.todayattend.Controls.Add(this.label9);
            this.todayattend.Controls.Add(this.label7);
            this.todayattend.Controls.Add(this.label8);
            this.todayattend.Controls.Add(this.dateat);
            this.todayattend.Location = new System.Drawing.Point(4, 35);
            this.todayattend.Name = "todayattend";
            this.todayattend.Padding = new System.Windows.Forms.Padding(3);
            this.todayattend.Size = new System.Drawing.Size(1327, 595);
            this.todayattend.TabIndex = 0;
            this.todayattend.Text = "Todays Attendence";
            // 
            // txttorole
            // 
            this.txttorole.Enabled = false;
            this.txttorole.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttorole.Location = new System.Drawing.Point(305, 287);
            this.txttorole.Multiline = true;
            this.txttorole.Name = "txttorole";
            this.txttorole.Size = new System.Drawing.Size(270, 37);
            this.txttorole.TabIndex = 49;
            this.txttorole.WordWrap = false;
            // 
            // txttodep
            // 
            this.txttodep.Enabled = false;
            this.txttodep.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttodep.Location = new System.Drawing.Point(305, 201);
            this.txttodep.Multiline = true;
            this.txttodep.Name = "txttodep";
            this.txttodep.Size = new System.Drawing.Size(270, 37);
            this.txttodep.TabIndex = 48;
            this.txttodep.WordWrap = false;
            // 
            // comtoeid
            // 
            this.comtoeid.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.comtoeid.FormattingEnabled = true;
            this.comtoeid.Location = new System.Drawing.Point(305, 38);
            this.comtoeid.Name = "comtoeid";
            this.comtoeid.Size = new System.Drawing.Size(270, 37);
            this.comtoeid.TabIndex = 1;
            this.comtoeid.SelectedIndexChanged += new System.EventHandler(this.comtoeid_SelectedIndexChanged);
            // 
            // oldattend
            // 
            this.oldattend.BackColor = System.Drawing.Color.LightCoral;
            this.oldattend.Controls.Add(this.dataGridView1);
            this.oldattend.Controls.Add(this.btnviewemp);
            this.oldattend.Controls.Add(this.comvieweid);
            this.oldattend.Controls.Add(this.label15);
            this.oldattend.Location = new System.Drawing.Point(4, 35);
            this.oldattend.Name = "oldattend";
            this.oldattend.Padding = new System.Windows.Forms.Padding(3);
            this.oldattend.Size = new System.Drawing.Size(1327, 595);
            this.oldattend.TabIndex = 1;
            this.oldattend.Text = "Attendence Sheet";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(38, 144);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1159, 410);
            this.dataGridView1.TabIndex = 24;
            this.dataGridView1.Visible = false;
            // 
            // btnviewemp
            // 
            this.btnviewemp.BackColor = System.Drawing.Color.Orange;
            this.btnviewemp.Font = new System.Drawing.Font("Microsoft Tai Le", 12F);
            this.btnviewemp.Location = new System.Drawing.Point(562, 39);
            this.btnviewemp.Name = "btnviewemp";
            this.btnviewemp.Size = new System.Drawing.Size(126, 61);
            this.btnviewemp.TabIndex = 22;
            this.btnviewemp.Text = "Search";
            this.btnviewemp.UseVisualStyleBackColor = false;
            this.btnviewemp.Click += new System.EventHandler(this.btnviewemp_Click);
            // 
            // comvieweid
            // 
            this.comvieweid.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.comvieweid.FormattingEnabled = true;
            this.comvieweid.Location = new System.Drawing.Point(248, 49);
            this.comvieweid.Name = "comvieweid";
            this.comvieweid.Size = new System.Drawing.Size(270, 37);
            this.comvieweid.TabIndex = 21;
            this.comvieweid.SelectedIndexChanged += new System.EventHandler(this.comvieweid_SelectedIndexChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(33, 52);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(151, 29);
            this.label15.TabIndex = 23;
            this.label15.Text = "Employee ID";
            // 
            // EmpAttend
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.MediumOrchid;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1924, 1055);
            this.Controls.Add(this.tabControl1);
            this.DoubleBuffered = true;
            this.Name = "EmpAttend";
            this.ShowIcon = false;
            this.Text = "Attendance Management";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.EmpAttend_Load);
            this.tabControl1.ResumeLayout(false);
            this.todayattend.ResumeLayout(false);
            this.todayattend.PerformLayout();
            this.oldattend.ResumeLayout(false);
            this.oldattend.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txttofirst;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dateat;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.RadioButton radiotono;
        private System.Windows.Forms.RadioButton radiotoyes;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker timetoin;
        private System.Windows.Forms.DateTimePicker timetoout;
        private System.Windows.Forms.TextBox txttoover;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btntosave;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage todayattend;
        private System.Windows.Forms.TabPage oldattend;
        private System.Windows.Forms.ComboBox comtoeid;
        private System.Windows.Forms.TextBox txttorole;
        private System.Windows.Forms.TextBox txttodep;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnviewemp;
        private System.Windows.Forms.ComboBox comvieweid;
        private System.Windows.Forms.Label label15;
    }
}