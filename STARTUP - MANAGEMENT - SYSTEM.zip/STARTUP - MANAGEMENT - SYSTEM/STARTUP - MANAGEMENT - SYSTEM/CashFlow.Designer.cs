﻿namespace STARTUP___MANAGEMENT___SYSTEM
{
    partial class CashFlow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CashFlow));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.newtrans = new System.Windows.Forms.TabPage();
            this.pannewinvest = new System.Windows.Forms.Panel();
            this.btnnewisave = new System.Windows.Forms.Button();
            this.label24 = new System.Windows.Forms.Label();
            this.txtnewidesc = new System.Windows.Forms.TextBox();
            this.txtnewiam = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.datenewiinvest = new System.Windows.Forms.DateTimePicker();
            this.label10 = new System.Windows.Forms.Label();
            this.txtnewiphone = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtnewiname = new System.Windows.Forms.TextBox();
            this.pannewl = new System.Windows.Forms.Panel();
            this.txtnewlampay = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.txtnewlintrest = new System.Windows.Forms.TextBox();
            this.label52 = new System.Windows.Forms.Label();
            this.txtnewlproname = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.txtnewlam = new System.Windows.Forms.TextBox();
            this.txtnewloandesc = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.btnnewlsave = new System.Windows.Forms.Button();
            this.label54 = new System.Windows.Forms.Label();
            this.datenewlret = new System.Windows.Forms.DateTimePicker();
            this.datenewltake = new System.Windows.Forms.DateTimePicker();
            this.label56 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtnewtid = new System.Windows.Forms.TextBox();
            this.comnewttype = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.modtrans = new System.Windows.Forms.TabPage();
            this.panmodloan = new System.Windows.Forms.Panel();
            this.comlmodstatus = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtlmopay = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtlmoinvest = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtlmoname = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.txtlmoamtake = new System.Windows.Forms.TextBox();
            this.txtlmoddesc = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.btnmodloan = new System.Windows.Forms.Button();
            this.label25 = new System.Windows.Forms.Label();
            this.datelmoret = new System.Windows.Forms.DateTimePicker();
            this.datelmotake = new System.Windows.Forms.DateTimePicker();
            this.label26 = new System.Windows.Forms.Label();
            this.panmodinvest = new System.Windows.Forms.Panel();
            this.btnimodsave = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txtimoddesc = new System.Windows.Forms.TextBox();
            this.txtimodinamt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.dateimodinvest = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.txtimodcontact = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtimodname = new System.Windows.Forms.TextBox();
            this.btnmoddel = new System.Windows.Forms.Button();
            this.commodproid = new System.Windows.Forms.ComboBox();
            this.label100 = new System.Windows.Forms.Label();
            this.viewtrans = new System.Windows.Forms.TabPage();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnviewtran = new System.Windows.Forms.Button();
            this.comviewtid = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.cominstatus = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.newtrans.SuspendLayout();
            this.pannewinvest.SuspendLayout();
            this.pannewl.SuspendLayout();
            this.modtrans.SuspendLayout();
            this.panmodloan.SuspendLayout();
            this.panmodinvest.SuspendLayout();
            this.viewtrans.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.newtrans);
            this.tabControl1.Controls.Add(this.modtrans);
            this.tabControl1.Controls.Add(this.viewtrans);
            this.tabControl1.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(26, 38);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1321, 648);
            this.tabControl1.TabIndex = 97;
            // 
            // newtrans
            // 
            this.newtrans.BackColor = System.Drawing.Color.Wheat;
            this.newtrans.Controls.Add(this.pannewinvest);
            this.newtrans.Controls.Add(this.pannewl);
            this.newtrans.Controls.Add(this.label2);
            this.newtrans.Controls.Add(this.txtnewtid);
            this.newtrans.Controls.Add(this.comnewttype);
            this.newtrans.Controls.Add(this.label6);
            this.newtrans.Location = new System.Drawing.Point(4, 35);
            this.newtrans.Name = "newtrans";
            this.newtrans.Padding = new System.Windows.Forms.Padding(3);
            this.newtrans.Size = new System.Drawing.Size(1313, 609);
            this.newtrans.TabIndex = 0;
            this.newtrans.Text = "New Transaction";
            // 
            // pannewinvest
            // 
            this.pannewinvest.BackColor = System.Drawing.Color.Wheat;
            this.pannewinvest.Controls.Add(this.btnnewisave);
            this.pannewinvest.Controls.Add(this.label24);
            this.pannewinvest.Controls.Add(this.txtnewidesc);
            this.pannewinvest.Controls.Add(this.txtnewiam);
            this.pannewinvest.Controls.Add(this.label21);
            this.pannewinvest.Controls.Add(this.label20);
            this.pannewinvest.Controls.Add(this.datenewiinvest);
            this.pannewinvest.Controls.Add(this.label10);
            this.pannewinvest.Controls.Add(this.txtnewiphone);
            this.pannewinvest.Controls.Add(this.label1);
            this.pannewinvest.Controls.Add(this.txtnewiname);
            this.pannewinvest.Location = new System.Drawing.Point(0, 93);
            this.pannewinvest.Name = "pannewinvest";
            this.pannewinvest.Size = new System.Drawing.Size(1327, 516);
            this.pannewinvest.TabIndex = 97;
            this.pannewinvest.Visible = false;
            // 
            // btnnewisave
            // 
            this.btnnewisave.BackColor = System.Drawing.Color.Lime;
            this.btnnewisave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnnewisave.Font = new System.Drawing.Font("Microsoft Tai Le", 12F);
            this.btnnewisave.Location = new System.Drawing.Point(634, 391);
            this.btnnewisave.Name = "btnnewisave";
            this.btnnewisave.Size = new System.Drawing.Size(126, 54);
            this.btnnewisave.TabIndex = 95;
            this.btnnewisave.Text = "Save";
            this.btnnewisave.UseVisualStyleBackColor = false;
            this.btnnewisave.Click += new System.EventHandler(this.btnnewisave_Click);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.Transparent;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(34, 233);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(267, 29);
            this.label24.TabIndex = 94;
            this.label24.Text = "Transaction Description";
            // 
            // txtnewidesc
            // 
            this.txtnewidesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnewidesc.Location = new System.Drawing.Point(299, 227);
            this.txtnewidesc.Multiline = true;
            this.txtnewidesc.Name = "txtnewidesc";
            this.txtnewidesc.Size = new System.Drawing.Size(413, 110);
            this.txtnewidesc.TabIndex = 93;
            // 
            // txtnewiam
            // 
            this.txtnewiam.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnewiam.Location = new System.Drawing.Point(883, 136);
            this.txtnewiam.Multiline = true;
            this.txtnewiam.Name = "txtnewiam";
            this.txtnewiam.Size = new System.Drawing.Size(270, 37);
            this.txtnewiam.TabIndex = 91;
            this.txtnewiam.WordWrap = false;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.Transparent;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(656, 139);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(190, 29);
            this.label21.TabIndex = 92;
            this.label21.Text = "Invested Amount";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.Transparent;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(34, 139);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(210, 29);
            this.label20.TabIndex = 86;
            this.label20.Text = "Date of Investment";
            // 
            // datenewiinvest
            // 
            this.datenewiinvest.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datenewiinvest.Location = new System.Drawing.Point(299, 139);
            this.datenewiinvest.Name = "datenewiinvest";
            this.datenewiinvest.Size = new System.Drawing.Size(270, 34);
            this.datenewiinvest.TabIndex = 85;
            this.datenewiinvest.Value = new System.DateTime(2023, 11, 15, 0, 20, 47, 0);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(656, 51);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(174, 29);
            this.label10.TabIndex = 80;
            this.label10.Text = "Contact Deatils";
            // 
            // txtnewiphone
            // 
            this.txtnewiphone.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnewiphone.Location = new System.Drawing.Point(882, 48);
            this.txtnewiphone.Multiline = true;
            this.txtnewiphone.Name = "txtnewiphone";
            this.txtnewiphone.Size = new System.Drawing.Size(270, 37);
            this.txtnewiphone.TabIndex = 79;
            this.txtnewiphone.WordWrap = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(34, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(194, 29);
            this.label1.TabIndex = 78;
            this.label1.Text = "Name of Investor";
            // 
            // txtnewiname
            // 
            this.txtnewiname.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnewiname.Location = new System.Drawing.Point(299, 48);
            this.txtnewiname.Multiline = true;
            this.txtnewiname.Name = "txtnewiname";
            this.txtnewiname.Size = new System.Drawing.Size(270, 37);
            this.txtnewiname.TabIndex = 3;
            this.txtnewiname.WordWrap = false;
            // 
            // pannewl
            // 
            this.pannewl.Controls.Add(this.txtnewlampay);
            this.pannewl.Controls.Add(this.label53);
            this.pannewl.Controls.Add(this.txtnewlintrest);
            this.pannewl.Controls.Add(this.label52);
            this.pannewl.Controls.Add(this.txtnewlproname);
            this.pannewl.Controls.Add(this.label50);
            this.pannewl.Controls.Add(this.label55);
            this.pannewl.Controls.Add(this.txtnewlam);
            this.pannewl.Controls.Add(this.txtnewloandesc);
            this.pannewl.Controls.Add(this.label51);
            this.pannewl.Controls.Add(this.btnnewlsave);
            this.pannewl.Controls.Add(this.label54);
            this.pannewl.Controls.Add(this.datenewlret);
            this.pannewl.Controls.Add(this.datenewltake);
            this.pannewl.Controls.Add(this.label56);
            this.pannewl.Location = new System.Drawing.Point(0, 93);
            this.pannewl.Name = "pannewl";
            this.pannewl.Size = new System.Drawing.Size(1327, 516);
            this.pannewl.TabIndex = 98;
            this.pannewl.Visible = false;
            // 
            // txtnewlampay
            // 
            this.txtnewlampay.Enabled = false;
            this.txtnewlampay.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnewlampay.Location = new System.Drawing.Point(881, 142);
            this.txtnewlampay.Multiline = true;
            this.txtnewlampay.Name = "txtnewlampay";
            this.txtnewlampay.Size = new System.Drawing.Size(270, 37);
            this.txtnewlampay.TabIndex = 6;
            this.txtnewlampay.WordWrap = false;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.BackColor = System.Drawing.Color.Transparent;
            this.label53.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(655, 145);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(176, 29);
            this.label53.TabIndex = 120;
            this.label53.Text = "Amount To Pay";
            // 
            // txtnewlintrest
            // 
            this.txtnewlintrest.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnewlintrest.Location = new System.Drawing.Point(298, 142);
            this.txtnewlintrest.Multiline = true;
            this.txtnewlintrest.Name = "txtnewlintrest";
            this.txtnewlintrest.Size = new System.Drawing.Size(270, 37);
            this.txtnewlintrest.TabIndex = 5;
            this.txtnewlintrest.WordWrap = false;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.BackColor = System.Drawing.Color.Transparent;
            this.label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(33, 145);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(134, 29);
            this.label52.TabIndex = 118;
            this.label52.Text = "Intrest Rate";
            // 
            // txtnewlproname
            // 
            this.txtnewlproname.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnewlproname.Location = new System.Drawing.Point(298, 61);
            this.txtnewlproname.Multiline = true;
            this.txtnewlproname.Name = "txtnewlproname";
            this.txtnewlproname.Size = new System.Drawing.Size(270, 37);
            this.txtnewlproname.TabIndex = 3;
            this.txtnewlproname.WordWrap = false;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.BackColor = System.Drawing.Color.Transparent;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(33, 64);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(175, 29);
            this.label50.TabIndex = 115;
            this.label50.Text = "Provider Name";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.BackColor = System.Drawing.Color.Transparent;
            this.label55.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(655, 224);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(194, 29);
            this.label55.TabIndex = 111;
            this.label55.Text = "Loan Description";
            // 
            // txtnewlam
            // 
            this.txtnewlam.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnewlam.Location = new System.Drawing.Point(881, 61);
            this.txtnewlam.Multiline = true;
            this.txtnewlam.Name = "txtnewlam";
            this.txtnewlam.Size = new System.Drawing.Size(270, 37);
            this.txtnewlam.TabIndex = 4;
            this.txtnewlam.WordWrap = false;
            // 
            // txtnewloandesc
            // 
            this.txtnewloandesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnewloandesc.Location = new System.Drawing.Point(881, 221);
            this.txtnewloandesc.Multiline = true;
            this.txtnewloandesc.Name = "txtnewloandesc";
            this.txtnewloandesc.Size = new System.Drawing.Size(413, 132);
            this.txtnewloandesc.TabIndex = 9;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.BackColor = System.Drawing.Color.Transparent;
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(655, 64);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(184, 29);
            this.label51.TabIndex = 114;
            this.label51.Text = "Amount Of Loan";
            // 
            // btnnewlsave
            // 
            this.btnnewlsave.BackColor = System.Drawing.Color.Lime;
            this.btnnewlsave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnnewlsave.Font = new System.Drawing.Font("Microsoft Tai Le", 12F);
            this.btnnewlsave.Location = new System.Drawing.Point(633, 402);
            this.btnnewlsave.Name = "btnnewlsave";
            this.btnnewlsave.Size = new System.Drawing.Size(126, 54);
            this.btnnewlsave.TabIndex = 10;
            this.btnnewlsave.Text = "Save";
            this.btnnewlsave.UseVisualStyleBackColor = false;
            this.btnnewlsave.Click += new System.EventHandler(this.btnnewlsave_Click);
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.BackColor = System.Drawing.Color.Transparent;
            this.label54.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(33, 224);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(228, 29);
            this.label54.TabIndex = 112;
            this.label54.Text = "Date of Loan Taking";
            // 
            // datenewlret
            // 
            this.datenewlret.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datenewlret.Location = new System.Drawing.Point(298, 305);
            this.datenewlret.Name = "datenewlret";
            this.datenewlret.Size = new System.Drawing.Size(270, 34);
            this.datenewlret.TabIndex = 8;
            this.datenewlret.Value = new System.DateTime(2023, 11, 15, 0, 20, 47, 0);
            // 
            // datenewltake
            // 
            this.datenewltake.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datenewltake.Location = new System.Drawing.Point(298, 224);
            this.datenewltake.Name = "datenewltake";
            this.datenewltake.Size = new System.Drawing.Size(270, 34);
            this.datenewltake.TabIndex = 7;
            this.datenewltake.Value = new System.DateTime(2023, 11, 15, 0, 20, 47, 0);
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.BackColor = System.Drawing.Color.Transparent;
            this.label56.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.Location = new System.Drawing.Point(33, 308);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(230, 29);
            this.label56.TabIndex = 113;
            this.label56.Text = "Last Date for Return ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(34, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(168, 29);
            this.label2.TabIndex = 78;
            this.label2.Text = "Transaction ID";
            // 
            // txtnewtid
            // 
            this.txtnewtid.Cursor = System.Windows.Forms.Cursors.No;
            this.txtnewtid.Enabled = false;
            this.txtnewtid.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnewtid.Location = new System.Drawing.Point(299, 32);
            this.txtnewtid.Multiline = true;
            this.txtnewtid.Name = "txtnewtid";
            this.txtnewtid.Size = new System.Drawing.Size(270, 37);
            this.txtnewtid.TabIndex = 1;
            this.txtnewtid.WordWrap = false;
            // 
            // comnewttype
            // 
            this.comnewttype.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comnewttype.FormattingEnabled = true;
            this.comnewttype.Items.AddRange(new object[] {
            "Investment",
            "Loan"});
            this.comnewttype.Location = new System.Drawing.Point(882, 35);
            this.comnewttype.Name = "comnewttype";
            this.comnewttype.Size = new System.Drawing.Size(270, 37);
            this.comnewttype.TabIndex = 2;
            this.comnewttype.SelectedIndexChanged += new System.EventHandler(this.comnewttype_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(656, 38);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(200, 29);
            this.label6.TabIndex = 88;
            this.label6.Text = "Transaction Type";
            // 
            // modtrans
            // 
            this.modtrans.BackColor = System.Drawing.Color.LightCoral;
            this.modtrans.Controls.Add(this.panmodloan);
            this.modtrans.Controls.Add(this.panmodinvest);
            this.modtrans.Controls.Add(this.btnmoddel);
            this.modtrans.Controls.Add(this.commodproid);
            this.modtrans.Controls.Add(this.label100);
            this.modtrans.Location = new System.Drawing.Point(4, 35);
            this.modtrans.Name = "modtrans";
            this.modtrans.Padding = new System.Windows.Forms.Padding(3);
            this.modtrans.Size = new System.Drawing.Size(1313, 609);
            this.modtrans.TabIndex = 1;
            this.modtrans.Text = "Modify Transaction";
            // 
            // panmodloan
            // 
            this.panmodloan.BackColor = System.Drawing.Color.LightCoral;
            this.panmodloan.Controls.Add(this.comlmodstatus);
            this.panmodloan.Controls.Add(this.label11);
            this.panmodloan.Controls.Add(this.txtlmopay);
            this.panmodloan.Controls.Add(this.label15);
            this.panmodloan.Controls.Add(this.txtlmoinvest);
            this.panmodloan.Controls.Add(this.label16);
            this.panmodloan.Controls.Add(this.txtlmoname);
            this.panmodloan.Controls.Add(this.label17);
            this.panmodloan.Controls.Add(this.label18);
            this.panmodloan.Controls.Add(this.txtlmoamtake);
            this.panmodloan.Controls.Add(this.txtlmoddesc);
            this.panmodloan.Controls.Add(this.label19);
            this.panmodloan.Controls.Add(this.btnmodloan);
            this.panmodloan.Controls.Add(this.label25);
            this.panmodloan.Controls.Add(this.datelmoret);
            this.panmodloan.Controls.Add(this.datelmotake);
            this.panmodloan.Controls.Add(this.label26);
            this.panmodloan.Location = new System.Drawing.Point(0, 91);
            this.panmodloan.Name = "panmodloan";
            this.panmodloan.Size = new System.Drawing.Size(1327, 516);
            this.panmodloan.TabIndex = 146;
            this.panmodloan.Visible = false;
            // 
            // comlmodstatus
            // 
            this.comlmodstatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.comlmodstatus.FormattingEnabled = true;
            this.comlmodstatus.Items.AddRange(new object[] {
            "Uncleared",
            "Cleared"});
            this.comlmodstatus.Location = new System.Drawing.Point(881, 319);
            this.comlmodstatus.Name = "comlmodstatus";
            this.comlmodstatus.Size = new System.Drawing.Size(270, 37);
            this.comlmodstatus.TabIndex = 10;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(655, 320);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(138, 29);
            this.label11.TabIndex = 121;
            this.label11.Text = "Loan Status";
            // 
            // txtlmopay
            // 
            this.txtlmopay.Enabled = false;
            this.txtlmopay.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtlmopay.Location = new System.Drawing.Point(881, 142);
            this.txtlmopay.Multiline = true;
            this.txtlmopay.Name = "txtlmopay";
            this.txtlmopay.Size = new System.Drawing.Size(270, 37);
            this.txtlmopay.TabIndex = 6;
            this.txtlmopay.WordWrap = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(655, 145);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(176, 29);
            this.label15.TabIndex = 120;
            this.label15.Text = "Amount To Pay";
            // 
            // txtlmoinvest
            // 
            this.txtlmoinvest.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtlmoinvest.Location = new System.Drawing.Point(298, 142);
            this.txtlmoinvest.Multiline = true;
            this.txtlmoinvest.Name = "txtlmoinvest";
            this.txtlmoinvest.Size = new System.Drawing.Size(270, 37);
            this.txtlmoinvest.TabIndex = 5;
            this.txtlmoinvest.WordWrap = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(33, 145);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(134, 29);
            this.label16.TabIndex = 118;
            this.label16.Text = "Intrest Rate";
            // 
            // txtlmoname
            // 
            this.txtlmoname.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtlmoname.Location = new System.Drawing.Point(298, 61);
            this.txtlmoname.Multiline = true;
            this.txtlmoname.Name = "txtlmoname";
            this.txtlmoname.Size = new System.Drawing.Size(270, 37);
            this.txtlmoname.TabIndex = 3;
            this.txtlmoname.WordWrap = false;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(33, 64);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(175, 29);
            this.label17.TabIndex = 115;
            this.label17.Text = "Provider Name";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(655, 224);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(194, 29);
            this.label18.TabIndex = 111;
            this.label18.Text = "Loan Description";
            // 
            // txtlmoamtake
            // 
            this.txtlmoamtake.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtlmoamtake.Location = new System.Drawing.Point(881, 61);
            this.txtlmoamtake.Multiline = true;
            this.txtlmoamtake.Name = "txtlmoamtake";
            this.txtlmoamtake.Size = new System.Drawing.Size(270, 37);
            this.txtlmoamtake.TabIndex = 4;
            this.txtlmoamtake.WordWrap = false;
            // 
            // txtlmoddesc
            // 
            this.txtlmoddesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtlmoddesc.Location = new System.Drawing.Point(881, 221);
            this.txtlmoddesc.Multiline = true;
            this.txtlmoddesc.Name = "txtlmoddesc";
            this.txtlmoddesc.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.txtlmoddesc.Size = new System.Drawing.Size(370, 72);
            this.txtlmoddesc.TabIndex = 8;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(655, 64);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(184, 29);
            this.label19.TabIndex = 114;
            this.label19.Text = "Amount Of Loan";
            // 
            // btnmodloan
            // 
            this.btnmodloan.BackColor = System.Drawing.Color.Lime;
            this.btnmodloan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnmodloan.Font = new System.Drawing.Font("Microsoft Tai Le", 12F);
            this.btnmodloan.Location = new System.Drawing.Point(633, 402);
            this.btnmodloan.Name = "btnmodloan";
            this.btnmodloan.Size = new System.Drawing.Size(126, 54);
            this.btnmodloan.TabIndex = 11;
            this.btnmodloan.Text = "Save";
            this.btnmodloan.UseVisualStyleBackColor = false;
            this.btnmodloan.Click += new System.EventHandler(this.btnmodloan_Click);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.Transparent;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(33, 224);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(228, 29);
            this.label25.TabIndex = 112;
            this.label25.Text = "Date of Loan Taking";
            // 
            // datelmoret
            // 
            this.datelmoret.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datelmoret.Location = new System.Drawing.Point(298, 317);
            this.datelmoret.Name = "datelmoret";
            this.datelmoret.Size = new System.Drawing.Size(270, 34);
            this.datelmoret.TabIndex = 9;
            this.datelmoret.Value = new System.DateTime(2023, 11, 15, 0, 20, 47, 0);
            // 
            // datelmotake
            // 
            this.datelmotake.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datelmotake.Location = new System.Drawing.Point(298, 224);
            this.datelmotake.Name = "datelmotake";
            this.datelmotake.Size = new System.Drawing.Size(270, 34);
            this.datelmotake.TabIndex = 7;
            this.datelmotake.Value = new System.DateTime(2023, 11, 15, 0, 20, 47, 0);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.Color.Transparent;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(33, 320);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(230, 29);
            this.label26.TabIndex = 113;
            this.label26.Text = "Last Date for Return ";
            // 
            // panmodinvest
            // 
            this.panmodinvest.BackColor = System.Drawing.Color.LightCoral;
            this.panmodinvest.Controls.Add(this.cominstatus);
            this.panmodinvest.Controls.Add(this.label12);
            this.panmodinvest.Controls.Add(this.btnimodsave);
            this.panmodinvest.Controls.Add(this.label3);
            this.panmodinvest.Controls.Add(this.txtimoddesc);
            this.panmodinvest.Controls.Add(this.txtimodinamt);
            this.panmodinvest.Controls.Add(this.label4);
            this.panmodinvest.Controls.Add(this.label5);
            this.panmodinvest.Controls.Add(this.dateimodinvest);
            this.panmodinvest.Controls.Add(this.label7);
            this.panmodinvest.Controls.Add(this.txtimodcontact);
            this.panmodinvest.Controls.Add(this.label8);
            this.panmodinvest.Controls.Add(this.txtimodname);
            this.panmodinvest.Location = new System.Drawing.Point(0, 93);
            this.panmodinvest.Name = "panmodinvest";
            this.panmodinvest.Size = new System.Drawing.Size(1327, 516);
            this.panmodinvest.TabIndex = 145;
            this.panmodinvest.Visible = false;
            // 
            // btnimodsave
            // 
            this.btnimodsave.BackColor = System.Drawing.Color.Lime;
            this.btnimodsave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnimodsave.Font = new System.Drawing.Font("Microsoft Tai Le", 12F);
            this.btnimodsave.Location = new System.Drawing.Point(634, 409);
            this.btnimodsave.Name = "btnimodsave";
            this.btnimodsave.Size = new System.Drawing.Size(126, 54);
            this.btnimodsave.TabIndex = 8;
            this.btnimodsave.Text = "Save";
            this.btnimodsave.UseVisualStyleBackColor = false;
            this.btnimodsave.Click += new System.EventHandler(this.btnimodsave_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(34, 233);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(217, 29);
            this.label3.TabIndex = 94;
            this.label3.Text = "Project Description";
            // 
            // txtimoddesc
            // 
            this.txtimoddesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtimoddesc.Location = new System.Drawing.Point(299, 227);
            this.txtimoddesc.Multiline = true;
            this.txtimoddesc.Name = "txtimoddesc";
            this.txtimoddesc.Size = new System.Drawing.Size(335, 105);
            this.txtimoddesc.TabIndex = 7;
            // 
            // txtimodinamt
            // 
            this.txtimodinamt.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtimodinamt.Location = new System.Drawing.Point(883, 136);
            this.txtimodinamt.Multiline = true;
            this.txtimodinamt.Name = "txtimodinamt";
            this.txtimodinamt.Size = new System.Drawing.Size(270, 37);
            this.txtimodinamt.TabIndex = 6;
            this.txtimodinamt.WordWrap = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(656, 139);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(190, 29);
            this.label4.TabIndex = 92;
            this.label4.Text = "Invested Amount";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(34, 139);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(210, 29);
            this.label5.TabIndex = 86;
            this.label5.Text = "Date of Investment";
            // 
            // dateimodinvest
            // 
            this.dateimodinvest.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateimodinvest.Location = new System.Drawing.Point(299, 139);
            this.dateimodinvest.Name = "dateimodinvest";
            this.dateimodinvest.Size = new System.Drawing.Size(270, 34);
            this.dateimodinvest.TabIndex = 5;
            this.dateimodinvest.Value = new System.DateTime(2023, 11, 15, 0, 20, 47, 0);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(656, 51);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(174, 29);
            this.label7.TabIndex = 80;
            this.label7.Text = "Contact Deatils";
            // 
            // txtimodcontact
            // 
            this.txtimodcontact.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtimodcontact.Location = new System.Drawing.Point(882, 48);
            this.txtimodcontact.Multiline = true;
            this.txtimodcontact.Name = "txtimodcontact";
            this.txtimodcontact.Size = new System.Drawing.Size(270, 37);
            this.txtimodcontact.TabIndex = 4;
            this.txtimodcontact.WordWrap = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(34, 51);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(194, 29);
            this.label8.TabIndex = 78;
            this.label8.Text = "Name of Investor";
            // 
            // txtimodname
            // 
            this.txtimodname.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtimodname.Location = new System.Drawing.Point(299, 48);
            this.txtimodname.Multiline = true;
            this.txtimodname.Name = "txtimodname";
            this.txtimodname.Size = new System.Drawing.Size(270, 37);
            this.txtimodname.TabIndex = 3;
            this.txtimodname.WordWrap = false;
            // 
            // btnmoddel
            // 
            this.btnmoddel.BackColor = System.Drawing.Color.Red;
            this.btnmoddel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnmoddel.Font = new System.Drawing.Font("Microsoft Tai Le", 12F);
            this.btnmoddel.Location = new System.Drawing.Point(1090, 34);
            this.btnmoddel.Name = "btnmoddel";
            this.btnmoddel.Size = new System.Drawing.Size(204, 48);
            this.btnmoddel.TabIndex = 100;
            this.btnmoddel.Text = "Remove Transaction";
            this.btnmoddel.UseVisualStyleBackColor = false;
            this.btnmoddel.Visible = false;
            this.btnmoddel.Click += new System.EventHandler(this.btnmoddel_Click);
            // 
            // commodproid
            // 
            this.commodproid.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.commodproid.FormattingEnabled = true;
            this.commodproid.Location = new System.Drawing.Point(298, 41);
            this.commodproid.Name = "commodproid";
            this.commodproid.Size = new System.Drawing.Size(270, 37);
            this.commodproid.TabIndex = 1;
            this.commodproid.SelectedIndexChanged += new System.EventHandler(this.commodproid_SelectedIndexChanged);
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label100.Location = new System.Drawing.Point(34, 44);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(258, 29);
            this.label100.TabIndex = 121;
            this.label100.Text = "Choose Transaction ID";
            // 
            // viewtrans
            // 
            this.viewtrans.BackColor = System.Drawing.Color.Sienna;
            this.viewtrans.Controls.Add(this.dataGridView1);
            this.viewtrans.Controls.Add(this.btnviewtran);
            this.viewtrans.Controls.Add(this.comviewtid);
            this.viewtrans.Controls.Add(this.label9);
            this.viewtrans.Location = new System.Drawing.Point(4, 35);
            this.viewtrans.Name = "viewtrans";
            this.viewtrans.Size = new System.Drawing.Size(1313, 609);
            this.viewtrans.TabIndex = 2;
            this.viewtrans.Text = "View Details";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.BurlyWood;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Cursor = System.Windows.Forms.Cursors.Help;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Bookman Old Style", 12F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.Location = new System.Drawing.Point(49, 143);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1099, 410);
            this.dataGridView1.TabIndex = 24;
            this.dataGridView1.Visible = false;
            // 
            // btnviewtran
            // 
            this.btnviewtran.BackColor = System.Drawing.Color.Orange;
            this.btnviewtran.Font = new System.Drawing.Font("Microsoft Tai Le", 12F);
            this.btnviewtran.Location = new System.Drawing.Point(573, 44);
            this.btnviewtran.Name = "btnviewtran";
            this.btnviewtran.Size = new System.Drawing.Size(126, 61);
            this.btnviewtran.TabIndex = 22;
            this.btnviewtran.Text = "Search";
            this.btnviewtran.UseVisualStyleBackColor = false;
            this.btnviewtran.Click += new System.EventHandler(this.btnviewtran_Click);
            // 
            // comviewtid
            // 
            this.comviewtid.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.comviewtid.FormattingEnabled = true;
            this.comviewtid.Location = new System.Drawing.Point(259, 54);
            this.comviewtid.Name = "comviewtid";
            this.comviewtid.Size = new System.Drawing.Size(270, 37);
            this.comviewtid.TabIndex = 21;
            this.comviewtid.SelectedIndexChanged += new System.EventHandler(this.comviewtid_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(44, 57);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(168, 29);
            this.label9.TabIndex = 23;
            this.label9.Text = "Transaction ID";
            // 
            // cominstatus
            // 
            this.cominstatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.cominstatus.FormattingEnabled = true;
            this.cominstatus.Items.AddRange(new object[] {
            "Uncleared",
            "Cleared"});
            this.cominstatus.Location = new System.Drawing.Point(882, 232);
            this.cominstatus.Name = "cominstatus";
            this.cominstatus.Size = new System.Drawing.Size(270, 37);
            this.cominstatus.TabIndex = 122;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(656, 233);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(138, 29);
            this.label12.TabIndex = 123;
            this.label12.Text = "Loan Status";
            // 
            // CashFlow
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.Coral;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1924, 1055);
            this.Controls.Add(this.tabControl1);
            this.DoubleBuffered = true;
            this.Name = "CashFlow";
            this.ShowIcon = false;
            this.Text = "CashFlow";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.CashFlow_Load);
            this.tabControl1.ResumeLayout(false);
            this.newtrans.ResumeLayout(false);
            this.newtrans.PerformLayout();
            this.pannewinvest.ResumeLayout(false);
            this.pannewinvest.PerformLayout();
            this.pannewl.ResumeLayout(false);
            this.pannewl.PerformLayout();
            this.modtrans.ResumeLayout(false);
            this.modtrans.PerformLayout();
            this.panmodloan.ResumeLayout(false);
            this.panmodloan.PerformLayout();
            this.panmodinvest.ResumeLayout(false);
            this.panmodinvest.PerformLayout();
            this.viewtrans.ResumeLayout(false);
            this.viewtrans.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage newtrans;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtnewtid;
        private System.Windows.Forms.ComboBox comnewttype;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TabPage modtrans;
        private System.Windows.Forms.Button btnmoddel;
        private System.Windows.Forms.ComboBox commodproid;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Panel pannewinvest;
        private System.Windows.Forms.Button btnnewisave;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtnewidesc;
        private System.Windows.Forms.TextBox txtnewiam;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.DateTimePicker datenewiinvest;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtnewiphone;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtnewiname;
        private System.Windows.Forms.Panel pannewl;
        private System.Windows.Forms.TextBox txtnewlampay;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox txtnewlintrest;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TextBox txtnewlproname;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox txtnewlam;
        private System.Windows.Forms.TextBox txtnewloandesc;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Button btnnewlsave;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.DateTimePicker datenewlret;
        private System.Windows.Forms.DateTimePicker datenewltake;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Panel panmodinvest;
        private System.Windows.Forms.Panel panmodloan;
        private System.Windows.Forms.TextBox txtlmopay;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtlmoinvest;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtlmoname;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtlmoamtake;
        private System.Windows.Forms.TextBox txtlmoddesc;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button btnmodloan;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.DateTimePicker datelmoret;
        private System.Windows.Forms.DateTimePicker datelmotake;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Button btnimodsave;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtimoddesc;
        private System.Windows.Forms.TextBox txtimodinamt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dateimodinvest;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtimodcontact;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtimodname;
        private System.Windows.Forms.TabPage viewtrans;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnviewtran;
        private System.Windows.Forms.ComboBox comviewtid;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox comlmodstatus;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cominstatus;
        private System.Windows.Forms.Label label12;
    }
}