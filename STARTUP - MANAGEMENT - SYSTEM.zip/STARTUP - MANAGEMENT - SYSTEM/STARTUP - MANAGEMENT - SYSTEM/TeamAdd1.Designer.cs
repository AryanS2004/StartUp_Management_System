﻿namespace STARTUP___MANAGEMENT___SYSTEM
{
    partial class TeamAdd1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TeamAdd1));
            this.label6 = new System.Windows.Forms.Label();
            this.comalead = new System.Windows.Forms.ComboBox();
            this.txtaname = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtatid = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.comae1 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.comae2 = new System.Windows.Forms.ComboBox();
            this.comae3 = new System.Windows.Forms.ComboBox();
            this.comae4 = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.comae5 = new System.Windows.Forms.ComboBox();
            this.txtadisc = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.comaskill = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.comaspec = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.btnasave = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.adddoc = new System.Windows.Forms.TabPage();
            this.moddoc = new System.Windows.Forms.TabPage();
            this.txtmodtname = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.comspec = new System.Windows.Forms.ComboBox();
            this.lab3 = new System.Windows.Forms.Label();
            this.comskill = new System.Windows.Forms.ComboBox();
            this.lab2 = new System.Windows.Forms.Label();
            this.txtdec = new System.Windows.Forms.TextBox();
            this.lab4 = new System.Windows.Forms.Label();
            this.lab9 = new System.Windows.Forms.Label();
            this.com5em = new System.Windows.Forms.ComboBox();
            this.lab8 = new System.Windows.Forms.Label();
            this.lab7 = new System.Windows.Forms.Label();
            this.lab6 = new System.Windows.Forms.Label();
            this.com4em = new System.Windows.Forms.ComboBox();
            this.com3em = new System.Windows.Forms.ComboBox();
            this.com2em = new System.Windows.Forms.ComboBox();
            this.com1em = new System.Windows.Forms.ComboBox();
            this.lab5 = new System.Windows.Forms.Label();
            this.comsupid = new System.Windows.Forms.ComboBox();
            this.lab1 = new System.Windows.Forms.Label();
            this.commodeid = new System.Windows.Forms.ComboBox();
            this.btnmodrem = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.btnmodsave = new System.Windows.Forms.Button();
            this.Viewdoc = new System.Windows.Forms.TabPage();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnviewdoc = new System.Windows.Forms.Button();
            this.comviewdocid = new System.Windows.Forms.ComboBox();
            this.label29 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.adddoc.SuspendLayout();
            this.moddoc.SuspendLayout();
            this.Viewdoc.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(9, 170);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(179, 29);
            this.label6.TabIndex = 46;
            this.label6.Text = "Choose Leader";
            // 
            // comalead
            // 
            this.comalead.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comalead.FormattingEnabled = true;
            this.comalead.Location = new System.Drawing.Point(274, 167);
            this.comalead.Name = "comalead";
            this.comalead.Size = new System.Drawing.Size(270, 37);
            this.comalead.TabIndex = 48;
            // 
            // txtaname
            // 
            this.txtaname.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaname.Location = new System.Drawing.Point(687, 96);
            this.txtaname.Multiline = true;
            this.txtaname.Name = "txtaname";
            this.txtaname.Size = new System.Drawing.Size(270, 37);
            this.txtaname.TabIndex = 50;
            this.txtaname.WordWrap = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(449, 100);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(147, 29);
            this.label1.TabIndex = 49;
            this.label1.Text = "Team Name";
            // 
            // txtatid
            // 
            this.txtatid.Cursor = System.Windows.Forms.Cursors.No;
            this.txtatid.Enabled = false;
            this.txtatid.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtatid.Location = new System.Drawing.Point(687, 30);
            this.txtatid.Multiline = true;
            this.txtatid.Name = "txtatid";
            this.txtatid.Size = new System.Drawing.Size(270, 37);
            this.txtatid.TabIndex = 52;
            this.txtatid.WordWrap = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(449, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 29);
            this.label2.TabIndex = 51;
            this.label2.Text = "Team ID";
            // 
            // comae1
            // 
            this.comae1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comae1.FormattingEnabled = true;
            this.comae1.Location = new System.Drawing.Point(1016, 162);
            this.comae1.Name = "comae1";
            this.comae1.Size = new System.Drawing.Size(270, 37);
            this.comae1.TabIndex = 54;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(714, 169);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(207, 29);
            this.label3.TabIndex = 53;
            this.label3.Text = "1st Subordinate Id";
            // 
            // comae2
            // 
            this.comae2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comae2.FormattingEnabled = true;
            this.comae2.Location = new System.Drawing.Point(1016, 226);
            this.comae2.Name = "comae2";
            this.comae2.Size = new System.Drawing.Size(270, 37);
            this.comae2.TabIndex = 56;
            // 
            // comae3
            // 
            this.comae3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comae3.FormattingEnabled = true;
            this.comae3.Location = new System.Drawing.Point(1016, 285);
            this.comae3.Name = "comae3";
            this.comae3.Size = new System.Drawing.Size(270, 37);
            this.comae3.TabIndex = 58;
            // 
            // comae4
            // 
            this.comae4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comae4.FormattingEnabled = true;
            this.comae4.Location = new System.Drawing.Point(1016, 350);
            this.comae4.Name = "comae4";
            this.comae4.Size = new System.Drawing.Size(270, 37);
            this.comae4.TabIndex = 60;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(714, 229);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(216, 29);
            this.label4.TabIndex = 61;
            this.label4.Text = "2nd Subordinate Id";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(714, 288);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(211, 29);
            this.label5.TabIndex = 62;
            this.label5.Text = "3rd Subordinate Id";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(714, 353);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(208, 29);
            this.label7.TabIndex = 63;
            this.label7.Text = "4th Subordinate Id";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(714, 416);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(208, 29);
            this.label8.TabIndex = 65;
            this.label8.Text = "5th Subordinate Id";
            // 
            // comae5
            // 
            this.comae5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comae5.FormattingEnabled = true;
            this.comae5.Location = new System.Drawing.Point(1016, 413);
            this.comae5.Name = "comae5";
            this.comae5.Size = new System.Drawing.Size(270, 37);
            this.comae5.TabIndex = 64;
            // 
            // txtadisc
            // 
            this.txtadisc.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtadisc.Location = new System.Drawing.Point(274, 347);
            this.txtadisc.Multiline = true;
            this.txtadisc.Name = "txtadisc";
            this.txtadisc.Size = new System.Drawing.Size(413, 132);
            this.txtadisc.TabIndex = 67;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(9, 353);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(204, 29);
            this.label9.TabIndex = 66;
            this.label9.Text = "Team Description";
            // 
            // comaskill
            // 
            this.comaskill.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comaskill.FormattingEnabled = true;
            this.comaskill.Location = new System.Drawing.Point(274, 285);
            this.comaskill.Name = "comaskill";
            this.comaskill.Size = new System.Drawing.Size(270, 37);
            this.comaskill.TabIndex = 69;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(9, 229);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(198, 29);
            this.label10.TabIndex = 68;
            this.label10.Text = "Teams Speciality";
            // 
            // comaspec
            // 
            this.comaspec.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comaspec.FormattingEnabled = true;
            this.comaspec.Location = new System.Drawing.Point(274, 226);
            this.comaspec.Name = "comaspec";
            this.comaspec.Size = new System.Drawing.Size(270, 37);
            this.comaspec.TabIndex = 71;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(9, 288);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(140, 29);
            this.label11.TabIndex = 70;
            this.label11.Text = "Teams Skill";
            // 
            // btnasave
            // 
            this.btnasave.BackColor = System.Drawing.Color.Lime;
            this.btnasave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnasave.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnasave.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnasave.Location = new System.Drawing.Point(567, 514);
            this.btnasave.Name = "btnasave";
            this.btnasave.Size = new System.Drawing.Size(170, 62);
            this.btnasave.TabIndex = 75;
            this.btnasave.Text = "Save";
            this.btnasave.UseVisualStyleBackColor = false;
            this.btnasave.Click += new System.EventHandler(this.Savebtn_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.adddoc);
            this.tabControl1.Controls.Add(this.moddoc);
            this.tabControl1.Controls.Add(this.Viewdoc);
            this.tabControl1.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(24, 36);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1317, 648);
            this.tabControl1.TabIndex = 76;
            // 
            // adddoc
            // 
            this.adddoc.BackColor = System.Drawing.Color.RosyBrown;
            this.adddoc.Controls.Add(this.txtadisc);
            this.adddoc.Controls.Add(this.btnasave);
            this.adddoc.Controls.Add(this.label6);
            this.adddoc.Controls.Add(this.comalead);
            this.adddoc.Controls.Add(this.comaspec);
            this.adddoc.Controls.Add(this.label1);
            this.adddoc.Controls.Add(this.label11);
            this.adddoc.Controls.Add(this.txtaname);
            this.adddoc.Controls.Add(this.comaskill);
            this.adddoc.Controls.Add(this.label2);
            this.adddoc.Controls.Add(this.label10);
            this.adddoc.Controls.Add(this.txtatid);
            this.adddoc.Controls.Add(this.label3);
            this.adddoc.Controls.Add(this.label9);
            this.adddoc.Controls.Add(this.comae1);
            this.adddoc.Controls.Add(this.label8);
            this.adddoc.Controls.Add(this.comae2);
            this.adddoc.Controls.Add(this.comae5);
            this.adddoc.Controls.Add(this.comae3);
            this.adddoc.Controls.Add(this.label7);
            this.adddoc.Controls.Add(this.comae4);
            this.adddoc.Controls.Add(this.label5);
            this.adddoc.Controls.Add(this.label4);
            this.adddoc.Location = new System.Drawing.Point(4, 35);
            this.adddoc.Name = "adddoc";
            this.adddoc.Padding = new System.Windows.Forms.Padding(3);
            this.adddoc.Size = new System.Drawing.Size(1309, 609);
            this.adddoc.TabIndex = 0;
            this.adddoc.Text = "Add";
            // 
            // moddoc
            // 
            this.moddoc.BackColor = System.Drawing.Color.Pink;
            this.moddoc.Controls.Add(this.txtmodtname);
            this.moddoc.Controls.Add(this.label15);
            this.moddoc.Controls.Add(this.comspec);
            this.moddoc.Controls.Add(this.lab3);
            this.moddoc.Controls.Add(this.comskill);
            this.moddoc.Controls.Add(this.lab2);
            this.moddoc.Controls.Add(this.txtdec);
            this.moddoc.Controls.Add(this.lab4);
            this.moddoc.Controls.Add(this.lab9);
            this.moddoc.Controls.Add(this.com5em);
            this.moddoc.Controls.Add(this.lab8);
            this.moddoc.Controls.Add(this.lab7);
            this.moddoc.Controls.Add(this.lab6);
            this.moddoc.Controls.Add(this.com4em);
            this.moddoc.Controls.Add(this.com3em);
            this.moddoc.Controls.Add(this.com2em);
            this.moddoc.Controls.Add(this.com1em);
            this.moddoc.Controls.Add(this.lab5);
            this.moddoc.Controls.Add(this.comsupid);
            this.moddoc.Controls.Add(this.lab1);
            this.moddoc.Controls.Add(this.commodeid);
            this.moddoc.Controls.Add(this.btnmodrem);
            this.moddoc.Controls.Add(this.label12);
            this.moddoc.Controls.Add(this.btnmodsave);
            this.moddoc.Location = new System.Drawing.Point(4, 35);
            this.moddoc.Name = "moddoc";
            this.moddoc.Padding = new System.Windows.Forms.Padding(3);
            this.moddoc.Size = new System.Drawing.Size(1309, 609);
            this.moddoc.TabIndex = 1;
            this.moddoc.Text = "Modify";
            // 
            // txtmodtname
            // 
            this.txtmodtname.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmodtname.Location = new System.Drawing.Point(1003, 23);
            this.txtmodtname.Multiline = true;
            this.txtmodtname.Name = "txtmodtname";
            this.txtmodtname.Size = new System.Drawing.Size(270, 37);
            this.txtmodtname.TabIndex = 85;
            this.txtmodtname.WordWrap = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(727, 26);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(147, 29);
            this.label15.TabIndex = 114;
            this.label15.Text = "Team Name";
            // 
            // comspec
            // 
            this.comspec.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comspec.FormattingEnabled = true;
            this.comspec.Location = new System.Drawing.Point(288, 184);
            this.comspec.Name = "comspec";
            this.comspec.Size = new System.Drawing.Size(270, 37);
            this.comspec.TabIndex = 113;
            // 
            // lab3
            // 
            this.lab3.AutoSize = true;
            this.lab3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab3.Location = new System.Drawing.Point(23, 272);
            this.lab3.Name = "lab3";
            this.lab3.Size = new System.Drawing.Size(140, 29);
            this.lab3.TabIndex = 112;
            this.lab3.Text = "Teams Skill";
            // 
            // comskill
            // 
            this.comskill.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comskill.FormattingEnabled = true;
            this.comskill.Location = new System.Drawing.Point(288, 269);
            this.comskill.Name = "comskill";
            this.comskill.Size = new System.Drawing.Size(270, 37);
            this.comskill.TabIndex = 111;
            // 
            // lab2
            // 
            this.lab2.AutoSize = true;
            this.lab2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab2.Location = new System.Drawing.Point(23, 187);
            this.lab2.Name = "lab2";
            this.lab2.Size = new System.Drawing.Size(198, 29);
            this.lab2.TabIndex = 110;
            this.lab2.Text = "Teams Speciality";
            // 
            // txtdec
            // 
            this.txtdec.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdec.Location = new System.Drawing.Point(288, 352);
            this.txtdec.Multiline = true;
            this.txtdec.Name = "txtdec";
            this.txtdec.Size = new System.Drawing.Size(413, 132);
            this.txtdec.TabIndex = 109;
            // 
            // lab4
            // 
            this.lab4.AutoSize = true;
            this.lab4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab4.Location = new System.Drawing.Point(23, 358);
            this.lab4.Name = "lab4";
            this.lab4.Size = new System.Drawing.Size(204, 29);
            this.lab4.TabIndex = 108;
            this.lab4.Text = "Team Description";
            // 
            // lab9
            // 
            this.lab9.AutoSize = true;
            this.lab9.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab9.Location = new System.Drawing.Point(727, 445);
            this.lab9.Name = "lab9";
            this.lab9.Size = new System.Drawing.Size(208, 29);
            this.lab9.TabIndex = 107;
            this.lab9.Text = "5th Subordinate Id";
            // 
            // com5em
            // 
            this.com5em.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.com5em.FormattingEnabled = true;
            this.com5em.Location = new System.Drawing.Point(1003, 442);
            this.com5em.Name = "com5em";
            this.com5em.Size = new System.Drawing.Size(270, 37);
            this.com5em.TabIndex = 106;
            // 
            // lab8
            // 
            this.lab8.AutoSize = true;
            this.lab8.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab8.Location = new System.Drawing.Point(727, 358);
            this.lab8.Name = "lab8";
            this.lab8.Size = new System.Drawing.Size(208, 29);
            this.lab8.TabIndex = 105;
            this.lab8.Text = "4th Subordinate Id";
            // 
            // lab7
            // 
            this.lab7.AutoSize = true;
            this.lab7.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab7.Location = new System.Drawing.Point(727, 272);
            this.lab7.Name = "lab7";
            this.lab7.Size = new System.Drawing.Size(211, 29);
            this.lab7.TabIndex = 104;
            this.lab7.Text = "3rd Subordinate Id";
            // 
            // lab6
            // 
            this.lab6.AutoSize = true;
            this.lab6.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab6.Location = new System.Drawing.Point(727, 187);
            this.lab6.Name = "lab6";
            this.lab6.Size = new System.Drawing.Size(216, 29);
            this.lab6.TabIndex = 103;
            this.lab6.Text = "2nd Subordinate Id";
            // 
            // com4em
            // 
            this.com4em.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.com4em.FormattingEnabled = true;
            this.com4em.Location = new System.Drawing.Point(1003, 355);
            this.com4em.Name = "com4em";
            this.com4em.Size = new System.Drawing.Size(270, 37);
            this.com4em.TabIndex = 102;
            // 
            // com3em
            // 
            this.com3em.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.com3em.FormattingEnabled = true;
            this.com3em.Location = new System.Drawing.Point(1003, 269);
            this.com3em.Name = "com3em";
            this.com3em.Size = new System.Drawing.Size(270, 37);
            this.com3em.TabIndex = 101;
            // 
            // com2em
            // 
            this.com2em.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.com2em.FormattingEnabled = true;
            this.com2em.Location = new System.Drawing.Point(1003, 184);
            this.com2em.Name = "com2em";
            this.com2em.Size = new System.Drawing.Size(270, 37);
            this.com2em.TabIndex = 100;
            // 
            // com1em
            // 
            this.com1em.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.com1em.FormattingEnabled = true;
            this.com1em.Location = new System.Drawing.Point(1003, 98);
            this.com1em.Name = "com1em";
            this.com1em.Size = new System.Drawing.Size(270, 37);
            this.com1em.TabIndex = 99;
            // 
            // lab5
            // 
            this.lab5.AutoSize = true;
            this.lab5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab5.Location = new System.Drawing.Point(727, 105);
            this.lab5.Name = "lab5";
            this.lab5.Size = new System.Drawing.Size(207, 29);
            this.lab5.TabIndex = 98;
            this.lab5.Text = "1st Subordinate Id";
            // 
            // comsupid
            // 
            this.comsupid.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comsupid.FormattingEnabled = true;
            this.comsupid.Location = new System.Drawing.Point(288, 103);
            this.comsupid.Name = "comsupid";
            this.comsupid.Size = new System.Drawing.Size(270, 37);
            this.comsupid.TabIndex = 97;
            // 
            // lab1
            // 
            this.lab1.AutoSize = true;
            this.lab1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab1.Location = new System.Drawing.Point(23, 106);
            this.lab1.Name = "lab1";
            this.lab1.Size = new System.Drawing.Size(179, 29);
            this.lab1.TabIndex = 96;
            this.lab1.Text = "Choose Leader";
            // 
            // commodeid
            // 
            this.commodeid.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.commodeid.FormattingEnabled = true;
            this.commodeid.Location = new System.Drawing.Point(288, 23);
            this.commodeid.Name = "commodeid";
            this.commodeid.Size = new System.Drawing.Size(270, 37);
            this.commodeid.TabIndex = 84;
            this.commodeid.SelectedIndexChanged += new System.EventHandler(this.commodeid_SelectedIndexChanged);
            // 
            // btnmodrem
            // 
            this.btnmodrem.BackColor = System.Drawing.Color.Red;
            this.btnmodrem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnmodrem.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnmodrem.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmodrem.Location = new System.Drawing.Point(1045, 523);
            this.btnmodrem.Name = "btnmodrem";
            this.btnmodrem.Size = new System.Drawing.Size(183, 50);
            this.btnmodrem.TabIndex = 83;
            this.btnmodrem.Text = "Remove Team";
            this.btnmodrem.UseVisualStyleBackColor = false;
            this.btnmodrem.Click += new System.EventHandler(this.btnmodrem_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(23, 26);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(187, 29);
            this.label12.TabIndex = 81;
            this.label12.Text = "Search Team ID";
            // 
            // btnmodsave
            // 
            this.btnmodsave.BackColor = System.Drawing.Color.Lime;
            this.btnmodsave.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnmodsave.Font = new System.Drawing.Font("Microsoft Tai Le", 12F);
            this.btnmodsave.Location = new System.Drawing.Point(663, 523);
            this.btnmodsave.Name = "btnmodsave";
            this.btnmodsave.Size = new System.Drawing.Size(126, 61);
            this.btnmodsave.TabIndex = 35;
            this.btnmodsave.Text = "Save";
            this.btnmodsave.UseVisualStyleBackColor = false;
            this.btnmodsave.Click += new System.EventHandler(this.btnmodsave_Click);
            // 
            // Viewdoc
            // 
            this.Viewdoc.BackColor = System.Drawing.Color.HotPink;
            this.Viewdoc.Controls.Add(this.dataGridView1);
            this.Viewdoc.Controls.Add(this.btnviewdoc);
            this.Viewdoc.Controls.Add(this.comviewdocid);
            this.Viewdoc.Controls.Add(this.label29);
            this.Viewdoc.Location = new System.Drawing.Point(4, 35);
            this.Viewdoc.Name = "Viewdoc";
            this.Viewdoc.Size = new System.Drawing.Size(1309, 609);
            this.Viewdoc.TabIndex = 2;
            this.Viewdoc.Text = "View";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(31, 141);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1205, 410);
            this.dataGridView1.TabIndex = 20;
            this.dataGridView1.Visible = false;
            // 
            // btnviewdoc
            // 
            this.btnviewdoc.BackColor = System.Drawing.Color.Orange;
            this.btnviewdoc.Font = new System.Drawing.Font("Microsoft Tai Le", 12F);
            this.btnviewdoc.Location = new System.Drawing.Point(530, 34);
            this.btnviewdoc.Name = "btnviewdoc";
            this.btnviewdoc.Size = new System.Drawing.Size(126, 61);
            this.btnviewdoc.TabIndex = 2;
            this.btnviewdoc.Text = "Search";
            this.btnviewdoc.UseVisualStyleBackColor = false;
            this.btnviewdoc.Click += new System.EventHandler(this.btnviewdoc_Click);
            // 
            // comviewdocid
            // 
            this.comviewdocid.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.comviewdocid.FormattingEnabled = true;
            this.comviewdocid.Location = new System.Drawing.Point(165, 45);
            this.comviewdocid.Name = "comviewdocid";
            this.comviewdocid.Size = new System.Drawing.Size(270, 37);
            this.comviewdocid.TabIndex = 1;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(26, 48);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(105, 29);
            this.label29.TabIndex = 17;
            this.label29.Text = "Team ID";
            // 
            // TeamAdd1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.Tan;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1924, 1055);
            this.Controls.Add(this.tabControl1);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "TeamAdd1";
            this.ShowIcon = false;
            this.Text = "Team Management";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.TeamAdd1_Load);
            this.tabControl1.ResumeLayout(false);
            this.adddoc.ResumeLayout(false);
            this.adddoc.PerformLayout();
            this.moddoc.ResumeLayout(false);
            this.moddoc.PerformLayout();
            this.Viewdoc.ResumeLayout(false);
            this.Viewdoc.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comalead;
        private System.Windows.Forms.TextBox txtaname;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtatid;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comae1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comae2;
        private System.Windows.Forms.ComboBox comae3;
        private System.Windows.Forms.ComboBox comae4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comae5;
        private System.Windows.Forms.TextBox txtadisc;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox comaskill;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox comaspec;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnasave;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage adddoc;
        private System.Windows.Forms.TabPage moddoc;
        private System.Windows.Forms.Button btnmodsave;
        private System.Windows.Forms.TabPage Viewdoc;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnviewdoc;
        private System.Windows.Forms.ComboBox comviewdocid;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.ComboBox commodeid;
        private System.Windows.Forms.Button btnmodrem;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox comspec;
        private System.Windows.Forms.Label lab3;
        private System.Windows.Forms.ComboBox comskill;
        private System.Windows.Forms.Label lab2;
        private System.Windows.Forms.TextBox txtdec;
        private System.Windows.Forms.Label lab4;
        private System.Windows.Forms.Label lab9;
        private System.Windows.Forms.ComboBox com5em;
        private System.Windows.Forms.Label lab8;
        private System.Windows.Forms.Label lab7;
        private System.Windows.Forms.Label lab6;
        private System.Windows.Forms.ComboBox com4em;
        private System.Windows.Forms.ComboBox com3em;
        private System.Windows.Forms.ComboBox com2em;
        private System.Windows.Forms.ComboBox com1em;
        private System.Windows.Forms.Label lab5;
        private System.Windows.Forms.ComboBox comsupid;
        private System.Windows.Forms.Label lab1;
        private System.Windows.Forms.TextBox txtmodtname;
        private System.Windows.Forms.Label label15;
    }
}