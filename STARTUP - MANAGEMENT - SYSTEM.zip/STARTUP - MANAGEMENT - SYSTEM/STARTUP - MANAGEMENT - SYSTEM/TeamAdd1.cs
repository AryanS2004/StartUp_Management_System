﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace STARTUP___MANAGEMENT___SYSTEM
{
    public partial class TeamAdd1 : Form
    {
        private bool isInformationSaved = false;
        private string connectionString = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\hp\Documents\Startup1.mdf;Integrated Security=True;Connect Timeout=30";
        private SqlConnection connection; private int leadid, em1, em2, em3, em4, em5, searchid; private string modtid;
        public TeamAdd1()
        {
            InitializeComponent(); connection = new SqlConnection(connectionString);
        }

        private void backbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void EmBasic_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!isInformationSaved)
            {
                DialogResult result = MessageBox.Show("Do you want to close the page? Unsaved information will be lost.", "Close Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.No)
                {
                    e.Cancel = true;
                }
            }
        }

        private void Savebtn_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtaname.Text) && !string.IsNullOrEmpty(txtadisc.Text) && !string.IsNullOrEmpty(comae1.Text) &&
                !string.IsNullOrEmpty(comae2.Text) && !string.IsNullOrEmpty(comae3.Text) && !string.IsNullOrEmpty(comae4.Text) && !string.IsNullOrEmpty(comaspec.Text) &&
                !string.IsNullOrEmpty(comae5.Text) && !string.IsNullOrEmpty(comalead.Text) && !string.IsNullOrEmpty(comaskill.Text))
            {
                getnumbers();
                DialogResult result = MessageBox.Show("Do you want to save the information?", "Save Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    try
                    {
                        connection.Open();
                        string insertQuery = "INSERT INTO teams (tname, supid, emp1id, emp2id, emp3id, emp4id, emp5id, teamspec, teamskill, teamdesc) " +
                                             "VALUES (@tname, @supid, @emp1id, @emp2id, @emp3id, @emp4id, @emp5id, @teamspec, @teamskill, @teamdesc)";
                        using (SqlCommand cmd = new SqlCommand(insertQuery, connection))
                        {
                            cmd.Parameters.AddWithValue("@tname", txtaname.Text.Trim()); cmd.Parameters.AddWithValue("@supid", leadid);
                            cmd.Parameters.AddWithValue("@emp1id", em1); cmd.Parameters.AddWithValue("@emp2id", em2);
                            cmd.Parameters.AddWithValue("@emp3id", em3); cmd.Parameters.AddWithValue("@emp4id", em4);
                            cmd.Parameters.AddWithValue("@emp5id", em5); cmd.Parameters.AddWithValue("@teamspec", comaspec.Text.Trim());
                            cmd.Parameters.AddWithValue("@teamskill", comaskill.Text.Trim());
                            cmd.Parameters.AddWithValue("@teamdesc", txtadisc.Text.Trim()); cmd.ExecuteNonQuery();
                        }
                        isInformationSaved = true; MessageBox.Show("Information saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error saving data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    finally
                    {
                        connection.Close();
                    }
                }
            }
            else
            {
                MessageBox.Show("Information not saved.", "Cancelled", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void TeamAdd1_Load(object sender, EventArgs e)
        {
            PopulateComboBox();
        }

        private void PopulateComboBox()
        {
            try
            {
                connection.Open(); string query = "SELECT Eid, fname, lname FROM Empbasic";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        comalead.Items.Clear(); comae1.Items.Clear(); comae2.Items.Clear();
                        comae4.Items.Clear(); comae5.Items.Clear(); comae3.Items.Clear();
                        while (reader.Read())
                        {
                            int eid = reader.GetInt32(0); string firstName = reader.GetString(1);
                            string lastName = reader.GetString(2); string displayString = "E"+eid+" ("+firstName+" "+lastName+")";
                            comalead.Items.Add(displayString); comae1.Items.Add(displayString); comae2.Items.Add(displayString);
                            comae3.Items.Add(displayString); comae4.Items.Add(displayString); comae5.Items.Add(displayString);
                            comsupid.Items.Add(displayString); com1em.Items.Add(displayString); com2em.Items.Add(displayString);
                            com3em.Items.Add(displayString); com4em.Items.Add(displayString); com5em.Items.Add(displayString);
                        }
                    }
                }
                string query2 = "SELECT tid FROM teams;";
                using (SqlCommand command = new SqlCommand(query2, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            int tid = reader.GetInt32(0); commodeid.Items.Add("T" + tid); comviewdocid.Items.Add("T" + tid);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        private void getnumbers()
        {
            leadid = ExtractIdFromComboBox(comalead.Text); em1 = ExtractIdFromComboBox(comae1.Text);
            em2 = ExtractIdFromComboBox(comae2.Text); em3 = ExtractIdFromComboBox(comae3.Text);
            em4 = ExtractIdFromComboBox(comae4.Text); em5 = ExtractIdFromComboBox(comae5.Text);
        }
            
        private void btnmodsave_Click(object sender, EventArgs e)
        {
             DialogResult result = MessageBox.Show("Do you want to save the information?", "Save Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
             if (result == DialogResult.Yes)
             {
                 getids(); using (SqlConnection connection = new SqlConnection(connectionString))
                 {
                     connection.Open(); string updateQuery = "UPDATE teams SET tname = @tname, supid = @supid, emp1id = @emp1id, emp2id = @emp2id, emp3id = @emp3id, " +
                         "emp4id = @emp4id, emp5id = @emp5id, teamspec = @teamspec, teamskill = @teamskill, teamdesc = @teamdesc WHERE tid = @tid";

                     using (SqlCommand cmd = new SqlCommand(updateQuery, connection))
                     {
                         cmd.Parameters.AddWithValue("@tname", txtmodtname.Text.Trim()); cmd.Parameters.AddWithValue("@supid", leadid);
                         cmd.Parameters.AddWithValue("@emp1id", em1); cmd.Parameters.AddWithValue("@emp2id", em2);
                         cmd.Parameters.AddWithValue("@emp3id", em3); cmd.Parameters.AddWithValue("@emp4id", em4);
                         cmd.Parameters.AddWithValue("@emp5id", em5); cmd.Parameters.AddWithValue("@teamspec", comspec.Text.Trim());
                         cmd.Parameters.AddWithValue("@teamskill", comskill.Text.Trim()); cmd.Parameters.AddWithValue("@teamdesc", txtdec.Text.Trim());
                         cmd.Parameters.AddWithValue("@tid", modtid); int rowsAffected = cmd.ExecuteNonQuery();
                         if (rowsAffected > 0)
                         {
                             MessageBox.Show("Data updated.");
                         }
                         else
                         {
                             MessageBox.Show("No matching record found in loantran table.");
                         }
                     }
                 }
             }
        }

        private void commodeid_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedValue = commodeid.SelectedItem.ToString();
            modtid = selectedValue.Substring(1); SearchDataInTables(modtid);
        }

        private void SearchDataInTables(string tranId)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open(); string investQuery = "SELECT * FROM teams WHERE tid = '" + tranId + "'";
                using (SqlCommand investCommand = new SqlCommand(investQuery, connection))
                {
                    using (SqlDataReader investReader = investCommand.ExecuteReader())
                    {
                        if (investReader.Read())
                        {
                            txtmodtname.Text = investReader["tname"].ToString(); comsupid.Text = investReader["supid"].ToString();
                            com1em.Text = investReader["emp1id"].ToString(); com2em.Text = investReader["emp2id"].ToString();
                            com3em.Text = investReader["emp3id"].ToString(); com4em.Text = investReader["emp4id"].ToString();
                            com5em.Text = investReader["emp5id"].ToString(); comspec.Text = investReader["teamspec"].ToString();
                            comskill.Text = investReader["teamskill"].ToString(); txtdec.Text = investReader["teamdesc"].ToString(); return;
                        }
                    }
                }
            }
        }

        private void getids()
        {
            leadid = ExtractIdFromComboBox(comsupid.Text); em1 = ExtractIdFromComboBox(com1em.Text);
            em2 = ExtractIdFromComboBox(com2em.Text); em3 = ExtractIdFromComboBox(com3em.Text);
            em4 = ExtractIdFromComboBox(com4em.Text); em5 = ExtractIdFromComboBox(com5em.Text);
        }

        private int ExtractIdFromComboBox(string comboText)
        {
            int startIdx = comboText.IndexOf('E') + 1; int endIdx = comboText.IndexOf(' ', startIdx);
            if (startIdx != -1 && endIdx != -1)
            {
                string idStr = comboText.Substring(startIdx, endIdx - startIdx); return Convert.ToInt32(idStr);
            }
            return -1;
        }

        private void btnmodrem_Click(object sender, EventArgs e)
        {
            string table1 = "teams";
            using (SqlCommand commandTable1 = new SqlCommand("DELETE FROM " + table1 + " WHERE tranid = '" + modtid + "';", connection))
            {
                try
                {
                    int rowsAffectedTable1 = commandTable1.ExecuteNonQuery(); 
                    if (rowsAffectedTable1 > 0)
                    {
                        Console.WriteLine("Data deleted from Teams.");
                    }
                    else
                    {
                        Console.WriteLine("No data deleted from Table1. Check your condition or data existence.");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error deleting from invest tabel:" + ex.Message);
                }
            }
        }

        private void btnviewdoc_Click(object sender, EventArgs e)
        {
            btnviewdoc.BackColor = Color.LimeGreen; dataGridView1.Visible = false;
            if (comviewdocid.Text == "")
            {
                DataSet dataSet0 = new DataSet(); string query0 = "SELECT * FROM teams"; connection.Open();
                using (SqlDataAdapter adapter0 = new SqlDataAdapter(query0, connection))
                {
                    adapter0.Fill(dataSet0, "All_Teams");
                }
                dataGridView1.DataSource = dataSet0.Tables["All_Teams"]; connection.Close();
            }
            else
            {
                searchid = ExtractIdfortid(comviewdocid.Text); DataSet dataSet0 = new DataSet();
                string query0 = "SELECT * FROM teams WHERE tid = @tranId "; connection.Open();
                using (SqlDataAdapter adapter0 = new SqlDataAdapter(query0, connection))
                {
                    adapter0.SelectCommand.Parameters.AddWithValue("@tranId", searchid); adapter0.Fill(dataSet0, "team");
                }
                dataGridView1.DataSource = dataSet0.Tables["team"]; connection.Close();
            }
        }

        private int ExtractIdfortid(string comboText)
        {
            int startIdx = comboText.IndexOf('T') + 1; int endIdx = comboText.IndexOf(' ', startIdx);
            if (startIdx != -1 && endIdx != -1)
            {
                string idStr = comboText.Substring(startIdx, endIdx - startIdx); return Convert.ToInt32(idStr);
            }
            return -1;
        }
    }
}