﻿namespace STARTUP___MANAGEMENT___SYSTEM
{
    partial class DocAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DocAdd));
            this.txtdocid = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.comdocty = new System.Windows.Forms.ComboBox();
            this.txtdocname = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.comsubby = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.datesub = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.btnchodoc = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.adddoc = new System.Windows.Forms.TabPage();
            this.richtxtdesc = new System.Windows.Forms.RichTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btnadd = new System.Windows.Forms.Button();
            this.moddoc = new System.Windows.Forms.TabPage();
            this.txtmoddesc = new System.Windows.Forms.RichTextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.btnmoddoc = new System.Windows.Forms.Button();
            this.btnmodchoosedoc = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.datemodsub = new System.Windows.Forms.DateTimePicker();
            this.commoddoctype = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.commodsub = new System.Windows.Forms.ComboBox();
            this.txtmoddocname = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.commoddocid = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.Viewdoc = new System.Windows.Forms.TabPage();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnviewdoc = new System.Windows.Forms.Button();
            this.comviewdocid = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.adddoc.SuspendLayout();
            this.moddoc.SuspendLayout();
            this.Viewdoc.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtdocid
            // 
            this.txtdocid.Cursor = System.Windows.Forms.Cursors.No;
            this.txtdocid.Enabled = false;
            this.txtdocid.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdocid.Location = new System.Drawing.Point(257, 65);
            this.txtdocid.Name = "txtdocid";
            this.txtdocid.Size = new System.Drawing.Size(270, 34);
            this.txtdocid.TabIndex = 2;
            this.txtdocid.WordWrap = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(19, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(151, 29);
            this.label2.TabIndex = 1;
            this.label2.Text = "Document ID";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(19, 139);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(183, 29);
            this.label1.TabIndex = 5;
            this.label1.Text = "Document Type";
            // 
            // comdocty
            // 
            this.comdocty.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.comdocty.FormattingEnabled = true;
            this.comdocty.Items.AddRange(new object[] {
            "Hard Copy",
            "Image",
            "PDF File",
            "Power Point File",
            "Word File",
            "Other"});
            this.comdocty.Location = new System.Drawing.Point(257, 136);
            this.comdocty.Name = "comdocty";
            this.comdocty.Size = new System.Drawing.Size(270, 37);
            this.comdocty.TabIndex = 6;
            this.comdocty.SelectedIndexChanged += new System.EventHandler(this.comdocty_SelectedIndexChanged);
            // 
            // txtdocname
            // 
            this.txtdocname.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtdocname.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdocname.Location = new System.Drawing.Point(986, 65);
            this.txtdocname.Name = "txtdocname";
            this.txtdocname.Size = new System.Drawing.Size(270, 34);
            this.txtdocname.TabIndex = 4;
            this.txtdocname.WordWrap = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(709, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(193, 29);
            this.label3.TabIndex = 3;
            this.label3.Text = "Document Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.label4.Location = new System.Drawing.Point(19, 215);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(155, 29);
            this.label4.TabIndex = 9;
            this.label4.Text = "Submitted By";
            // 
            // comsubby
            // 
            this.comsubby.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.comsubby.FormattingEnabled = true;
            this.comsubby.Location = new System.Drawing.Point(257, 212);
            this.comsubby.Name = "comsubby";
            this.comsubby.Size = new System.Drawing.Size(270, 37);
            this.comsubby.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.label5.Location = new System.Drawing.Point(709, 215);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(226, 29);
            this.label5.TabIndex = 11;
            this.label5.Text = "Date Of Submission";
            // 
            // datesub
            // 
            this.datesub.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.datesub.Location = new System.Drawing.Point(986, 210);
            this.datesub.Name = "datesub";
            this.datesub.Size = new System.Drawing.Size(270, 34);
            this.datesub.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.label6.Location = new System.Drawing.Point(709, 139);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(212, 29);
            this.label6.TabIndex = 7;
            this.label6.Text = "Choose Document";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // btnchodoc
            // 
            this.btnchodoc.BackColor = System.Drawing.Color.DarkGray;
            this.btnchodoc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnchodoc.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnchodoc.Location = new System.Drawing.Point(986, 141);
            this.btnchodoc.Name = "btnchodoc";
            this.btnchodoc.Size = new System.Drawing.Size(125, 31);
            this.btnchodoc.TabIndex = 8;
            this.btnchodoc.Text = "Choose File";
            this.btnchodoc.UseVisualStyleBackColor = false;
            this.btnchodoc.Click += new System.EventHandler(this.btnchodoc_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.adddoc);
            this.tabControl1.Controls.Add(this.moddoc);
            this.tabControl1.Controls.Add(this.Viewdoc);
            this.tabControl1.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(12, 34);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1335, 634);
            this.tabControl1.TabIndex = 14;
            // 
            // adddoc
            // 
            this.adddoc.BackColor = System.Drawing.Color.LightSteelBlue;
            this.adddoc.Controls.Add(this.richtxtdesc);
            this.adddoc.Controls.Add(this.label7);
            this.adddoc.Controls.Add(this.btnadd);
            this.adddoc.Controls.Add(this.label2);
            this.adddoc.Controls.Add(this.btnchodoc);
            this.adddoc.Controls.Add(this.txtdocid);
            this.adddoc.Controls.Add(this.label6);
            this.adddoc.Controls.Add(this.label1);
            this.adddoc.Controls.Add(this.datesub);
            this.adddoc.Controls.Add(this.comdocty);
            this.adddoc.Controls.Add(this.label5);
            this.adddoc.Controls.Add(this.label3);
            this.adddoc.Controls.Add(this.comsubby);
            this.adddoc.Controls.Add(this.txtdocname);
            this.adddoc.Controls.Add(this.label4);
            this.adddoc.Location = new System.Drawing.Point(4, 35);
            this.adddoc.Name = "adddoc";
            this.adddoc.Padding = new System.Windows.Forms.Padding(3);
            this.adddoc.Size = new System.Drawing.Size(1327, 595);
            this.adddoc.TabIndex = 0;
            this.adddoc.Text = "Add";
            // 
            // richtxtdesc
            // 
            this.richtxtdesc.Location = new System.Drawing.Point(257, 291);
            this.richtxtdesc.Name = "richtxtdesc";
            this.richtxtdesc.Size = new System.Drawing.Size(435, 135);
            this.richtxtdesc.TabIndex = 14;
            this.richtxtdesc.Text = "";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.label7.Location = new System.Drawing.Point(19, 292);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(135, 29);
            this.label7.TabIndex = 13;
            this.label7.Text = "Description";
            // 
            // btnadd
            // 
            this.btnadd.BackColor = System.Drawing.Color.Lime;
            this.btnadd.Font = new System.Drawing.Font("Microsoft Tai Le", 12F);
            this.btnadd.Location = new System.Drawing.Point(566, 459);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(126, 61);
            this.btnadd.TabIndex = 15;
            this.btnadd.Text = "Save";
            this.btnadd.UseVisualStyleBackColor = false;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click);
            // 
            // moddoc
            // 
            this.moddoc.BackColor = System.Drawing.Color.CornflowerBlue;
            this.moddoc.Controls.Add(this.txtmoddesc);
            this.moddoc.Controls.Add(this.label9);
            this.moddoc.Controls.Add(this.btnmoddoc);
            this.moddoc.Controls.Add(this.btnmodchoosedoc);
            this.moddoc.Controls.Add(this.label10);
            this.moddoc.Controls.Add(this.label11);
            this.moddoc.Controls.Add(this.datemodsub);
            this.moddoc.Controls.Add(this.commoddoctype);
            this.moddoc.Controls.Add(this.label12);
            this.moddoc.Controls.Add(this.label13);
            this.moddoc.Controls.Add(this.commodsub);
            this.moddoc.Controls.Add(this.txtmoddocname);
            this.moddoc.Controls.Add(this.label14);
            this.moddoc.Controls.Add(this.commoddocid);
            this.moddoc.Controls.Add(this.label8);
            this.moddoc.Location = new System.Drawing.Point(4, 35);
            this.moddoc.Name = "moddoc";
            this.moddoc.Padding = new System.Windows.Forms.Padding(3);
            this.moddoc.Size = new System.Drawing.Size(1327, 595);
            this.moddoc.TabIndex = 1;
            this.moddoc.Text = "Modify";
            // 
            // txtmoddesc
            // 
            this.txtmoddesc.Location = new System.Drawing.Point(252, 325);
            this.txtmoddesc.Name = "txtmoddesc";
            this.txtmoddesc.Size = new System.Drawing.Size(435, 135);
            this.txtmoddesc.TabIndex = 8;
            this.txtmoddesc.Text = "";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.label9.Location = new System.Drawing.Point(37, 326);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(135, 29);
            this.label9.TabIndex = 26;
            this.label9.Text = "Description";
            // 
            // btnmoddoc
            // 
            this.btnmoddoc.BackColor = System.Drawing.Color.Lime;
            this.btnmoddoc.Font = new System.Drawing.Font("Microsoft Tai Le", 12F);
            this.btnmoddoc.Location = new System.Drawing.Point(584, 493);
            this.btnmoddoc.Name = "btnmoddoc";
            this.btnmoddoc.Size = new System.Drawing.Size(126, 61);
            this.btnmoddoc.TabIndex = 9;
            this.btnmoddoc.Text = "Save";
            this.btnmoddoc.UseVisualStyleBackColor = false;
            this.btnmoddoc.Click += new System.EventHandler(this.btnmoddoc_Click);
            // 
            // btnmodchoosedoc
            // 
            this.btnmodchoosedoc.BackColor = System.Drawing.Color.Gray;
            this.btnmodchoosedoc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnmodchoosedoc.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmodchoosedoc.Location = new System.Drawing.Point(1029, 175);
            this.btnmodchoosedoc.Name = "btnmodchoosedoc";
            this.btnmodchoosedoc.Size = new System.Drawing.Size(125, 31);
            this.btnmodchoosedoc.TabIndex = 5;
            this.btnmodchoosedoc.Text = "Choose File";
            this.btnmodchoosedoc.UseVisualStyleBackColor = false;
            this.btnmodchoosedoc.Click += new System.EventHandler(this.btnmodchoosedoc_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.label10.Location = new System.Drawing.Point(752, 173);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(212, 29);
            this.label10.TabIndex = 21;
            this.label10.Text = "Choose Document";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(37, 173);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(183, 29);
            this.label11.TabIndex = 19;
            this.label11.Text = "Document Type";
            // 
            // datemodsub
            // 
            this.datemodsub.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.datemodsub.Location = new System.Drawing.Point(1029, 244);
            this.datemodsub.Name = "datemodsub";
            this.datemodsub.Size = new System.Drawing.Size(270, 34);
            this.datemodsub.TabIndex = 7;
            // 
            // commoddoctype
            // 
            this.commoddoctype.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.commoddoctype.FormattingEnabled = true;
            this.commoddoctype.Items.AddRange(new object[] {
            "Hard Copy",
            "Image",
            "PDF File",
            "Power Point File",
            "Word File",
            "Other"});
            this.commoddoctype.Location = new System.Drawing.Point(252, 170);
            this.commoddoctype.Name = "commoddoctype";
            this.commoddoctype.Size = new System.Drawing.Size(270, 37);
            this.commoddoctype.TabIndex = 4;
            this.commoddoctype.SelectedIndexChanged += new System.EventHandler(this.commoddoctype_SelectedIndexChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.label12.Location = new System.Drawing.Point(752, 249);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(226, 29);
            this.label12.TabIndex = 24;
            this.label12.Text = "Date Of Submission";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(752, 77);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(193, 29);
            this.label13.TabIndex = 17;
            this.label13.Text = "Document Name";
            // 
            // commodsub
            // 
            this.commodsub.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.commodsub.FormattingEnabled = true;
            this.commodsub.Location = new System.Drawing.Point(252, 246);
            this.commodsub.Name = "commodsub";
            this.commodsub.Size = new System.Drawing.Size(270, 37);
            this.commodsub.TabIndex = 6;
            // 
            // txtmoddocname
            // 
            this.txtmoddocname.Cursor = System.Windows.Forms.Cursors.No;
            this.txtmoddocname.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmoddocname.Location = new System.Drawing.Point(1029, 74);
            this.txtmoddocname.Name = "txtmoddocname";
            this.txtmoddocname.Size = new System.Drawing.Size(270, 34);
            this.txtmoddocname.TabIndex = 3;
            this.txtmoddocname.WordWrap = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.label14.Location = new System.Drawing.Point(37, 249);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(155, 29);
            this.label14.TabIndex = 22;
            this.label14.Text = "Submitted By";
            // 
            // commoddocid
            // 
            this.commoddocid.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.commoddocid.FormattingEnabled = true;
            this.commoddocid.Location = new System.Drawing.Point(252, 74);
            this.commoddocid.Name = "commoddocid";
            this.commoddocid.Size = new System.Drawing.Size(270, 37);
            this.commoddocid.TabIndex = 1;
            this.commoddocid.SelectedIndexChanged += new System.EventHandler(this.commoddocid_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(37, 77);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(151, 29);
            this.label8.TabIndex = 6;
            this.label8.Text = "Document ID";
            // 
            // Viewdoc
            // 
            this.Viewdoc.BackColor = System.Drawing.Color.Teal;
            this.Viewdoc.Controls.Add(this.dataGridView1);
            this.Viewdoc.Controls.Add(this.btnviewdoc);
            this.Viewdoc.Controls.Add(this.comviewdocid);
            this.Viewdoc.Controls.Add(this.label15);
            this.Viewdoc.Location = new System.Drawing.Point(4, 35);
            this.Viewdoc.Name = "Viewdoc";
            this.Viewdoc.Size = new System.Drawing.Size(1327, 595);
            this.Viewdoc.TabIndex = 2;
            this.Viewdoc.Text = "View";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(31, 140);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1159, 410);
            this.dataGridView1.TabIndex = 20;
            this.dataGridView1.Visible = false;
            // 
            // btnviewdoc
            // 
            this.btnviewdoc.BackColor = System.Drawing.Color.Orange;
            this.btnviewdoc.Font = new System.Drawing.Font("Microsoft Tai Le", 12F);
            this.btnviewdoc.Location = new System.Drawing.Point(555, 35);
            this.btnviewdoc.Name = "btnviewdoc";
            this.btnviewdoc.Size = new System.Drawing.Size(126, 61);
            this.btnviewdoc.TabIndex = 2;
            this.btnviewdoc.Text = "Search";
            this.btnviewdoc.UseVisualStyleBackColor = false;
            this.btnviewdoc.Click += new System.EventHandler(this.btnviewdoc_Click);
            // 
            // comviewdocid
            // 
            this.comviewdocid.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.comviewdocid.FormattingEnabled = true;
            this.comviewdocid.Location = new System.Drawing.Point(241, 45);
            this.comviewdocid.Name = "comviewdocid";
            this.comviewdocid.Size = new System.Drawing.Size(270, 37);
            this.comviewdocid.TabIndex = 1;
            this.comviewdocid.SelectedIndexChanged += new System.EventHandler(this.comviewdocid_SelectedIndexChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(26, 48);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(151, 29);
            this.label15.TabIndex = 17;
            this.label15.Text = "Document ID";
            // 
            // DocAdd
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(157)))), ((int)(((byte)(94)))), ((int)(((byte)(96)))));
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1924, 1055);
            this.Controls.Add(this.tabControl1);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "DocAdd";
            this.ShowIcon = false;
            this.Text = " ";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.DocAdd_Load);
            this.tabControl1.ResumeLayout(false);
            this.adddoc.ResumeLayout(false);
            this.adddoc.PerformLayout();
            this.moddoc.ResumeLayout(false);
            this.moddoc.PerformLayout();
            this.Viewdoc.ResumeLayout(false);
            this.Viewdoc.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtdocid;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comdocty;
        private System.Windows.Forms.TextBox txtdocname;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comsubby;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker datesub;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button btnchodoc;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage adddoc;
        private System.Windows.Forms.TabPage moddoc;
        private System.Windows.Forms.Button btnadd;
        private System.Windows.Forms.RichTextBox richtxtdesc;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox commoddocid;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.RichTextBox txtmoddesc;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnmoddoc;
        private System.Windows.Forms.Button btnmodchoosedoc;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DateTimePicker datemodsub;
        private System.Windows.Forms.ComboBox commoddoctype;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox commodsub;
        private System.Windows.Forms.TextBox txtmoddocname;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TabPage Viewdoc;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnviewdoc;
        private System.Windows.Forms.ComboBox comviewdocid;
        private System.Windows.Forms.Label label15;
    }
}