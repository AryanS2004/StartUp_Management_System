﻿namespace STARTUP___MANAGEMENT___SYSTEM
{
    partial class Stock
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Stock));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.adddoc = new System.Windows.Forms.TabPage();
            this.dateaddman = new System.Windows.Forms.DateTimePicker();
            this.labeladddate = new System.Windows.Forms.Label();
            this.numaddproquan = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.txtaddpropri = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtaddprodesc = new System.Windows.Forms.RichTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btnadditeam = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtaddproid = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.comaddprotype = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtaddproname = new System.Windows.Forms.TextBox();
            this.moddoc = new System.Windows.Forms.TabPage();
            this.datemodman = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.nummodproquan = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtmodpropri = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtmodprodesc = new System.Windows.Forms.RichTextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.btnmodsave = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.commodprotype = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtmodproname = new System.Windows.Forms.TextBox();
            this.commodproid = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.Viewdoc = new System.Windows.Forms.TabPage();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnviewdoc = new System.Windows.Forms.Button();
            this.comviewdocid = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtaddprofield = new System.Windows.Forms.TextBox();
            this.txtmodprofield = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.adddoc.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numaddproquan)).BeginInit();
            this.moddoc.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nummodproquan)).BeginInit();
            this.Viewdoc.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.adddoc);
            this.tabControl1.Controls.Add(this.moddoc);
            this.tabControl1.Controls.Add(this.Viewdoc);
            this.tabControl1.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(12, 34);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1335, 634);
            this.tabControl1.TabIndex = 15;
            // 
            // adddoc
            // 
            this.adddoc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(168)))), ((int)(((byte)(113)))));
            this.adddoc.Controls.Add(this.txtaddprofield);
            this.adddoc.Controls.Add(this.dateaddman);
            this.adddoc.Controls.Add(this.labeladddate);
            this.adddoc.Controls.Add(this.numaddproquan);
            this.adddoc.Controls.Add(this.label4);
            this.adddoc.Controls.Add(this.label17);
            this.adddoc.Controls.Add(this.txtaddpropri);
            this.adddoc.Controls.Add(this.label16);
            this.adddoc.Controls.Add(this.txtaddprodesc);
            this.adddoc.Controls.Add(this.label7);
            this.adddoc.Controls.Add(this.btnadditeam);
            this.adddoc.Controls.Add(this.label2);
            this.adddoc.Controls.Add(this.txtaddproid);
            this.adddoc.Controls.Add(this.label6);
            this.adddoc.Controls.Add(this.label1);
            this.adddoc.Controls.Add(this.comaddprotype);
            this.adddoc.Controls.Add(this.label3);
            this.adddoc.Controls.Add(this.txtaddproname);
            this.adddoc.Location = new System.Drawing.Point(4, 35);
            this.adddoc.Name = "adddoc";
            this.adddoc.Padding = new System.Windows.Forms.Padding(3);
            this.adddoc.Size = new System.Drawing.Size(1327, 595);
            this.adddoc.TabIndex = 0;
            this.adddoc.Text = "Add";
            // 
            // dateaddman
            // 
            this.dateaddman.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.dateaddman.Location = new System.Drawing.Point(255, 214);
            this.dateaddman.Name = "dateaddman";
            this.dateaddman.Size = new System.Drawing.Size(270, 34);
            this.dateaddman.TabIndex = 9;
            // 
            // labeladddate
            // 
            this.labeladddate.AutoSize = true;
            this.labeladddate.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.labeladddate.Location = new System.Drawing.Point(19, 220);
            this.labeladddate.Name = "labeladddate";
            this.labeladddate.Size = new System.Drawing.Size(94, 29);
            this.labeladddate.TabIndex = 23;
            this.labeladddate.Text = "Date Of";
            // 
            // numaddproquan
            // 
            this.numaddproquan.Location = new System.Drawing.Point(1012, 289);
            this.numaddproquan.Name = "numaddproquan";
            this.numaddproquan.Size = new System.Drawing.Size(270, 34);
            this.numaddproquan.TabIndex = 12;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.label4.Location = new System.Drawing.Point(735, 289);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(189, 29);
            this.label4.TabIndex = 21;
            this.label4.Text = "Product Quantity";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Bookman Old Style", 10F);
            this.label17.Location = new System.Drawing.Point(888, 220);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(57, 21);
            this.label17.TabIndex = 19;
            this.label17.Text = "in Rs.";
            // 
            // txtaddpropri
            // 
            this.txtaddpropri.Cursor = System.Windows.Forms.Cursors.No;
            this.txtaddpropri.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaddpropri.Location = new System.Drawing.Point(1012, 209);
            this.txtaddpropri.Name = "txtaddpropri";
            this.txtaddpropri.Size = new System.Drawing.Size(270, 34);
            this.txtaddpropri.TabIndex = 10;
            this.txtaddpropri.WordWrap = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.label16.Location = new System.Drawing.Point(735, 214);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(158, 29);
            this.label16.TabIndex = 17;
            this.label16.Text = "Product Price";
            // 
            // txtaddprodesc
            // 
            this.txtaddprodesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.txtaddprodesc.Location = new System.Drawing.Point(255, 288);
            this.txtaddprodesc.Name = "txtaddprodesc";
            this.txtaddprodesc.Size = new System.Drawing.Size(435, 135);
            this.txtaddprodesc.TabIndex = 11;
            this.txtaddprodesc.Text = "";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.label7.Location = new System.Drawing.Point(19, 289);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(224, 29);
            this.label7.TabIndex = 13;
            this.label7.Text = "Product Description";
            // 
            // btnadditeam
            // 
            this.btnadditeam.BackColor = System.Drawing.Color.Lime;
            this.btnadditeam.Font = new System.Drawing.Font("Microsoft Tai Le", 12F);
            this.btnadditeam.Location = new System.Drawing.Point(632, 469);
            this.btnadditeam.Name = "btnadditeam";
            this.btnadditeam.Size = new System.Drawing.Size(126, 61);
            this.btnadditeam.TabIndex = 13;
            this.btnadditeam.Text = "Save";
            this.btnadditeam.UseVisualStyleBackColor = false;
            this.btnadditeam.Click += new System.EventHandler(this.btnadditeam_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(19, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(125, 29);
            this.label2.TabIndex = 1;
            this.label2.Text = "Product ID";
            // 
            // txtaddproid
            // 
            this.txtaddproid.Cursor = System.Windows.Forms.Cursors.No;
            this.txtaddproid.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaddproid.Location = new System.Drawing.Point(255, 65);
            this.txtaddproid.Name = "txtaddproid";
            this.txtaddproid.Size = new System.Drawing.Size(270, 34);
            this.txtaddproid.TabIndex = 2;
            this.txtaddproid.WordWrap = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.label6.Location = new System.Drawing.Point(735, 139);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(157, 29);
            this.label6.TabIndex = 7;
            this.label6.Text = "Product Field";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(19, 139);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(157, 29);
            this.label1.TabIndex = 5;
            this.label1.Text = "Product Type";
            // 
            // comaddprotype
            // 
            this.comaddprotype.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.comaddprotype.FormattingEnabled = true;
            this.comaddprotype.Items.AddRange(new object[] {
            "Manufactured",
            "Bought"});
            this.comaddprotype.Location = new System.Drawing.Point(255, 136);
            this.comaddprotype.Name = "comaddprotype";
            this.comaddprotype.Size = new System.Drawing.Size(270, 37);
            this.comaddprotype.TabIndex = 6;
            this.comaddprotype.SelectedIndexChanged += new System.EventHandler(this.comaddprotype_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(735, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(167, 29);
            this.label3.TabIndex = 3;
            this.label3.Text = "Product Name";
            // 
            // txtaddproname
            // 
            this.txtaddproname.Cursor = System.Windows.Forms.Cursors.No;
            this.txtaddproname.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaddproname.Location = new System.Drawing.Point(1012, 65);
            this.txtaddproname.Name = "txtaddproname";
            this.txtaddproname.Size = new System.Drawing.Size(270, 34);
            this.txtaddproname.TabIndex = 4;
            this.txtaddproname.WordWrap = false;
            // 
            // moddoc
            // 
            this.moddoc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(134)))), ((int)(((byte)(83)))));
            this.moddoc.Controls.Add(this.txtmodprofield);
            this.moddoc.Controls.Add(this.datemodman);
            this.moddoc.Controls.Add(this.label5);
            this.moddoc.Controls.Add(this.nummodproquan);
            this.moddoc.Controls.Add(this.label9);
            this.moddoc.Controls.Add(this.label10);
            this.moddoc.Controls.Add(this.txtmodpropri);
            this.moddoc.Controls.Add(this.label11);
            this.moddoc.Controls.Add(this.txtmodprodesc);
            this.moddoc.Controls.Add(this.label12);
            this.moddoc.Controls.Add(this.btnmodsave);
            this.moddoc.Controls.Add(this.label13);
            this.moddoc.Controls.Add(this.label14);
            this.moddoc.Controls.Add(this.commodprotype);
            this.moddoc.Controls.Add(this.label18);
            this.moddoc.Controls.Add(this.txtmodproname);
            this.moddoc.Controls.Add(this.commodproid);
            this.moddoc.Controls.Add(this.label8);
            this.moddoc.Location = new System.Drawing.Point(4, 35);
            this.moddoc.Name = "moddoc";
            this.moddoc.Padding = new System.Windows.Forms.Padding(3);
            this.moddoc.Size = new System.Drawing.Size(1327, 595);
            this.moddoc.TabIndex = 1;
            this.moddoc.Text = "Modify";
            // 
            // datemodman
            // 
            this.datemodman.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.datemodman.Location = new System.Drawing.Point(271, 231);
            this.datemodman.Name = "datemodman";
            this.datemodman.Size = new System.Drawing.Size(270, 34);
            this.datemodman.TabIndex = 30;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.label5.Location = new System.Drawing.Point(35, 237);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 29);
            this.label5.TabIndex = 39;
            this.label5.Text = "Date Of";
            // 
            // nummodproquan
            // 
            this.nummodproquan.Location = new System.Drawing.Point(1019, 306);
            this.nummodproquan.Name = "nummodproquan";
            this.nummodproquan.Size = new System.Drawing.Size(270, 34);
            this.nummodproquan.TabIndex = 33;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.label9.Location = new System.Drawing.Point(742, 306);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(189, 29);
            this.label9.TabIndex = 38;
            this.label9.Text = "Product Quantity";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Bookman Old Style", 10F);
            this.label10.Location = new System.Drawing.Point(895, 237);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(57, 21);
            this.label10.TabIndex = 37;
            this.label10.Text = "in Rs.";
            // 
            // txtmodpropri
            // 
            this.txtmodpropri.Cursor = System.Windows.Forms.Cursors.No;
            this.txtmodpropri.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmodpropri.Location = new System.Drawing.Point(1019, 226);
            this.txtmodpropri.Name = "txtmodpropri";
            this.txtmodpropri.Size = new System.Drawing.Size(270, 34);
            this.txtmodpropri.TabIndex = 31;
            this.txtmodpropri.WordWrap = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.label11.Location = new System.Drawing.Point(742, 231);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(158, 29);
            this.label11.TabIndex = 36;
            this.label11.Text = "Product Price";
            // 
            // txtmodprodesc
            // 
            this.txtmodprodesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.txtmodprodesc.Location = new System.Drawing.Point(271, 305);
            this.txtmodprodesc.Name = "txtmodprodesc";
            this.txtmodprodesc.Size = new System.Drawing.Size(435, 135);
            this.txtmodprodesc.TabIndex = 32;
            this.txtmodprodesc.Text = "";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.label12.Location = new System.Drawing.Point(35, 306);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(224, 29);
            this.label12.TabIndex = 34;
            this.label12.Text = "Product Description";
            // 
            // btnmodsave
            // 
            this.btnmodsave.BackColor = System.Drawing.Color.Lime;
            this.btnmodsave.Font = new System.Drawing.Font("Microsoft Tai Le", 12F);
            this.btnmodsave.Location = new System.Drawing.Point(648, 486);
            this.btnmodsave.Name = "btnmodsave";
            this.btnmodsave.Size = new System.Drawing.Size(126, 61);
            this.btnmodsave.TabIndex = 35;
            this.btnmodsave.Text = "Save";
            this.btnmodsave.UseVisualStyleBackColor = false;
            this.btnmodsave.Click += new System.EventHandler(this.btnmodsave_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.label13.Location = new System.Drawing.Point(742, 156);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(157, 29);
            this.label13.TabIndex = 28;
            this.label13.Text = "Product Field";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(35, 156);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(157, 29);
            this.label14.TabIndex = 26;
            this.label14.Text = "Product Type";
            // 
            // commodprotype
            // 
            this.commodprotype.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.commodprotype.FormattingEnabled = true;
            this.commodprotype.Items.AddRange(new object[] {
            "Manufactured",
            "Bought"});
            this.commodprotype.Location = new System.Drawing.Point(271, 153);
            this.commodprotype.Name = "commodprotype";
            this.commodprotype.Size = new System.Drawing.Size(270, 37);
            this.commodprotype.TabIndex = 27;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(742, 79);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(167, 29);
            this.label18.TabIndex = 24;
            this.label18.Text = "Product Name";
            // 
            // txtmodproname
            // 
            this.txtmodproname.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtmodproname.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmodproname.Location = new System.Drawing.Point(1019, 76);
            this.txtmodproname.Name = "txtmodproname";
            this.txtmodproname.Size = new System.Drawing.Size(270, 34);
            this.txtmodproname.TabIndex = 25;
            this.txtmodproname.WordWrap = false;
            // 
            // commodproid
            // 
            this.commodproid.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.commodproid.FormattingEnabled = true;
            this.commodproid.Location = new System.Drawing.Point(271, 71);
            this.commodproid.Name = "commodproid";
            this.commodproid.Size = new System.Drawing.Size(270, 37);
            this.commodproid.TabIndex = 1;
            this.commodproid.SelectedIndexChanged += new System.EventHandler(this.commodproid_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(35, 74);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(125, 29);
            this.label8.TabIndex = 6;
            this.label8.Text = "Product ID";
            // 
            // Viewdoc
            // 
            this.Viewdoc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(86)))), ((int)(((byte)(39)))));
            this.Viewdoc.Controls.Add(this.dataGridView1);
            this.Viewdoc.Controls.Add(this.btnviewdoc);
            this.Viewdoc.Controls.Add(this.comviewdocid);
            this.Viewdoc.Controls.Add(this.label15);
            this.Viewdoc.Location = new System.Drawing.Point(4, 35);
            this.Viewdoc.Name = "Viewdoc";
            this.Viewdoc.Size = new System.Drawing.Size(1327, 595);
            this.Viewdoc.TabIndex = 2;
            this.Viewdoc.Text = "View";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(31, 140);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1027, 410);
            this.dataGridView1.TabIndex = 20;
            this.dataGridView1.Visible = false;
            // 
            // btnviewdoc
            // 
            this.btnviewdoc.BackColor = System.Drawing.Color.Orange;
            this.btnviewdoc.Font = new System.Drawing.Font("Microsoft Tai Le", 12F);
            this.btnviewdoc.Location = new System.Drawing.Point(555, 35);
            this.btnviewdoc.Name = "btnviewdoc";
            this.btnviewdoc.Size = new System.Drawing.Size(126, 61);
            this.btnviewdoc.TabIndex = 2;
            this.btnviewdoc.Text = "Search";
            this.btnviewdoc.UseVisualStyleBackColor = false;
            this.btnviewdoc.Click += new System.EventHandler(this.btnviewdoc_Click);
            // 
            // comviewdocid
            // 
            this.comviewdocid.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.comviewdocid.FormattingEnabled = true;
            this.comviewdocid.Items.AddRange(new object[] {
            "D001 (ppt on local survey)",
            "D002 (research paper of envirnment) "});
            this.comviewdocid.Location = new System.Drawing.Point(241, 45);
            this.comviewdocid.Name = "comviewdocid";
            this.comviewdocid.Size = new System.Drawing.Size(270, 37);
            this.comviewdocid.TabIndex = 1;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(26, 48);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(151, 29);
            this.label15.TabIndex = 17;
            this.label15.Text = "Document ID";
            // 
            // txtaddprofield
            // 
            this.txtaddprofield.Cursor = System.Windows.Forms.Cursors.No;
            this.txtaddprofield.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaddprofield.Location = new System.Drawing.Point(1012, 139);
            this.txtaddprofield.Name = "txtaddprofield";
            this.txtaddprofield.Size = new System.Drawing.Size(270, 34);
            this.txtaddprofield.TabIndex = 24;
            this.txtaddprofield.WordWrap = false;
            // 
            // txtmodprofield
            // 
            this.txtmodprofield.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtmodprofield.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmodprofield.Location = new System.Drawing.Point(1019, 151);
            this.txtmodprofield.Name = "txtmodprofield";
            this.txtmodprofield.Size = new System.Drawing.Size(270, 34);
            this.txtmodprofield.TabIndex = 40;
            this.txtmodprofield.WordWrap = false;
            // 
            // Stock
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.MediumPurple;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1924, 1055);
            this.Controls.Add(this.tabControl1);
            this.DoubleBuffered = true;
            this.Name = "Stock";
            this.ShowIcon = false;
            this.Text = "Stock Management";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Stock_Load);
            this.tabControl1.ResumeLayout(false);
            this.adddoc.ResumeLayout(false);
            this.adddoc.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numaddproquan)).EndInit();
            this.moddoc.ResumeLayout(false);
            this.moddoc.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nummodproquan)).EndInit();
            this.Viewdoc.ResumeLayout(false);
            this.Viewdoc.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage adddoc;
        private System.Windows.Forms.RichTextBox txtaddprodesc;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnadditeam;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtaddproid;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comaddprotype;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtaddproname;
        private System.Windows.Forms.TabPage moddoc;
        private System.Windows.Forms.ComboBox commodproid;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TabPage Viewdoc;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnviewdoc;
        private System.Windows.Forms.ComboBox comviewdocid;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtaddpropri;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.DateTimePicker dateaddman;
        private System.Windows.Forms.Label labeladddate;
        private System.Windows.Forms.NumericUpDown numaddproquan;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker datemodman;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown nummodproquan;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtmodpropri;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.RichTextBox txtmodprodesc;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnmodsave;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox commodprotype;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtmodproname;
        private System.Windows.Forms.TextBox txtaddprofield;
        private System.Windows.Forms.TextBox txtmodprofield;
    }
}