﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace STARTUP___MANAGEMENT___SYSTEM
{
    public partial class EmpAttendShow : Form
    {
        private string connectionString = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\hp\Documents\Startup1.mdf;Integrated Security=True;Connect Timeout=30";
        private SqlConnection connection; int searchid;

        public EmpAttendShow()
        {
            InitializeComponent(); connection = new SqlConnection(connectionString);
        }

        private void EmpAttendShow_Load(object sender, EventArgs e)
        {
            try
            {
                connection.Open(); string query = "SELECT Eid, fname, lname FROM Empbasic";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        comid.Items.Clear();
                        while (reader.Read())
                        {
                            int eid = reader.GetInt32(0); string firstname = reader.GetString(1); string lastname = reader.GetString(2);
                            string displayString = "E" + eid + " (" + firstname + " " + lastname + ")"; comid.Items.Add(displayString);
                        }
                    }
                }
                DataSet dataSet0 = new DataSet(); string query0 = "SELECT * FROM Empbasic";
                using (SqlDataAdapter adapter0 = new SqlDataAdapter(query0, connection))
                {
                    adapter0.Fill(dataSet0, "All_Employee_Details");
                }
                dataGridView1.DataSource = dataSet0.Tables["All_Employee_Details"]; connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        private void comid_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comid.Text == "")
            {
                DataSet dataSet0 = new DataSet(); string query0 = "SELECT * FROM Empbasic"; connection.Open();
                using (SqlDataAdapter adapter0 = new SqlDataAdapter(query0, connection))
                {
                    adapter0.Fill(dataSet0, "All_Employee_Details");
                }
                dataGridView1.DataSource = dataSet0.Tables["All_Employee_Details"];
            }
            else
            {
                searchid = ExtractIdFromComboBox(comid.Text); DataSet dataSet0 = new DataSet();
                string query0 = "SELECT * FROM Empbasic WHERE Eid = @tranId "; connection.Open();
                using (SqlDataAdapter adapter0 = new SqlDataAdapter(query0, connection))
                {
                    adapter0.SelectCommand.Parameters.AddWithValue("@tranId", searchid); adapter0.Fill(dataSet0, "Employee");
                }
                dataGridView1.DataSource = dataSet0.Tables["Employee"];
            }
        }

        private int ExtractIdFromComboBox(string comboText)
        {
            int startIdx = comboText.IndexOf('E') + 1; int endIdx = comboText.IndexOf(' ', startIdx);
            if (startIdx != -1 && endIdx != -1)
            {
                string idStr = comboText.Substring(startIdx, endIdx - startIdx); return Convert.ToInt32(idStr);
            }
            return -1;
        }
    }
}