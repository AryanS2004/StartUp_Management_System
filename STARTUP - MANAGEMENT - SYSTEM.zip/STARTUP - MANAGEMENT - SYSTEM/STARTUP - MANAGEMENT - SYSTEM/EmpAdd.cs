﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace STARTUP___MANAGEMENT___SYSTEM
{
    public partial class EmpAdd : Form
    {
        private string connectionString = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\hp\Documents\Startup1.mdf;Integrated Security=True;Connect Timeout=30";
        private SqlConnection connection; private bool isInformationSaved = false; private string userimage,signimage;
        private string num,role,asbranch,lname,fname; private int eid; private DateTime datejoin,dateagree,datesal;
        private string idtype, idnum, altnum, locadd, paradd , email; private int sal, bon;

        public EmpAdd()
        {
            InitializeComponent(); connection = new SqlConnection(connectionString);
        }

        private void InsertDataIntoEmpbasic()
        {
            num = txtbasnum.Text; fname = txtbasefirstname.Text; lname = txtbaselastname.Text; asbranch = combasbra.Text; role = combasrole.Text; 
             try
                {
                    if (connection.State != ConnectionState.Open)
                    {
                        connection.Open();
                    }
                    string query = "INSERT INTO Empbasic (imgemp, imgsign, contactnum, asrole, asbranch, lname, fname, dateofjoin, dateagritill, datesalgive, identitype, idnum, altcontactnum, localadd, parmanentadd, email, salary, bonus) " +
                                   "VALUES (@userimage, @signimage, @nums, @role, @asbranch, @lname, @fname, @datejoin, @dateagree, @datesal, @idtype, @idnum, @altnum, @locadd, @paradd, @email, @sal, @bon)";
                    SqlCommand cmd = new SqlCommand(query, connection); cmd.Parameters.AddWithValue("@userimage", userimage); cmd.Parameters.AddWithValue("@signimage", signimage);
                    cmd.Parameters.AddWithValue("@nums", num); cmd.Parameters.AddWithValue("@role", role); cmd.Parameters.AddWithValue("@asbranch", asbranch);
                    cmd.Parameters.AddWithValue("@lname", lname); cmd.Parameters.AddWithValue("@fname", fname); cmd.Parameters.AddWithValue("@eid", eid);
                    cmd.Parameters.AddWithValue("@datejoin", datejoin); cmd.Parameters.AddWithValue("@dateagree", dateagree); cmd.Parameters.AddWithValue("@datesal", datesal);
                    cmd.Parameters.AddWithValue("@idtype", idtype); cmd.Parameters.AddWithValue("@idnum", idnum); cmd.Parameters.AddWithValue("@altnum", altnum);
                    cmd.Parameters.AddWithValue("@locadd", locadd); cmd.Parameters.AddWithValue("@paradd", paradd); cmd.Parameters.AddWithValue("@email", email);
                    cmd.Parameters.AddWithValue("@sal", sal); cmd.Parameters.AddWithValue("@bon", bon);

                    cmd.ExecuteNonQuery(); MessageBox.Show("Information saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information); isInformationSaved = true;
                }
                catch (Exception ex)
                {
                    string errors = ex.Message; MessageBox.Show ("Error: "+errors, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    connection.Close();
                }
        }

        private void btnbassave_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtid.Text) && !string.IsNullOrEmpty(txtbasefirstname.Text) && !string.IsNullOrEmpty(txtbaselastname.Text) &&
            !string.IsNullOrEmpty(combasbra.Text) && !string.IsNullOrEmpty(combasrole.Text) && !string.IsNullOrEmpty(txtbasnum.Text))
            {
                string realid = txtid.Text;

                if (realid.Length >= 3)
                {
                    eid = Convert.ToInt32(realid.Substring(realid.Length - 3)); 
                }
                DialogResult result = MessageBox.Show("Do you want to save the information?", "Save Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    MessageBox.Show("Information saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    btnbasnext.Visible = true; isInformationSaved = true; txtid2.Text = realid; txtid3.Text = realid;
                }
                else
                {
                    MessageBox.Show("Information not saved.", "Cancelled", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else 
            {
                MessageBox.Show("Please Enter all Details !! ", "Oops!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void EmBasic_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!isInformationSaved)
            {
                DialogResult result = MessageBox.Show("Do you want to close this page? Unsaved information will be lost.", "Close Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.No)
                {
                    e.Cancel = true;
                }
            }
        }

        private void btnbasnext_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = advemp;
        }

        private void comadidtype_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comadidtype.SelectedItem.ToString() != "")
            {
                labadidnum.Visible = true; txtadidnum.Visible = true;
            }
            else
            {
                labadidnum.Visible = false; txtadidnum.Visible = false;
            }
        }

        private void radioadyes_CheckedChanged(object sender, EventArgs e)
        {
            if (radioadyes.Checked)
            {
                if (!string.IsNullOrEmpty(txtadlocaladd.Text))
                {
                    txtadparadd.Text = txtadlocaladd.Text;
                }
                else
                {
                    MessageBox.Show("Please enter the local address first.", "Input Required", MessageBoxButtons.OK, MessageBoxIcon.Warning); radioadyes.Checked = false;
                }
            }
        }

        private void radioadno_CheckedChanged(object sender, EventArgs e)
        {
            if (radioadno.Checked)
            {
                using (var inputForm = new Form())
                {
                    inputForm.StartPosition = FormStartPosition.CenterScreen; inputForm.Text = "Enter Parmanent Address - ";
                    var textBox = new TextBox(); textBox.Dock = DockStyle.Fill; textBox.ScrollBars = ScrollBars.Vertical;
                    textBox.Multiline = true; textBox.Font = new Font("Microsoft Sans Serif", 14);
                    var okButton = new Button(); okButton.Text = "OK"; okButton.DialogResult = DialogResult.OK; 
                    inputForm.Controls.Add(textBox); inputForm.Controls.Add(okButton);
                    okButton.Dock = DockStyle.Bottom; DialogResult result = inputForm.ShowDialog();
                    if (result == DialogResult.OK)
                    {
                        MessageBox.Show("Address added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        txtadparadd.Text = textBox.Text;
                    }
                    else
                    {
                        radioadno.Checked = false;
                    }
                }
            }
        }

        private void btnadsave_Click(object sender, EventArgs e)
        {
            if (dateadjoin.Value != null && !string.IsNullOrEmpty(comadidtype.Text) && !string.IsNullOrEmpty(txtadidnum.Text) &&
                !string.IsNullOrEmpty(txtaddaltnum.Text) && !string.IsNullOrEmpty(txtemail.Text) && !string.IsNullOrEmpty(txtadlocaladd.Text) &&
                !string.IsNullOrEmpty(txtadparadd.Text))
            {
                datejoin = dateadjoin.Value; idtype = comadidtype.Text; idnum = txtadidnum.Text; altnum = txtaddaltnum.Text;
                email = txtemail.Text; locadd = txtadlocaladd.Text; paradd = txtadparadd.Text;
                DialogResult result = MessageBox.Show("Do you want to save the information?", "Save Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    MessageBox.Show("Information saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    btnadnext.Visible = true; isInformationSaved = true;
                }
                else
                {
                    MessageBox.Show("Information not saved.", "Cancelled", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Please Enter all Details !! ", "Oops!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnadnext_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = finalemp;
        }

        private void btnfinsave_Click(object sender, EventArgs e)
        {
            sal = int.Parse(txtfinsal.Text); bon = int.Parse(txtfinbonus.Text); datesal = datefinsalg.Value; dateagree = datefinagree.Value;

            DialogResult result = MessageBox.Show("Do you want to save the information?", "Save Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                InsertDataIntoEmpbasic();
            }
            else
            {
                MessageBox.Show("Information not saved.", "Cancelled", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnfinimemp_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog(); openFileDialog1.Filter = "Image Files|*.bmp;*.jpg;*.jpeg;*.png;*.gif|All Files|*.*";
                 
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                userimage = openFileDialog1.FileName;
                MessageBox.Show("Document selected for Image : " + userimage, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnfinimgsig_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog(); openFileDialog1.Filter = "Image Files|*.bmp;*.jpg;*.jpeg;*.png;*.gif|All Files|*.*";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                signimage = openFileDialog1.FileName;
                MessageBox.Show("Document selected for Signature: " + userimage, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void combasbra_SelectedIndexChanged(object sender, EventArgs e)
        {
            combasrole.Items.Clear(); string seldep = combasbra.Text;
            if (seldep == "IT")
            {
                combasrole.Items.Add("IT Coordinator"); combasrole.Items.Add("Systems Analyst");
                combasrole.Items.Add("Database Administrator"); combasrole.Items.Add("Web Developer");
            }
            else if (seldep == "Production")
            {
                combasrole.Items.Add("Production Manager"); combasrole.Items.Add("Production Supervisor");
                combasrole.Items.Add("Quality Manager"); combasrole.Items.Add("Machine Operator");
            }
            else if (seldep == "Finance")
            {
                combasrole.Items.Add("Analyst"); combasrole.Items.Add("Manager");
                combasrole.Items.Add("Assistant"); combasrole.Items.Add("Clerk");
            }
            else if (seldep == "HR")
            {
                combasrole.Items.Add("Staffing Coordinator"); combasrole.Items.Add("HR Analyst");
                combasrole.Items.Add("HR Supervisor"); combasrole.Items.Add("Personal Manager");
            }
            else if (seldep == "Sales")
            {
                combasrole.Items.Add("Sales Manager"); combasrole.Items.Add("Sales Support");
                combasrole.Items.Add("Sales Representative"); combasrole.Items.Add("Sales Consultant");
            }
            else if (seldep == "Accounting")
            {
                combasrole.Items.Add("Auditor"); combasrole.Items.Add("Management Accountant");
                combasrole.Items.Add("Accounting clerk"); combasrole.Items.Add("Cost Accountant");
                combasrole.Items.Add("Tax Accountant");
            }
            else if (seldep == "Marketing")
            {
                combasrole.Items.Add("Marketing Manager"); combasrole.Items.Add("Business Analyst"); 
                combasrole.Items.Add("Brand Manager"); combasrole.Items.Add("Social Media Manager"); combasrole.Items.Add("CopyWriter"); 
            }
        }

        private void EmpAdd_Load(object sender, EventArgs e)
        {
            try
            {
                if (connection.State != ConnectionState.Open)
                {
                    connection.Open();
                }
                string countQuery = "SELECT COUNT(*) FROM Empbasic"; SqlCommand countCmd = new SqlCommand(countQuery, connection);
                int recordCount = Convert.ToInt32(countCmd.ExecuteScalar());
                int nextEid = recordCount + 1; string formattedEid = "E" + nextEid; txtid.Text = formattedEid;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                connection.Close();
            }
        }
    }
}
