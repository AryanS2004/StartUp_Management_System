﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace STARTUP___MANAGEMENT___SYSTEM
{
    public partial class Stock : Form
    {
        private string connectionString = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\hp\Documents\Startup1.mdf;Integrated Security=True;Connect Timeout=30";
        private SqlConnection connection; private int sid; private string modsid, searchid;

        public Stock()
        {
            InitializeComponent(); connection = new SqlConnection(connectionString);
        }

        private void comaddprotype_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comaddprotype.SelectedItem != null && comaddprotype.SelectedItem.ToString() == "Manufactured")
            {
                labeladddate.Text = "Date Of Manufacture";
            }

            if (comaddprotype.SelectedItem != null && comaddprotype.SelectedItem.ToString() == "Bought")
            {
                labeladddate.Text = "Date Of Purchase";
            }
        }

        private void Stock_Load(object sender, EventArgs e)
        {
            PopulateComboBox();
        }

        private void PopulateComboBox()
        {
            try
            {
                connection.Open(); string countQuery = "SELECT COUNT(*) FROM stocks;"; string query2 = "SELECT sid FROM stocks;";
                SqlCommand countCmd = new SqlCommand(countQuery, connection); int recordCount = Convert.ToInt32(countCmd.ExecuteScalar());
                int nextEid = recordCount + 1; string formattedEid = "I" + nextEid; txtaddproid.Text = formattedEid;
                using (SqlCommand command = new SqlCommand(query2, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            int sid = reader.GetInt32(0); commodproid.Items.Add("I" + sid); comviewdocid.Items.Add("I" + sid);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        private void btnadditeam_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do you want to save the information?", "Save Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                string pname = txtaddproname.Text; string ptype = comaddprotype.Text; string pfield = txtaddprofield.Text;
                DateTime datepro = dateaddman.Value; float pprice = Convert.ToSingle(txtaddpropri.Text);
                string pdesc = txtaddprodesc.Text; int pquan = Convert.ToInt32(numaddproquan.Value); getsid();
                try
                {
                    connection.Open();
                    string insertQuery = "INSERT INTO stocks (sid, pname, ptype, pfield, datepro, pprice, pdesc, pquan) " +
                                         "VALUES (@sid, @pname, @ptype, @pfield, @datepro, @pprice, @pdesc, @pquan)";
                    using (SqlCommand cmd = new SqlCommand(insertQuery, connection))
                    {
                        cmd.Parameters.AddWithValue("@sid", sid); cmd.Parameters.AddWithValue("@pname", pname);
                        cmd.Parameters.AddWithValue("@ptype", ptype); cmd.Parameters.AddWithValue("@pfield", pfield);
                        cmd.Parameters.AddWithValue("@datepro", datepro); cmd.Parameters.AddWithValue("@pprice", pprice);
                        cmd.Parameters.AddWithValue("@pdesc", pdesc); cmd.Parameters.AddWithValue("@pquan", pquan); cmd.ExecuteNonQuery();
                    }
                    MessageBox.Show("Information saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error saving data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    connection.Close();
                }
            }
        }

        private void getsid()
        {
            string productId = txtaddproid.Text; int indexOfI = productId.IndexOf('I');
            if (indexOfI != -1)
            {
                string numericPart = productId.Substring(indexOfI + 1); if (int.TryParse(numericPart, out sid)) { }
            }
        }

        private void commodproid_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedValue = commodproid.SelectedItem.ToString();
            modsid = selectedValue.Substring(1); SearchDataInTables(modsid);
        }

        private void SearchDataInTables(string tranId)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open(); string investQuery = "SELECT * FROM stocks WHERE sid = '" + tranId + "'";
                using (SqlCommand investCommand = new SqlCommand(investQuery, connection))
                {
                    using (SqlDataReader investReader = investCommand.ExecuteReader())
                    {
                        if (investReader.Read())
                        {
                            txtmodproname.Text = investReader["pname"].ToString(); int teamid = Convert.ToInt32(investReader["pprice"]);
                            txtmodpropri.Text = teamid.ToString(); commodprotype.Text = investReader["ptype"].ToString();
                            txtmodprofield.Text = investReader["pfield"].ToString(); txtmodprodesc.Text = investReader["pdesc"].ToString();
                            nummodproquan.Text = investReader["pquan"].ToString(); DateTime datepro;
                            if (DateTime.TryParse(investReader["datepro"].ToString(), out datepro))
                            {
                                datemodman.Value = datepro;
                            }
                            return;
                        }
                    }
                }
            }
        }

        private void btnmodsave_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do you want to save the information?", "Save Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                string pname = txtmodproname.Text; string ptype = commodprotype.Text; string pfield = txtmodprofield.Text;
                DateTime datepro = datemodman.Value; float pprice = Convert.ToSingle(txtmodpropri.Text);
                string pdesc = txtmodprodesc.Text; int pquan = Convert.ToInt32(nummodproquan.Value);
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open(); string updateQuery = "UPDATE stocks SET pname = @pname, ptype = @ptype, pfield = @pfield, datepro = @datepro, " +
                        "pprice = @pprice, pdesc = @pdesc, pquan = @pquan WHERE sid = @sid";
                    using (SqlCommand cmd = new SqlCommand(updateQuery, connection))
                    {
                        cmd.Parameters.AddWithValue("@sid", modsid); cmd.Parameters.AddWithValue("@pname", pname);
                        cmd.Parameters.AddWithValue("@ptype", ptype); cmd.Parameters.AddWithValue("@pfield", pfield);
                        cmd.Parameters.AddWithValue("@datepro", datepro); cmd.Parameters.AddWithValue("@pprice", pprice);
                        cmd.Parameters.AddWithValue("@pdesc", pdesc); cmd.Parameters.AddWithValue("@pquan", pquan);
                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Data updated.");
                        }
                        else
                        {
                            MessageBox.Show("No matching record found in loantran table.");
                        }
                    }
                }
            }
        }

        private void btnviewdoc_Click(object sender, EventArgs e)
        {
            btnviewdoc.BackColor = Color.LimeGreen; dataGridView1.Visible = true;
            if (comviewdocid.Text == "")
            {
                DataSet dataSet0 = new DataSet(); string query0 = "SELECT * FROM stocks"; connection.Open();
                using (SqlDataAdapter adapter0 = new SqlDataAdapter(query0, connection))
                {
                    adapter0.Fill(dataSet0, "All_Employee_Attendance");
                }
                dataGridView1.DataSource = dataSet0.Tables["All_Employee_Attendance"]; connection.Close();
            }
            else
            {
                string selectedValue = comviewdocid.SelectedItem.ToString(); searchid = selectedValue.Substring(1);
                DataSet dataSet0 = new DataSet(); string query0 = "SELECT * FROM stocks WHERE sid = @tranId "; connection.Open();
                using (SqlDataAdapter adapter0 = new SqlDataAdapter(query0, connection))
                {
                    adapter0.SelectCommand.Parameters.AddWithValue("@tranId", searchid); adapter0.Fill(dataSet0, "Employee");
                }
                dataGridView1.DataSource = dataSet0.Tables["Employee"]; connection.Close();
            }
        }
    }
}