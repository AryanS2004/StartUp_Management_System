﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace STARTUP___MANAGEMENT___SYSTEM
{
    public partial class EmpAttend : Form
    {
        private string connectionString = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\hp\Documents\Startup1.mdf;Integrated Security=True;Connect Timeout=30";
        private SqlConnection connection; private int eid, searchid; private string fname, lname, deprt, role;

        public EmpAttend()
        {
            InitializeComponent(); connection = new SqlConnection(connectionString); this.FormClosing += EmployeePage_FormClosing;
            timetoin.Format = DateTimePickerFormat.Time; timetoin.ShowUpDown = true;
            timetoout.Format = DateTimePickerFormat.Time; timetoout.ShowUpDown = true;
        }
 
        private void yesradio_CheckedChanged(object sender, EventArgs e)
        {
            if (radiotoyes.Checked)
            {
                label8.Visible = true; timetoin.Visible = true; timetoout.Visible = true; label7.Visible = true;
                DateTime inTime = timetoin.Value; DateTime outTime = inTime.AddHours(10);
                timetoout.Value = outTime; label7.Visible = true;
            }
            else
            {
                label8.Visible = false; timetoin.Visible = false;
                timetoout.Visible = false; label7.Visible = false;
            }
        }

        private void noradio_CheckedChanged(object sender, EventArgs e)
        {
            if (radiotono.Checked)
            {
                timetoin.Visible = false; timetoout.Visible = false;
                label7.Visible = false; label8.Visible = false;
            }
        }

        private void backbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void EmployeePage_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult result = MessageBox.Show("Do you want to close this page ? Unsaved data will be lost.", "Close Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.No)
            {
                e.Cancel = true;
            }
        }

        private void Savebtn_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do you want to save the information?", "Save Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open(); DateTime dateattend = dateat.Value;
                        int overtime = 0; DateTime intime = DateTime.MinValue; DateTime outtime = DateTime.MinValue;
                        if (radiotoyes.Checked)
                        {
                            intime = timetoin.Value; outtime = timetoout.Value; overtime = 1;
                        }
                        if (radiotono.Checked)
                        {
                            intime = DateTime.MinValue; outtime = DateTime.MinValue; overtime = 0;
                        }
                        
                        string query = "INSERT INTO Empattend (intime, outtime, dateattend, overtime, Eid) " +
                                        "VALUES (@Intime, @Outtime, @Dateattend, @Overtime, @Eid)";
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@Intime", intime); command.Parameters.AddWithValue("@Outtime", outtime);
                            command.Parameters.AddWithValue("@Dateattend", dateattend); command.Parameters.AddWithValue("@Overtime", overtime);
                            command.Parameters.AddWithValue("@Eid", eid);
                            int rowsAffected = command.ExecuteNonQuery();                                                     
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error:" + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Information not saved.", "Cancelled", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            MessageBox.Show("Information saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void EmpAttend_Load(object sender, EventArgs e)
        {
            try
            {
                connection.Open(); string query = "SELECT Eid, fname, lname FROM Empbasic";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        comtoeid.Items.Clear(); 
                        while (reader.Read())
                        {
                            int eid = reader.GetInt32(0); string firstname = reader.GetString(1);
                            string lastname = reader.GetString(2); string displayString = "E" + eid + " (" + firstname + " " + lastname + ")";
                            comtoeid.Items.Add(displayString); comvieweid.Items.Add(displayString);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        private void comtoeid_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comtoeid.SelectedItem.ToString() != "")
            {
                string eidstr = comtoeid.Text; int startlead = eidstr.IndexOf('E') + 1; int endlead = eidstr.IndexOf(' ', startlead);
                if (startlead != -1 && endlead != -1)
                {
                    string leadString = eidstr.Substring(startlead, endlead - startlead); eid = Convert.ToInt32(leadString);
                }
                 try
                {
                    connection.Open(); string query = "SELECT fname, lname, asbranch, asrole FROM Empbasic WHERE Eid = @Eid";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Eid", eid);
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                fname = reader.GetString(0); lname = reader.GetString(1); deprt = reader.GetString(2);
                                role = reader.GetString(3); txttofirst.Text = fname + " " + lname; 
                                txttodep.Text = deprt; txttorole.Text = role;
                            }
                            else
                            {
                                Console.WriteLine("No data found for the specified Eid.");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: "+ ex.Message);
                }
            }
        }

        private void btnviewemp_Click(object sender, EventArgs e)
        {
            if (comvieweid.Text != "")
            {
                MessageBox.Show("Employee Found.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information); dataGridView1.Visible = true;
            }
        }

        private void comvieweid_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comvieweid.Text == "")
            {
                DataSet dataSet0 = new DataSet(); string query0 = "SELECT * FROM Empattend"; connection.Open();
                using (SqlDataAdapter adapter0 = new SqlDataAdapter(query0, connection))
                {
                    adapter0.Fill(dataSet0, "All_Employee_Attendance");
                }
                dataGridView1.DataSource = dataSet0.Tables["All_Employee_Attendance"]; connection.Close();
            }
            else
            {
                searchid = ExtractIdFromComboBox(comvieweid.Text); DataSet dataSet0 = new DataSet();
                string query0 = "SELECT * FROM Empattend WHERE Eid = @tranId "; connection.Open();
                using (SqlDataAdapter adapter0 = new SqlDataAdapter(query0, connection))
                {
                    adapter0.SelectCommand.Parameters.AddWithValue("@tranId", searchid); adapter0.Fill(dataSet0, "Employee");
                }
                dataGridView1.DataSource = dataSet0.Tables["Employee"]; connection.Close();
            }
        }

        private int ExtractIdFromComboBox(string comboText)
        {
            int startIdx = comboText.IndexOf('E') + 1; int endIdx = comboText.IndexOf(' ', startIdx);
            if (startIdx != -1 && endIdx != -1)
            {
                string idStr = comboText.Substring(startIdx, endIdx - startIdx); return Convert.ToInt32(idStr);
            }
            return -1;
        }
    }
}