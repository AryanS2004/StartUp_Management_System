﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace STARTUP___MANAGEMENT___SYSTEM
{
    public partial class ModifyEmployee : Form
    {
        private string connectionString = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\hp\Documents\Startup1.mdf;Integrated Security=True;Connect Timeout=30";
        private SqlConnection connection; int Eid; string empimage, signimage, fname, lname, asbranch, asrole, contactnum;
        string identitype, altcontactnum, idnum, localadd, email, parmanentadd; int salary, bonus; DateTime dateofjoin, dateagritill, datesalgive;

        public ModifyEmployee()
        {
            InitializeComponent(); connection = new SqlConnection(connectionString);
        }

        private void btnmodsearch_Click(object sender, EventArgs e)
        {
            btnmodsearch.BackColor = Color.LimeGreen; Eid = ExtractIdFromComboBox(commodeid.Text);
            tabControl1.Visible = true; SearchDataInTables(Eid); btnmodrem.Visible = true;
        }

        private int ExtractIdFromComboBox(string comboText)
        {
            int startIdx = comboText.IndexOf('E') + 1; int endIdx = comboText.IndexOf(' ', startIdx);
            if (startIdx != -1 && endIdx != -1)
            {
                string idStr = comboText.Substring(startIdx, endIdx - startIdx); return Convert.ToInt32(idStr);
            }
            return -1;
        }

        private void SearchDataInTables(int tranId)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open(); string investQuery = "SELECT * FROM Empbasic WHERE Eid = '" + tranId + "'";
                using (SqlCommand investCommand = new SqlCommand(investQuery, connection))
                {
                    using (SqlDataReader investReader = investCommand.ExecuteReader())
                    {
                        if (investReader.Read())
                        {
                            txtbasefirstname.Text = investReader["fname"].ToString(); textbaslastname.Text = investReader["lname"].ToString();
                            combasbra.Text = investReader["asbranch"].ToString(); combasrole.Text = investReader["asrole"].ToString();
                            txtbasnum.Text = investReader["contactnum"].ToString(); DateTime dateofjoin;
                            if (DateTime.TryParse(investReader["dateofjoin"].ToString(), out dateofjoin))
                            {
                                dateadjoin.Value = dateofjoin;
                            }
                            comadidtype.Text = investReader["identitype"].ToString(); txtaddaltnum.Text = investReader["altcontactnum"].ToString();
                            txtadidnum.Text = investReader["idnum"].ToString(); txtadlocaladd.Text = investReader["localadd"].ToString();
                            txtemail.Text = investReader["email"].ToString(); txtadparadd.Text = investReader["parmanentadd"].ToString();
                            txtfinsal.Text = investReader["salary"].ToString(); DateTime dateagritill; signimage = investReader["imgsign"].ToString();
                            if (DateTime.TryParse(investReader["dateagritill"].ToString(), out dateagritill))
                            {
                                datefinagree.Value = dateagritill;
                            }
                            txtfinbonus.Text = investReader["bonus"].ToString(); empimage = investReader["imgemp"].ToString(); DateTime datesalgive;
                            if (DateTime.TryParse(investReader["datesalgive"].ToString(), out datesalgive))
                            {
                                datefinsalg.Value = datesalgive;
                            }
                            return;
                        }
                    }
                }
            }
        }

        private void btnfinsave_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do you want to save the information?", "Save Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                fname = txtbasefirstname.Text; lname = textbaslastname.Text; asbranch = combasbra.Text; asrole = combasrole.Text; contactnum = txtbasnum.Text;
                dateofjoin = dateadjoin.Value; identitype = comadidtype.Text; altcontactnum = txtaddaltnum.Text; idnum = txtadidnum.Text; localadd = txtadlocaladd.Text;
                email = txtemail.Text; parmanentadd = txtadparadd.Text; salary = Convert.ToInt32(txtfinsal.Text); dateagritill = datefinagree.Value;
                bonus = Convert.ToInt32(txtfinbonus.Text); datesalgive = datefinsalg.Value;

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string updateQuery = "UPDATE Empbasic SET fname = @fname, lname = @lname, asbranch = @asbranch, asrole = @asrole, contactnum = @contactnum, " +
                        "dateofjoin = @dateofjoin, identitype = @identitype, altcontactnum = @altcontactnum, idnum = @idnum, localadd = @localadd, " +
                        "email = @email, parmanentadd = @parmanentadd, salary = @salary, dateagritill = @dateagritill, bonus = @bonus, " +
                        "datesalgive = @datesalgive, imgemp = @imgemp, imgsign = @imgsign WHERE Eid = @Eid";

                    using (SqlCommand cmd = new SqlCommand(updateQuery, connection))
                    {
                        cmd.Parameters.AddWithValue("@fname", fname); cmd.Parameters.AddWithValue("@lname", lname);
                        cmd.Parameters.AddWithValue("@asbranch", asbranch); cmd.Parameters.AddWithValue("@asrole", asrole);
                        cmd.Parameters.AddWithValue("@contactnum", contactnum); cmd.Parameters.AddWithValue("@dateofjoin", dateofjoin);
                        cmd.Parameters.AddWithValue("@identitype", identitype); cmd.Parameters.AddWithValue("@altcontactnum", altcontactnum);
                        cmd.Parameters.AddWithValue("@idnum", idnum); cmd.Parameters.AddWithValue("@localadd", localadd);
                        cmd.Parameters.AddWithValue("@email", email); cmd.Parameters.AddWithValue("@parmanentadd", parmanentadd);
                        cmd.Parameters.AddWithValue("@salary", salary); cmd.Parameters.AddWithValue("@dateagritill", dateagritill);
                        cmd.Parameters.AddWithValue("@bonus", bonus); cmd.Parameters.AddWithValue("@datesalgive", datesalgive);
                        cmd.Parameters.AddWithValue("@imgemp", empimage); cmd.Parameters.AddWithValue("@imgsign", signimage);
                        cmd.Parameters.AddWithValue("@Eid", Eid); int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Data updated.");
                        }
                        else
                        {
                            MessageBox.Show("No matching record found in loantran table.");
                        }
                    }
                }
            }
        }

        private void ModifyEmployee_Load(object sender, EventArgs e)
        {
            PopulateComboBox();
        }

        private void PopulateComboBox()
        {
            try
            {
                connection.Open(); string query = "SELECT Eid, fname, lname FROM Empbasic";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            int eid = reader.GetInt32(0); string firstName = reader.GetString(1); string lastName = reader.GetString(2); 
                            string displayString = "E" + eid + " (" + firstName + " " + lastName + ")"; commodeid.Items.Add(displayString);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        private void btnbasnext_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = advemp;
        }

        private void btnadnext_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = finalemp;
        }

        private void btnfinimemp_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog(); openFileDialog1.Filter = "Image Files|*.bmp;*.jpg;*.jpeg;*.png;*.gif|All Files|*.*";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                empimage = openFileDialog1.FileName; MessageBox.Show("Document selected for Image : " + empimage, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnfinimgsig_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog(); openFileDialog1.Filter = "Image Files|*.bmp;*.jpg;*.jpeg;*.png;*.gif|All Files|*.*";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                signimage = openFileDialog1.FileName; MessageBox.Show("Document selected for Image : " + signimage, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnmodrem_Click(object sender, EventArgs e)
        {
            using (SqlCommand commandTable1 = new SqlCommand("DELETE FROM Empbasis WHERE tranid = '" + Eid + "';", connection))
            {
                try
                {
                    int rowsAffectedTable1 = commandTable1.ExecuteNonQuery();
                    if (rowsAffectedTable1 > 0)
                    {
                        Console.WriteLine("Data deleted from Teams.");
                    }
                    else
                    {
                        Console.WriteLine("No data deleted from Table1. Check your condition or data existence.");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error deleting from Employee tabel:" + ex.Message);
                }
            }
        }

        private void combasbra_SelectedIndexChanged(object sender, EventArgs e)
        {
            combasrole.Items.Clear(); string seldep = combasbra.Text;
            if (seldep == "IT")
            {
                combasrole.Items.Add("IT Coordinator"); combasrole.Items.Add("Systems Analyst");
                combasrole.Items.Add("Database Administrator"); combasrole.Items.Add("Web Developer");
            }
            else if (seldep == "Production")
            {
                combasrole.Items.Add("Production Manager"); combasrole.Items.Add("Production Supervisor");
                combasrole.Items.Add("Quality Manager"); combasrole.Items.Add("Machine Operator");
            }
            else if (seldep == "Finance")
            {
                combasrole.Items.Add("Analyst"); combasrole.Items.Add("Manager");
                combasrole.Items.Add("Assistant"); combasrole.Items.Add("Clerk");
            }
            else if (seldep == "HR")
            {
                combasrole.Items.Add("Staffing Coordinator"); combasrole.Items.Add("HR Analyst");
                combasrole.Items.Add("HR Supervisor"); combasrole.Items.Add("Personal Manager");
            }
            else if (seldep == "Sales")
            {
                combasrole.Items.Add("Sales Manager"); combasrole.Items.Add("Sales Support");
                combasrole.Items.Add("Sales Representative"); combasrole.Items.Add("Sales Consultant");
            }
            else if (seldep == "Accounting")
            {
                combasrole.Items.Add("Auditor"); combasrole.Items.Add("Management Accountant");
                combasrole.Items.Add("Accounting clerk"); combasrole.Items.Add("Cost Accountant");
                combasrole.Items.Add("Tax Accountant");
            }
            else if (seldep == "Marketing")
            {
                combasrole.Items.Add("Marketing Manager"); combasrole.Items.Add("Business Analyst");
                combasrole.Items.Add("Brand Manager"); combasrole.Items.Add("Social Media Manager"); combasrole.Items.Add("CopyWriter");
            }
        }
    }
}