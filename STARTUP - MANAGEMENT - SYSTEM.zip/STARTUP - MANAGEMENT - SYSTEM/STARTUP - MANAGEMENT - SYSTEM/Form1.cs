﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace STARTUP___MANAGEMENT___SYSTEM
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            string user, pass; user = untext.Text; pass = passtext.Text;
            if (user == "admin" && pass == "ad1234")
            {
                label4.Visible = true; label1.Visible = false; passtext.Visible = false;
                button1.Visible = false; untext.Visible = false; label2.Visible = false; pb.Visible = true;
                for (int i = 0; i < 100; i++)
                {
                    pb.Value++; 
                    if (pb.Value==33||pb.Value==66||pb.Value==100)
                    {
                        await Task.Delay(1000);
                    }
                }
                this.Hide(); var newForm = new admin_page(); newForm.Show();    
            }
            else
            {
                MessageBox.Show("UNKNOWN / WRONG ID OR PASSWORD. TRY AGAIN WITH THE RIGHT DETAILS.", "SURUWAT SAYS..", MessageBoxButtons.OK);
                untext.Text = ""; passtext.Text = "";
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Welcome to our Helpdesk! 🚀 If you ever need assistance or have questions, feel free to reach out to us. For emergencies, " +
             "you can contact us at 8769961080 or email us at aryaleena2004@gmail.com. Thank you for choosing our app to elevate your startup journey! 💼✨");
        }  
    }
}