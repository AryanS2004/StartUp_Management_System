﻿namespace STARTUP___MANAGEMENT___SYSTEM
{
    partial class ModifyEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ModifyEmployee));
            this.label2 = new System.Windows.Forms.Label();
            this.btnmodsearch = new System.Windows.Forms.Button();
            this.btnmodrem = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.addemp = new System.Windows.Forms.TabPage();
            this.btnbasnext = new System.Windows.Forms.Button();
            this.combasrole = new System.Windows.Forms.ComboBox();
            this.combasbra = new System.Windows.Forms.ComboBox();
            this.txtbasnum = new System.Windows.Forms.TextBox();
            this.textbaslastname = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtbasefirstname = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.advemp = new System.Windows.Forms.TabPage();
            this.btnadnext = new System.Windows.Forms.Button();
            this.txtadparadd = new System.Windows.Forms.TextBox();
            this.radioadno = new System.Windows.Forms.RadioButton();
            this.radioadyes = new System.Windows.Forms.RadioButton();
            this.label8 = new System.Windows.Forms.Label();
            this.dateadjoin = new System.Windows.Forms.DateTimePicker();
            this.txtadlocaladd = new System.Windows.Forms.TextBox();
            this.txtadidnum = new System.Windows.Forms.TextBox();
            this.labadidnum = new System.Windows.Forms.Label();
            this.comadidtype = new System.Windows.Forms.ComboBox();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.txtaddaltnum = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.finalemp = new System.Windows.Forms.TabPage();
            this.btnfinimgsig = new System.Windows.Forms.Button();
            this.btnfinimemp = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.datefinagree = new System.Windows.Forms.DateTimePicker();
            this.label17 = new System.Windows.Forms.Label();
            this.btnfinsave = new System.Windows.Forms.Button();
            this.datefinsalg = new System.Windows.Forms.DateTimePicker();
            this.label18 = new System.Windows.Forms.Label();
            this.txtfinbonus = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txtfinsal = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.commodeid = new System.Windows.Forms.ComboBox();
            this.tabControl1.SuspendLayout();
            this.addemp.SuspendLayout();
            this.advemp.SuspendLayout();
            this.finalemp.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(23, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(316, 29);
            this.label2.TabIndex = 15;
            this.label2.Text = "Search Employee Unique ID";
            // 
            // btnmodsearch
            // 
            this.btnmodsearch.BackColor = System.Drawing.Color.Orange;
            this.btnmodsearch.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnmodsearch.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnmodsearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmodsearch.Location = new System.Drawing.Point(699, 19);
            this.btnmodsearch.Name = "btnmodsearch";
            this.btnmodsearch.Size = new System.Drawing.Size(127, 48);
            this.btnmodsearch.TabIndex = 17;
            this.btnmodsearch.Text = "Search";
            this.btnmodsearch.UseVisualStyleBackColor = false;
            this.btnmodsearch.Click += new System.EventHandler(this.btnmodsearch_Click);
            // 
            // btnmodrem
            // 
            this.btnmodrem.BackColor = System.Drawing.Color.Red;
            this.btnmodrem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnmodrem.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnmodrem.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmodrem.Location = new System.Drawing.Point(1112, 17);
            this.btnmodrem.Name = "btnmodrem";
            this.btnmodrem.Size = new System.Drawing.Size(231, 50);
            this.btnmodrem.TabIndex = 20;
            this.btnmodrem.Text = "Remove Employee";
            this.btnmodrem.UseVisualStyleBackColor = false;
            this.btnmodrem.Visible = false;
            this.btnmodrem.Click += new System.EventHandler(this.btnmodrem_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.addemp);
            this.tabControl1.Controls.Add(this.advemp);
            this.tabControl1.Controls.Add(this.finalemp);
            this.tabControl1.Font = new System.Drawing.Font("Bookman Old Style", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.HotTrack = true;
            this.tabControl1.Location = new System.Drawing.Point(12, 103);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1335, 554);
            this.tabControl1.TabIndex = 21;
            this.tabControl1.Visible = false;
            // 
            // addemp
            // 
            this.addemp.BackColor = System.Drawing.Color.Wheat;
            this.addemp.Controls.Add(this.btnbasnext);
            this.addemp.Controls.Add(this.combasrole);
            this.addemp.Controls.Add(this.combasbra);
            this.addemp.Controls.Add(this.txtbasnum);
            this.addemp.Controls.Add(this.textbaslastname);
            this.addemp.Controls.Add(this.label6);
            this.addemp.Controls.Add(this.txtbasefirstname);
            this.addemp.Controls.Add(this.label1);
            this.addemp.Controls.Add(this.label4);
            this.addemp.Controls.Add(this.label3);
            this.addemp.Controls.Add(this.label7);
            this.addemp.Location = new System.Drawing.Point(4, 35);
            this.addemp.Name = "addemp";
            this.addemp.Padding = new System.Windows.Forms.Padding(3);
            this.addemp.Size = new System.Drawing.Size(1327, 515);
            this.addemp.TabIndex = 0;
            this.addemp.Text = "Basic Details";
            // 
            // btnbasnext
            // 
            this.btnbasnext.BackColor = System.Drawing.Color.Lime;
            this.btnbasnext.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnbasnext.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnbasnext.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbasnext.Location = new System.Drawing.Point(586, 415);
            this.btnbasnext.Name = "btnbasnext";
            this.btnbasnext.Size = new System.Drawing.Size(170, 62);
            this.btnbasnext.TabIndex = 8;
            this.btnbasnext.Text = "Next Page";
            this.btnbasnext.UseVisualStyleBackColor = false;
            this.btnbasnext.Click += new System.EventHandler(this.btnbasnext_Click);
            // 
            // combasrole
            // 
            this.combasrole.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combasrole.FormattingEnabled = true;
            this.combasrole.Location = new System.Drawing.Point(968, 164);
            this.combasrole.Name = "combasrole";
            this.combasrole.Size = new System.Drawing.Size(270, 37);
            this.combasrole.TabIndex = 5;
            // 
            // combasbra
            // 
            this.combasbra.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combasbra.FormattingEnabled = true;
            this.combasbra.Items.AddRange(new object[] {
            "IT",
            "Production",
            "Finance",
            "HR",
            "Sales",
            "Accounting",
            "Marketing"});
            this.combasbra.Location = new System.Drawing.Point(301, 164);
            this.combasbra.Name = "combasbra";
            this.combasbra.Size = new System.Drawing.Size(270, 37);
            this.combasbra.TabIndex = 4;
            this.combasbra.SelectedIndexChanged += new System.EventHandler(this.combasbra_SelectedIndexChanged);
            // 
            // txtbasnum
            // 
            this.txtbasnum.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbasnum.Location = new System.Drawing.Point(301, 285);
            this.txtbasnum.Multiline = true;
            this.txtbasnum.Name = "txtbasnum";
            this.txtbasnum.Size = new System.Drawing.Size(270, 37);
            this.txtbasnum.TabIndex = 5;
            this.txtbasnum.WordWrap = false;
            // 
            // textbaslastname
            // 
            this.textbaslastname.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textbaslastname.Location = new System.Drawing.Point(968, 48);
            this.textbaslastname.Multiline = true;
            this.textbaslastname.Name = "textbaslastname";
            this.textbaslastname.Size = new System.Drawing.Size(270, 37);
            this.textbaslastname.TabIndex = 3;
            this.textbaslastname.WordWrap = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(760, 56);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(128, 29);
            this.label6.TabIndex = 26;
            this.label6.Text = "Last Name";
            // 
            // txtbasefirstname
            // 
            this.txtbasefirstname.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbasefirstname.Location = new System.Drawing.Point(301, 50);
            this.txtbasefirstname.Multiline = true;
            this.txtbasefirstname.Name = "txtbasefirstname";
            this.txtbasefirstname.Size = new System.Drawing.Size(270, 37);
            this.txtbasefirstname.TabIndex = 2;
            this.txtbasefirstname.WordWrap = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(760, 170);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(141, 29);
            this.label1.TabIndex = 24;
            this.label1.Text = "Designation";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(27, 168);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(244, 29);
            this.label4.TabIndex = 23;
            this.label4.Text = "Assigned Department";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(27, 288);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(193, 29);
            this.label3.TabIndex = 22;
            this.label3.Text = "Contact Number ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(27, 52);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(131, 29);
            this.label7.TabIndex = 19;
            this.label7.Text = "First Name";
            // 
            // advemp
            // 
            this.advemp.BackColor = System.Drawing.Color.LightCoral;
            this.advemp.Controls.Add(this.btnadnext);
            this.advemp.Controls.Add(this.txtadparadd);
            this.advemp.Controls.Add(this.radioadno);
            this.advemp.Controls.Add(this.radioadyes);
            this.advemp.Controls.Add(this.label8);
            this.advemp.Controls.Add(this.dateadjoin);
            this.advemp.Controls.Add(this.txtadlocaladd);
            this.advemp.Controls.Add(this.txtadidnum);
            this.advemp.Controls.Add(this.labadidnum);
            this.advemp.Controls.Add(this.comadidtype);
            this.advemp.Controls.Add(this.txtemail);
            this.advemp.Controls.Add(this.txtaddaltnum);
            this.advemp.Controls.Add(this.label9);
            this.advemp.Controls.Add(this.label10);
            this.advemp.Controls.Add(this.label11);
            this.advemp.Controls.Add(this.label12);
            this.advemp.Controls.Add(this.label14);
            this.advemp.Location = new System.Drawing.Point(4, 35);
            this.advemp.Name = "advemp";
            this.advemp.Padding = new System.Windows.Forms.Padding(3);
            this.advemp.Size = new System.Drawing.Size(1327, 515);
            this.advemp.TabIndex = 1;
            this.advemp.Text = "Advance Details";
            // 
            // btnadnext
            // 
            this.btnadnext.BackColor = System.Drawing.Color.Lime;
            this.btnadnext.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnadnext.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnadnext.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadnext.Location = new System.Drawing.Point(621, 417);
            this.btnadnext.Name = "btnadnext";
            this.btnadnext.Size = new System.Drawing.Size(170, 62);
            this.btnadnext.TabIndex = 11;
            this.btnadnext.Text = "Next Page";
            this.btnadnext.UseVisualStyleBackColor = false;
            this.btnadnext.Click += new System.EventHandler(this.btnadnext_Click);
            // 
            // txtadparadd
            // 
            this.txtadparadd.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtadparadd.Location = new System.Drawing.Point(1080, 357);
            this.txtadparadd.Multiline = true;
            this.txtadparadd.Name = "txtadparadd";
            this.txtadparadd.Size = new System.Drawing.Size(452, 132);
            this.txtadparadd.TabIndex = 58;
            this.txtadparadd.Visible = false;
            // 
            // radioadno
            // 
            this.radioadno.AutoSize = true;
            this.radioadno.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioadno.Location = new System.Drawing.Point(1231, 313);
            this.radioadno.Name = "radioadno";
            this.radioadno.Size = new System.Drawing.Size(66, 33);
            this.radioadno.TabIndex = 9;
            this.radioadno.TabStop = true;
            this.radioadno.Text = "No";
            this.radioadno.UseVisualStyleBackColor = true;
            // 
            // radioadyes
            // 
            this.radioadyes.AutoSize = true;
            this.radioadyes.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioadyes.Location = new System.Drawing.Point(1028, 318);
            this.radioadyes.Name = "radioadyes";
            this.radioadyes.Size = new System.Drawing.Size(76, 33);
            this.radioadyes.TabIndex = 8;
            this.radioadyes.TabStop = true;
            this.radioadyes.Text = "Yes";
            this.radioadyes.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(747, 310);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(273, 58);
            this.label8.TabIndex = 55;
            this.label8.Text = "Parmanent Address \r\n(Same as local address)";
            // 
            // dateadjoin
            // 
            this.dateadjoin.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateadjoin.Location = new System.Drawing.Point(254, 36);
            this.dateadjoin.Name = "dateadjoin";
            this.dateadjoin.Size = new System.Drawing.Size(270, 34);
            this.dateadjoin.TabIndex = 2;
            this.dateadjoin.Value = new System.DateTime(2023, 11, 15, 0, 20, 47, 0);
            // 
            // txtadlocaladd
            // 
            this.txtadlocaladd.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtadlocaladd.Location = new System.Drawing.Point(254, 207);
            this.txtadlocaladd.Multiline = true;
            this.txtadlocaladd.Name = "txtadlocaladd";
            this.txtadlocaladd.Size = new System.Drawing.Size(452, 132);
            this.txtadlocaladd.TabIndex = 6;
            // 
            // txtadidnum
            // 
            this.txtadidnum.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtadidnum.Location = new System.Drawing.Point(1028, 113);
            this.txtadidnum.Multiline = true;
            this.txtadidnum.Name = "txtadidnum";
            this.txtadidnum.Size = new System.Drawing.Size(270, 37);
            this.txtadidnum.TabIndex = 5;
            this.txtadidnum.WordWrap = false;
            // 
            // labadidnum
            // 
            this.labadidnum.AutoSize = true;
            this.labadidnum.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labadidnum.Location = new System.Drawing.Point(747, 119);
            this.labadidnum.Name = "labadidnum";
            this.labadidnum.Size = new System.Drawing.Size(129, 29);
            this.labadidnum.TabIndex = 49;
            this.labadidnum.Text = "ID Number";
            // 
            // comadidtype
            // 
            this.comadidtype.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comadidtype.FormattingEnabled = true;
            this.comadidtype.Items.AddRange(new object[] {
            "Aadhar Card"});
            this.comadidtype.Location = new System.Drawing.Point(1028, 30);
            this.comadidtype.Name = "comadidtype";
            this.comadidtype.Size = new System.Drawing.Size(270, 37);
            this.comadidtype.TabIndex = 3;
            // 
            // txtemail
            // 
            this.txtemail.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtemail.Location = new System.Drawing.Point(1028, 202);
            this.txtemail.Multiline = true;
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(270, 37);
            this.txtemail.TabIndex = 7;
            this.txtemail.WordWrap = false;
            // 
            // txtaddaltnum
            // 
            this.txtaddaltnum.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaddaltnum.Location = new System.Drawing.Point(254, 115);
            this.txtaddaltnum.Multiline = true;
            this.txtaddaltnum.Name = "txtaddaltnum";
            this.txtaddaltnum.Size = new System.Drawing.Size(270, 37);
            this.txtaddaltnum.TabIndex = 4;
            this.txtaddaltnum.WordWrap = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(15, 119);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(218, 29);
            this.label9.TabIndex = 45;
            this.label9.Text = "Alternative Number";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(15, 213);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(166, 29);
            this.label10.TabIndex = 44;
            this.label10.Text = "Local Address";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(747, 35);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(235, 29);
            this.label11.TabIndex = 43;
            this.label11.Text = "Identification Id Type";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(747, 210);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(74, 29);
            this.label12.TabIndex = 42;
            this.label12.Text = "Email";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(17, 41);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(178, 29);
            this.label14.TabIndex = 41;
            this.label14.Text = "Date Of Joining";
            // 
            // finalemp
            // 
            this.finalemp.BackColor = System.Drawing.Color.PaleVioletRed;
            this.finalemp.Controls.Add(this.btnfinimgsig);
            this.finalemp.Controls.Add(this.btnfinimemp);
            this.finalemp.Controls.Add(this.label15);
            this.finalemp.Controls.Add(this.label16);
            this.finalemp.Controls.Add(this.datefinagree);
            this.finalemp.Controls.Add(this.label17);
            this.finalemp.Controls.Add(this.btnfinsave);
            this.finalemp.Controls.Add(this.datefinsalg);
            this.finalemp.Controls.Add(this.label18);
            this.finalemp.Controls.Add(this.txtfinbonus);
            this.finalemp.Controls.Add(this.label19);
            this.finalemp.Controls.Add(this.txtfinsal);
            this.finalemp.Controls.Add(this.label21);
            this.finalemp.Location = new System.Drawing.Point(4, 35);
            this.finalemp.Name = "finalemp";
            this.finalemp.Size = new System.Drawing.Size(1327, 515);
            this.finalemp.TabIndex = 2;
            this.finalemp.Text = "Finalizing";
            // 
            // btnfinimgsig
            // 
            this.btnfinimgsig.BackColor = System.Drawing.Color.DarkGray;
            this.btnfinimgsig.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnfinimgsig.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnfinimgsig.Location = new System.Drawing.Point(1011, 264);
            this.btnfinimgsig.Name = "btnfinimgsig";
            this.btnfinimgsig.Size = new System.Drawing.Size(125, 31);
            this.btnfinimgsig.TabIndex = 7;
            this.btnfinimgsig.Text = "Choose File";
            this.btnfinimgsig.UseVisualStyleBackColor = false;
            this.btnfinimgsig.Click += new System.EventHandler(this.btnfinimgsig_Click);
            // 
            // btnfinimemp
            // 
            this.btnfinimemp.BackColor = System.Drawing.Color.DarkGray;
            this.btnfinimemp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnfinimemp.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnfinimemp.Location = new System.Drawing.Point(1011, 154);
            this.btnfinimemp.Name = "btnfinimemp";
            this.btnfinimemp.Size = new System.Drawing.Size(125, 31);
            this.btnfinimemp.TabIndex = 5;
            this.btnfinimemp.Text = "Choose File";
            this.btnfinimemp.UseVisualStyleBackColor = false;
            this.btnfinimemp.Click += new System.EventHandler(this.btnfinimemp_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(760, 266);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(215, 29);
            this.label15.TabIndex = 56;
            this.label15.Text = "Image of Signature";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(760, 152);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(221, 29);
            this.label16.TabIndex = 55;
            this.label16.Text = "Image of Employee";
            // 
            // datefinagree
            // 
            this.datefinagree.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datefinagree.Location = new System.Drawing.Point(1011, 38);
            this.datefinagree.Name = "datefinagree";
            this.datefinagree.Size = new System.Drawing.Size(270, 34);
            this.datefinagree.TabIndex = 3;
            this.datefinagree.Value = new System.DateTime(2023, 11, 15, 0, 20, 47, 0);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(760, 43);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(171, 29);
            this.label17.TabIndex = 53;
            this.label17.Text = "Agreement Till";
            // 
            // btnfinsave
            // 
            this.btnfinsave.BackColor = System.Drawing.Color.Lime;
            this.btnfinsave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnfinsave.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnfinsave.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnfinsave.Location = new System.Drawing.Point(598, 391);
            this.btnfinsave.Name = "btnfinsave";
            this.btnfinsave.Size = new System.Drawing.Size(170, 62);
            this.btnfinsave.TabIndex = 8;
            this.btnfinsave.Text = "Save";
            this.btnfinsave.UseVisualStyleBackColor = false;
            this.btnfinsave.Click += new System.EventHandler(this.btnfinsave_Click);
            // 
            // datefinsalg
            // 
            this.datefinsalg.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datefinsalg.Location = new System.Drawing.Point(308, 261);
            this.datefinsalg.Name = "datefinsalg";
            this.datefinsalg.Size = new System.Drawing.Size(270, 34);
            this.datefinsalg.TabIndex = 6;
            this.datefinsalg.Value = new System.DateTime(2023, 11, 15, 0, 20, 47, 0);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(46, 267);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(244, 29);
            this.label18.TabIndex = 49;
            this.label18.Text = "Date for Salary Giving";
            // 
            // txtfinbonus
            // 
            this.txtfinbonus.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfinbonus.Location = new System.Drawing.Point(308, 149);
            this.txtfinbonus.Multiline = true;
            this.txtfinbonus.Name = "txtfinbonus";
            this.txtfinbonus.Size = new System.Drawing.Size(270, 37);
            this.txtfinbonus.TabIndex = 4;
            this.txtfinbonus.WordWrap = false;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(46, 152);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(148, 29);
            this.label19.TabIndex = 46;
            this.label19.Text = "Bonus / Fine";
            // 
            // txtfinsal
            // 
            this.txtfinsal.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfinsal.Location = new System.Drawing.Point(308, 36);
            this.txtfinsal.Multiline = true;
            this.txtfinsal.Name = "txtfinsal";
            this.txtfinsal.Size = new System.Drawing.Size(270, 37);
            this.txtfinsal.TabIndex = 2;
            this.txtfinsal.WordWrap = false;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(46, 39);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(80, 29);
            this.label21.TabIndex = 43;
            this.label21.Text = "Salary";
            // 
            // commodeid
            // 
            this.commodeid.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.commodeid.FormattingEnabled = true;
            this.commodeid.Location = new System.Drawing.Point(387, 26);
            this.commodeid.Name = "commodeid";
            this.commodeid.Size = new System.Drawing.Size(270, 37);
            this.commodeid.TabIndex = 48;
            // 
            // ModifyEmployee
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.Tan;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1924, 1055);
            this.Controls.Add(this.commodeid);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.btnmodrem);
            this.Controls.Add(this.btnmodsearch);
            this.Controls.Add(this.label2);
            this.DoubleBuffered = true;
            this.Name = "ModifyEmployee";
            this.ShowIcon = false;
            this.Text = "Modify Employee";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.ModifyEmployee_Load);
            this.tabControl1.ResumeLayout(false);
            this.addemp.ResumeLayout(false);
            this.addemp.PerformLayout();
            this.advemp.ResumeLayout(false);
            this.advemp.PerformLayout();
            this.finalemp.ResumeLayout(false);
            this.finalemp.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnmodsearch;
        private System.Windows.Forms.Button btnmodrem;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage addemp;
        private System.Windows.Forms.Button btnbasnext;
        private System.Windows.Forms.ComboBox combasrole;
        private System.Windows.Forms.ComboBox combasbra;
        private System.Windows.Forms.TextBox txtbasnum;
        private System.Windows.Forms.TextBox textbaslastname;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtbasefirstname;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TabPage advemp;
        private System.Windows.Forms.Button btnadnext;
        private System.Windows.Forms.TextBox txtadparadd;
        private System.Windows.Forms.RadioButton radioadno;
        private System.Windows.Forms.RadioButton radioadyes;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DateTimePicker dateadjoin;
        private System.Windows.Forms.TextBox txtadlocaladd;
        private System.Windows.Forms.TextBox txtadidnum;
        private System.Windows.Forms.Label labadidnum;
        private System.Windows.Forms.ComboBox comadidtype;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.TextBox txtaddaltnum;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TabPage finalemp;
        private System.Windows.Forms.Button btnfinimgsig;
        private System.Windows.Forms.Button btnfinimemp;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.DateTimePicker datefinagree;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button btnfinsave;
        private System.Windows.Forms.DateTimePicker datefinsalg;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtfinbonus;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtfinsal;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox commodeid;
    }
}