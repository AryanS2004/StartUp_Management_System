﻿namespace STARTUP___MANAGEMENT___SYSTEM
{
    partial class admin_page
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(admin_page));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.employeeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addNewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.attendanceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mODIFYToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.projectsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.teamsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bugetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.documentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.documentsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.stockToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabmsg = new System.Windows.Forms.TabPage();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.richTextBox5 = new System.Windows.Forms.RichTextBox();
            this.tabtoday = new System.Windows.Forms.TabPage();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.tabfuture = new System.Windows.Forms.TabPage();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.linkaboutus = new System.Windows.Forms.LinkLabel();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabmsg.SuspendLayout();
            this.tabtoday.SuspendLayout();
            this.tabfuture.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.DimGray;
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.Left;
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI", 20F);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.employeeToolStripMenuItem,
            this.projectsToolStripMenuItem,
            this.teamsToolStripMenuItem,
            this.bugetToolStripMenuItem,
            this.documentsToolStripMenuItem});
            this.menuStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.VerticalStackWithOverflow;
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(6, 0, 0, 6);
            this.menuStrip1.Size = new System.Drawing.Size(208, 1055);
            this.menuStrip1.TabIndex = 7;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // employeeToolStripMenuItem
            // 
            this.employeeToolStripMenuItem.BackColor = System.Drawing.Color.Goldenrod;
            this.employeeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addNewToolStripMenuItem,
            this.attendanceToolStripMenuItem,
            this.mODIFYToolStripMenuItem,
            this.viewToolStripMenuItem});
            this.employeeToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 20F);
            this.employeeToolStripMenuItem.Margin = new System.Windows.Forms.Padding(10, 80, 10, 50);
            this.employeeToolStripMenuItem.Name = "employeeToolStripMenuItem";
            this.employeeToolStripMenuItem.Size = new System.Drawing.Size(175, 50);
            this.employeeToolStripMenuItem.Text = "Employee";
            // 
            // addNewToolStripMenuItem
            // 
            this.addNewToolStripMenuItem.BackColor = System.Drawing.Color.White;
            this.addNewToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 15F);
            this.addNewToolStripMenuItem.Name = "addNewToolStripMenuItem";
            this.addNewToolStripMenuItem.Size = new System.Drawing.Size(230, 40);
            this.addNewToolStripMenuItem.Text = "Add New";
            this.addNewToolStripMenuItem.Click += new System.EventHandler(this.addNewToolStripMenuItem_Click);
            // 
            // attendanceToolStripMenuItem
            // 
            this.attendanceToolStripMenuItem.BackColor = System.Drawing.Color.White;
            this.attendanceToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 15F);
            this.attendanceToolStripMenuItem.Name = "attendanceToolStripMenuItem";
            this.attendanceToolStripMenuItem.Size = new System.Drawing.Size(230, 40);
            this.attendanceToolStripMenuItem.Text = "Attendance";
            this.attendanceToolStripMenuItem.Click += new System.EventHandler(this.attendanceToolStripMenuItem_Click);
            // 
            // mODIFYToolStripMenuItem
            // 
            this.mODIFYToolStripMenuItem.BackColor = System.Drawing.Color.White;
            this.mODIFYToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 15F);
            this.mODIFYToolStripMenuItem.Name = "mODIFYToolStripMenuItem";
            this.mODIFYToolStripMenuItem.Size = new System.Drawing.Size(230, 40);
            this.mODIFYToolStripMenuItem.Text = "Modify";
            this.mODIFYToolStripMenuItem.Click += new System.EventHandler(this.mODIFYToolStripMenuItem_Click);
            // 
            // viewToolStripMenuItem
            // 
            this.viewToolStripMenuItem.BackColor = System.Drawing.Color.White;
            this.viewToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 15F);
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            this.viewToolStripMenuItem.Size = new System.Drawing.Size(230, 40);
            this.viewToolStripMenuItem.Text = "View Details";
            this.viewToolStripMenuItem.Click += new System.EventHandler(this.viewToolStripMenuItem_Click);
            // 
            // projectsToolStripMenuItem
            // 
            this.projectsToolStripMenuItem.BackColor = System.Drawing.Color.Goldenrod;
            this.projectsToolStripMenuItem.Margin = new System.Windows.Forms.Padding(10, 30, 10, 40);
            this.projectsToolStripMenuItem.Name = "projectsToolStripMenuItem";
            this.projectsToolStripMenuItem.Size = new System.Drawing.Size(175, 50);
            this.projectsToolStripMenuItem.Text = "Projects";
            this.projectsToolStripMenuItem.Click += new System.EventHandler(this.projectsToolStripMenuItem_Click);
            // 
            // teamsToolStripMenuItem
            // 
            this.teamsToolStripMenuItem.BackColor = System.Drawing.Color.Goldenrod;
            this.teamsToolStripMenuItem.Margin = new System.Windows.Forms.Padding(10, 30, 10, 40);
            this.teamsToolStripMenuItem.Name = "teamsToolStripMenuItem";
            this.teamsToolStripMenuItem.Size = new System.Drawing.Size(175, 50);
            this.teamsToolStripMenuItem.Text = "Teams";
            this.teamsToolStripMenuItem.Click += new System.EventHandler(this.teamsToolStripMenuItem_Click);
            // 
            // bugetToolStripMenuItem
            // 
            this.bugetToolStripMenuItem.BackColor = System.Drawing.Color.Goldenrod;
            this.bugetToolStripMenuItem.Margin = new System.Windows.Forms.Padding(10, 30, 10, 40);
            this.bugetToolStripMenuItem.Name = "bugetToolStripMenuItem";
            this.bugetToolStripMenuItem.Size = new System.Drawing.Size(175, 50);
            this.bugetToolStripMenuItem.Text = "Cash Flow";
            this.bugetToolStripMenuItem.Click += new System.EventHandler(this.bugetToolStripMenuItem_Click);
            // 
            // documentsToolStripMenuItem
            // 
            this.documentsToolStripMenuItem.BackColor = System.Drawing.Color.Goldenrod;
            this.documentsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.documentsToolStripMenuItem1,
            this.stockToolStripMenuItem});
            this.documentsToolStripMenuItem.Margin = new System.Windows.Forms.Padding(10, 30, 10, 40);
            this.documentsToolStripMenuItem.Name = "documentsToolStripMenuItem";
            this.documentsToolStripMenuItem.Size = new System.Drawing.Size(175, 50);
            this.documentsToolStripMenuItem.Text = "Assets";
            // 
            // documentsToolStripMenuItem1
            // 
            this.documentsToolStripMenuItem1.Font = new System.Drawing.Font("Segoe UI", 15F);
            this.documentsToolStripMenuItem1.Name = "documentsToolStripMenuItem1";
            this.documentsToolStripMenuItem1.Size = new System.Drawing.Size(222, 40);
            this.documentsToolStripMenuItem1.Text = "Documents";
            this.documentsToolStripMenuItem1.Click += new System.EventHandler(this.documentsToolStripMenuItem1_Click);
            // 
            // stockToolStripMenuItem
            // 
            this.stockToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 15F);
            this.stockToolStripMenuItem.Name = "stockToolStripMenuItem";
            this.stockToolStripMenuItem.Size = new System.Drawing.Size(222, 40);
            this.stockToolStripMenuItem.Text = "Stock";
            this.stockToolStripMenuItem.Click += new System.EventHandler(this.stockToolStripMenuItem_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(232)))), ((int)(((byte)(172)))));
            this.panel1.Controls.Add(this.tabControl1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(328, 60);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(528, 541);
            this.panel1.TabIndex = 13;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabmsg);
            this.tabControl1.Controls.Add(this.tabtoday);
            this.tabControl1.Controls.Add(this.tabfuture);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.tabControl1.Location = new System.Drawing.Point(3, 73);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.Padding = new System.Drawing.Point(8, 2);
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(522, 461);
            this.tabControl1.TabIndex = 1;
            // 
            // tabmsg
            // 
            this.tabmsg.BackColor = System.Drawing.Color.SeaGreen;
            this.tabmsg.Controls.Add(this.button9);
            this.tabmsg.Controls.Add(this.button10);
            this.tabmsg.Controls.Add(this.richTextBox5);
            this.tabmsg.Location = new System.Drawing.Point(4, 32);
            this.tabmsg.Name = "tabmsg";
            this.tabmsg.Size = new System.Drawing.Size(514, 425);
            this.tabmsg.TabIndex = 2;
            this.tabmsg.Text = "Reminders";
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.OliveDrab;
            this.button9.Location = new System.Drawing.Point(288, 370);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(151, 47);
            this.button9.TabIndex = 5;
            this.button9.Text = "Clear";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.OliveDrab;
            this.button10.Location = new System.Drawing.Point(59, 370);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(151, 47);
            this.button10.TabIndex = 4;
            this.button10.Text = "Save";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // richTextBox5
            // 
            this.richTextBox5.Location = new System.Drawing.Point(5, 7);
            this.richTextBox5.Name = "richTextBox5";
            this.richTextBox5.Size = new System.Drawing.Size(502, 357);
            this.richTextBox5.TabIndex = 3;
            this.richTextBox5.Text = "we have to work hard and give our best .\nnever give up.\nif you can\'t do it , then" +
    " no one can. ";
            // 
            // tabtoday
            // 
            this.tabtoday.BackColor = System.Drawing.Color.MediumPurple;
            this.tabtoday.Controls.Add(this.richTextBox1);
            this.tabtoday.Location = new System.Drawing.Point(4, 32);
            this.tabtoday.Name = "tabtoday";
            this.tabtoday.Padding = new System.Windows.Forms.Padding(3);
            this.tabtoday.Size = new System.Drawing.Size(514, 425);
            this.tabtoday.TabIndex = 0;
            this.tabtoday.Text = "Todays Task";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Enabled = false;
            this.richTextBox1.Location = new System.Drawing.Point(5, 7);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(502, 357);
            this.richTextBox1.TabIndex = 0;
            this.richTextBox1.Text = "Projects - \nProject ABC ( P001) Should be submitted. ";
            // 
            // tabfuture
            // 
            this.tabfuture.BackColor = System.Drawing.Color.SaddleBrown;
            this.tabfuture.Controls.Add(this.richTextBox2);
            this.tabfuture.Location = new System.Drawing.Point(4, 32);
            this.tabfuture.Name = "tabfuture";
            this.tabfuture.Padding = new System.Windows.Forms.Padding(3);
            this.tabfuture.Size = new System.Drawing.Size(514, 425);
            this.tabfuture.TabIndex = 1;
            this.tabfuture.Text = "Future Tasks";
            // 
            // richTextBox2
            // 
            this.richTextBox2.Enabled = false;
            this.richTextBox2.Location = new System.Drawing.Point(5, 7);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(502, 357);
            this.richTextBox2.TabIndex = 1;
            this.richTextBox2.Text = "Projects In 3 Days - \nProject XYZ ( P023) is going to be submitted .";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Baskerville Old Face", 13.8F);
            this.label1.Location = new System.Drawing.Point(194, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(127, 27);
            this.label1.TabIndex = 0;
            this.label1.Text = "Dash Board";
            // 
            // linkaboutus
            // 
            this.linkaboutus.AutoSize = true;
            this.linkaboutus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(129)))), ((int)(((byte)(60)))));
            this.linkaboutus.Font = new System.Drawing.Font("Bookman Old Style", 16F);
            this.linkaboutus.ForeColor = System.Drawing.Color.Black;
            this.linkaboutus.LinkColor = System.Drawing.Color.Black;
            this.linkaboutus.Location = new System.Drawing.Point(1735, 26);
            this.linkaboutus.Name = "linkaboutus";
            this.linkaboutus.Size = new System.Drawing.Size(174, 32);
            this.linkaboutus.TabIndex = 15;
            this.linkaboutus.TabStop = true;
            this.linkaboutus.Text = "Need Help ?";
            this.linkaboutus.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkaboutus_LinkClicked);
            // 
            // admin_page
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Sienna;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1924, 1055);
            this.Controls.Add(this.linkaboutus);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "admin_page";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "admin page";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.admin_page_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabmsg.ResumeLayout(false);
            this.tabtoday.ResumeLayout(false);
            this.tabfuture.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem employeeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addNewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mODIFYToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem attendanceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem projectsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem teamsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bugetToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem documentsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabtoday;
        private System.Windows.Forms.TabPage tabfuture;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.TabPage tabmsg;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.RichTextBox richTextBox5;
        private System.Windows.Forms.ToolStripMenuItem documentsToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem stockToolStripMenuItem;
        private System.Windows.Forms.LinkLabel linkaboutus;

    }
}